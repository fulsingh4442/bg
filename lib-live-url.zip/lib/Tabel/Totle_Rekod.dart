import 'package:bookings/Home1.dart';
import 'package:bookings/models/Table_Response_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:percent_indicator/percent_indicator.dart';

class Totle_Rekod extends StatefulWidget {
  const Totle_Rekod({Key key}) : super(key: key);

  @override
  State<Totle_Rekod> createState() => _Totle_RekodState();
}

class _Totle_RekodState extends State<Totle_Rekod> {
  bool _isVisible = false;
  String level1 = '';
  void hideWidget() {
    setState(() {
      _isVisible = !_isVisible;
    });
  }
  TableResponseModel tableResponseModel;
  // Future booking;
  DateTime _selectedDate;
  String _formatted;

  bool viaTextField = false;
  TextEditingController textEditingController = TextEditingController();
  TextEditingController _textEditingController1 = TextEditingController();

  getDetails(String currentDate) {
    print("inside get details");
    // setState(() {
    //   booking(currentDate).then((value) {
    //     tableResponseModel = value;
    //   });
    // });
  }

  @override
  void initState() {
    super.initState();
    if (_textEditingController1.text.isEmpty) {
      final DateFormat _formatter = DateFormat('yyyy-MM-dd');
      _textEditingController1.text = _formatter.format(DateTime.now());
      _formatted =
          _formatter.format(DateTime.parse(_textEditingController1.text));
      print("formatted ---- $_formatted");
      getDetails(_formatted);
     // selectedDate = _formatted;
    }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     // backgroundColor: Colors.black,
      appBar: AppBar(

        backgroundColor: Colors.black,
        leading: InkWell(
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => home()),
                      (Route<dynamic> route) => false);
            },
            child: Icon(Icons.arrow_back)),
        title: Center(
          child: Container(
              margin: EdgeInsets.only(right: 50),
              height: 40,width: 40,

              child: Image.asset('assets/images/appicon.png',color: Colors.white )),
        ),
        // actions: <Widget>[
        //   InkWell(
        //   onTap: () {},
        //     child: Padding(
        //         padding: EdgeInsets.only(right: 20.0),
        //         child: GestureDetector(
        //           onTap: () {
        //             _selectDate(context);
        //           },
        //           child: Icon(
        //             Icons.calendar_month_outlined,
        //             size: 26.0,
        //           ),
        //         )
        //     ),
        //   ),
        // ],
        // suffixIcon: InkWell(
        //     onTap: () {
        //       _selectDate(context);
        //
        //
        //     },
        //     child: Icon(Icons.calendar_month_outlined,color: Colors.black,)),

        //title: Text("Lizard_Lounge",style: TextStyle(fontWeight: FontWeight.bold),),

      ),

      body: Container(

        child: Column(children: [

          Container(
            margin: EdgeInsets.only(left: 10,right: 10,top: 0),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                    //margin: EdgeInsets.only(top: 5),
                    child: Text("Report",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)


                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.40,
                  height: MediaQuery.of(context).size.height * 0.06,
                  margin: EdgeInsets.only(top: 10,left: 0),
                  child: TextField(


                    focusNode: AlwaysDisabledFocusNode(),
                    textAlign: TextAlign.center,
                    controller: _textEditingController1,
                    onTap: () {
                      // tableResponseModel.data.aaData[0].date;
                      // selectedDate = _selectDate(context);
                      // getDetails(selectedDate);
                    },

                    decoration: InputDecoration(
                       contentPadding: const EdgeInsets.only(bottom: 10), isDense: true,
                      // suffixIcon: InkWell(
                      //     onTap: () {
                      //       _selectDate(context);
                      //
                      //
                      //     },
                      //     child: Icon(Icons.calendar_month_outlined,color: Colors.black,)),

                      fillColor: Colors.white,

                      focusedBorder: OutlineInputBorder(

                        borderSide:
                        const BorderSide(color: Colors.white, width: 0.5),
                        borderRadius: BorderRadius.circular(5.0),


                      ),

                      enabledBorder: OutlineInputBorder(
                        borderSide:
                        const BorderSide(color: Colors.white, width: 0.5),
                        borderRadius: BorderRadius.circular(5.0),



                      ),



                    ),


                  ),

                ),
                InkWell(
                      onTap: () {
                        _selectDate(context);


                      },
                  child: Container(
                      margin: EdgeInsets.only(right: 15),
                      height: 30,width: 30,

                      child: Image.asset('assets/images/c2.png' )),
                ),


              ],
            ),
          ),
          Divider(color: Colors.grey,),

           Expanded(

             child: SingleChildScrollView(

               child: Column(
                 children: [
                   Container(
                     margin: EdgeInsets.only(top: 15,left: 15),
                     child: Row(
                       children: [

                         CircularPercentIndicator(
                          radius: 30.0,
                          lineWidth: 5.0,
                          percent: 0.7,
                          center: new Text("70%",style: TextStyle(color: Colors.black),),
                          progressColor: Colors.black,
          ),
                         Column(
                           children: [
                             Container(
                                 margin: EdgeInsets.only(left: 30),
                                 child: Text("Booking Table",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                             Row(
                               children: [
                                 Container(
                                     margin: EdgeInsets.only(left: 20),
                                     child: Text("70/",style: TextStyle(color: Colors.black,fontSize: 15,),)),
                                 Text("100",style: TextStyle(color: Colors.black,fontSize: 15,),)
                               ],
                             )
                           ],
                         )


                       ],
                     ),
                   ),



          Container(

            margin: EdgeInsets.only(top: 10,left: 20),
            child: Column(
              children: [
                Container(
                    margin: EdgeInsets.only(top: 10,),
                    alignment: Alignment.topLeft,

                    child: Text("Total Check-ins.",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                Container(
                    alignment: Alignment.topLeft,
                    margin: EdgeInsets.only(top: 10,left: 30),

                    child: Text("70",style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    // Container(
                    //     margin: EdgeInsets.only(top: 20,right: 10),
                    //     child: Text("12;45",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))
                  ],
                ),

              ],
            ),
          ),
          Divider(color: Colors.grey,),
          Container(
              margin: EdgeInsets.only(top: 5,left: 15),
              alignment: Alignment.topLeft,
              child: Text("Event",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
              Divider(),

          Container(
            alignment: Alignment.topLeft,
              margin: EdgeInsets.only(left: 15),
              child: Text("Abcd",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),

          Container(
            margin: EdgeInsets.only(top: 15,left: 15),
            child: Row(
              children: [

                CircularPercentIndicator(
                  radius: 30.0,
                  lineWidth: 5.0,
                  percent: 0.5,
                  center: new Text("50%",style: TextStyle(color: Colors.black),),
                  progressColor: Colors.black,
                ),
                Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 30),
                        child: Text("Booking Event",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                    Row(
                      children: [
                        Container(
                            margin: EdgeInsets.only(left: 20),
                            child: Text("50/",style: TextStyle(color: Colors.black,fontSize: 15,),)),
                        Text("100",style: TextStyle(color: Colors.black,fontSize: 15,),)
                      ],
                    )
                  ],
                )


              ],
            ),
          ),


          Container(

            margin: EdgeInsets.only(top: 10,left: 20),
            child: Column(
              children: [
                Container(
                    margin: EdgeInsets.only(top: 10,),
                    alignment: Alignment.topLeft,

                    child: Text("Total Check-ins.",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                Container(
                    alignment: Alignment.topLeft,
                    margin: EdgeInsets.only(top: 10,left: 30),

                    child: Text("50",style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    // Container(
                    //     margin: EdgeInsets.only(top: 20,right: 10),
                    //     child: Text("12;45",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))
                  ],
                ),

              ],
            ),
          ),
          Divider(color: Colors.grey,),
          Container(
            alignment: Alignment.topLeft,
              margin: EdgeInsets.only(left: 20),
              child: Text("Reats Stare Event",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                   Divider(),


                   // Container(
                   //     alignment: Alignment.topLeft,
                   //     margin: EdgeInsets.only(left: 15),
                   //     child: Text("Abcd",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),

                   Container(
                     margin: EdgeInsets.only(top: 15,left: 15),
                     child: Row(
                       children: [

                         CircularPercentIndicator(
                           radius: 30.0,
                           lineWidth: 5.0,
                           percent: 0.2,
                           center: new Text("20%",style: TextStyle(color: Colors.black),),
                           progressColor: Colors.black,
                         ),
                         Column(
                           children: [
                             Container(
                                 margin: EdgeInsets.only(left: 30),
                                 child: Text("Booking Event",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                             Row(
                               children: [
                                 Container(
                                     margin: EdgeInsets.only(left: 20),
                                     child: Text("20/",style: TextStyle(color: Colors.black,fontSize: 15,),)),
                                 Text("100",style: TextStyle(color: Colors.black,fontSize: 15,),)
                               ],
                             )
                           ],
                         )


                       ],
                     ),
                   ),


                   Container(

                     margin: EdgeInsets.only(top: 10,left: 20),
                     child: Column(
                       children: [
                         Container(
                             margin: EdgeInsets.only(top: 10,),
                             alignment: Alignment.topLeft,

                             child: Text("Total Check-ins.",style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),)),
                         Container(
                             alignment: Alignment.topLeft,
                             margin: EdgeInsets.only(top: 10,left: 30),

                             child: Text("20",style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),)),
                         Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: [

                             // Container(
                             //     margin: EdgeInsets.only(top: 20,right: 10),
                             //     child: Text("12;45",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))
                           ],
                         ),

                       ],
                     ),
                   ),

          // Expanded(
          //   child: SingleChildScrollView(
          //     child: FutureBuilder(
          //        // future: booking(selectedDate),
          //         builder: (context, snapshot) {
          //           if (!snapshot.hasData) {
          //             return Container(
          //               // color:Colors.red,
          //               // padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
          //               margin: EdgeInsets.only(top: 0),
          //               width: MediaQuery
          //                   .of(context)
          //                   .size
          //                   .width * 1.0,
          //               height: MediaQuery
          //                   .of(context)
          //                   .size
          //                   .height * 0.72,
          //               child: tableResponseModel.data.iTotalRecords == 0
          //                   ? Container(
          //                   margin: EdgeInsets.only(left: 20),
          //                   child: Center(child: Text("No Data Found !")))
          //                   : ListView.builder(
          //                   shrinkWrap: true,
          //                   scrollDirection: Axis.vertical,
          //                   itemCount:
          //                   tableResponseModel.data.aaData.length,
          //                   itemBuilder: (context, index) {
          //                     return GestureDetector(
          //                       onTap: () {
          //                         print(tableResponseModel
          //                             .data.aaData[index].checkinStatus);
          //                         if (tableResponseModel.data
          //                             .aaData[index].checkinStatus ==
          //                             0) {
          //                           print('hii');
          //                         } else {
          //
          //                         }
          //                       },
          //                       child:
          //                       Column(
          //                         children: [
          //                           Container(
          //                             //  margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
          //                             child: Card(
          //                               elevation: 5,
          //                               shape: RoundedRectangleBorder(
          //                                 borderRadius: BorderRadius.circular(
          //                                     10),
          //                               ),
          //                               child: Column(
          //                                 children: [
          //                                 ],
          //                               ),
          //                             ),
          //
          //                           ),
          //                         ],
          //                       ),
          //                     );
          //                   }),
          //             );
          //           }
          //         }),
          //   ),
          // ),
                 ],
               ),

             ),
           ),

        ],
        ),

      ),
    );
  }
  _selectDate(BuildContext context) async {
    DateTime newSelectedDate = await showDatePicker(
        context: context,
        initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2040),
        builder: (BuildContext context, Widget child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: Colors.blue.shade900,
                onPrimary: Colors.white,
                surface: Colors.blue.shade900,
                onSurface: Colors.white,
              ),
              dialogBackgroundColor: Colors.blue[500],
            ),
            child: child,
          );
        });

    if (newSelectedDate != null) {
      _selectedDate = newSelectedDate;
      final DateFormat formatter = DateFormat('dd-MM-yyyy');

      final String formatted = formatter.format(_selectedDate);
      _textEditingController1
        ..text = formatted
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _textEditingController1.text.length,
            affinity: TextAffinity.upstream));
      print(formatted);
      getDetails(formatted);
    }
  }

  getEventDetails(String currentDate) {}


}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}

//
// import 'package:bookings/Home1.dart';
// import 'package:bookings/models/Table_Response_model.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:percent_indicator/percent_indicator.dart';
// class StackOver extends StatefulWidget {
//   @override
//   _StackOverState createState() => _StackOverState();
// }
//
// class _StackOverState extends State<StackOver>
//     with SingleTickerProviderStateMixin {
//   TabController _tabController;
//
//   @override
//   void initState() {
//     if (_textEditingController1.text.isEmpty) {
//       final DateFormat _formatter = DateFormat('yyyy-MM-dd');
//       _textEditingController1.text = _formatter.format(DateTime.now());
//       _formatted =
//           _formatter.format(DateTime.parse(_textEditingController1.text));
//       print("formatted ---- $_formatted");
//       getDetails(_formatted);
//       // selectedDate = _formatted;
//     }
//     _tabController = TabController(length: 2, vsync: this);
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//     _tabController.dispose();
//   }
//   bool _isVisible = false;
//   String level1 = '';
//   void hideWidget() {
//     setState(() {
//       _isVisible = !_isVisible;
//     });
//   }
//   TableResponseModel tableResponseModel;
//   // Future booking;
//   DateTime _selectedDate;
//   String _formatted;
//
//   bool viaTextField = false;
//   TextEditingController textEditingController = TextEditingController();
//   TextEditingController _textEditingController1 = TextEditingController();
//
//   getDetails(String currentDate) {
//     print("inside get details");
//     // setState(() {
//     //   booking(currentDate).then((value) {
//     //     tableResponseModel = value;
//     //   });
//     // });
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//
//         backgroundColor: Colors.black,
//         leading: InkWell(
//             onTap: () {
//               Navigator.of(context).pushAndRemoveUntil(
//                   MaterialPageRoute(builder: (context) => home()),
//                       (Route<dynamic> route) => false);
//             },
//             child: Icon(Icons.arrow_back)),
//         title: Center(
//           child: Container(
//               margin: EdgeInsets.only(right: 50),
//               height: 40,width: 40,
//
//               child: Image.asset('assets/images/appicon.png',color: Colors.white )),
//         ),
//
//
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: Column(
//           children: [
//             // give the tab bar a height [can change hheight to preferred height]
//             Row(
//               children: [
//                 Container(
//                   height: 45,
//                   width: 280,
//                   decoration: BoxDecoration(
//                     color: Colors.grey[300],
//                     borderRadius: BorderRadius.circular(
//                       25.0,
//                     ),
//                   ),
//                   child: TabBar(
//                     controller: _tabController,
//                     // give the indicator a decoration (color and border radius)
//                     indicator: BoxDecoration(
//                       borderRadius: BorderRadius.circular(
//                         25.0,
//                       ),
//                       color: Colors.black,
//                     ),
//                     labelColor: Colors.white,
//                     unselectedLabelColor: Colors.black,
//                     tabs: [
//                       // first tab [you can add an icon using the icon property]
//                       Tab(
//                         text: 'Table',
//                       ),
//
//                       // second tab [you can add an icon using the icon property]
//                       Tab(
//                         text: 'Event',
//                       ),
//                     ],
//                   ),
//                 ),
//                 InkWell(
//                   onTap: () {
//                      _selectDate(context);
//
//                   },
//                   child: Container(
//                       margin: EdgeInsets.only(left: 20,),
//                       height: 40,width: 40,
//
//                       child: Image.asset('assets/images/c2.png', )),
//                 ),
//               ],
//             ),
//             // tab bar view here
//             Expanded(
//               child: TabBarView(
//                 controller: _tabController,
//                 children: [
//                   // first tab bar view widget
//                   Column(children: [
//
//                     // Container(
//                     //   margin: EdgeInsets.only(left: 10,right: 10,top: 5),
//                     //   child: Row(
//                     //     mainAxisAlignment: MainAxisAlignment.center,
//                     //     children: [
//                     //       InkWell(
//                     //         onTap: () {
//                     //           setState((){
//                     //             // _booking1(
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].bookingUid,
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].date,
//                     //             //     "table");
//                     //             // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//                     //             //   content: Text("Check in successfully"),
//                     //             // ));
//                     //
//                     //           });
//                     //
//                     //
//                     //         },
//                     //
//                     //         child: Row(
//                     //           mainAxisAlignment: MainAxisAlignment.center,
//                     //           children: [
//                     //             Container(
//                     //               // margin: EdgeInsets.only(left: 10),
//                     //               decoration: BoxDecoration(
//                     //                 borderRadius: BorderRadius.all(Radius.circular(5)),
//                     //                 gradient: LinearGradient(colors: [
//                     //                   Colors.black,
//                     //                   Colors.black,
//                     //                   Colors.black
//                     //                 ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                     //               ),
//                     //               padding: EdgeInsets.fromLTRB(45, 12, 45, 12,),
//                     //               child: Text(
//                     //                 "Table",
//                     //                 style: TextStyle(
//                     //                   //fontSize: 20,
//                     //                     color: Colors.white,fontWeight: FontWeight.bold
//                     //                 ),
//                     //               ),
//                     //             ),
//                     //           ],
//                     //         ),
//                     //       ),
//                     //
//                     //       InkWell(
//                     //         onTap: () {
//                     //           setState((){
//                     //             // _booking1(
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].bookingUid,
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].date,
//                     //             //     "table");
//                     //             // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//                     //             //   content: Text("Check in successfully"),
//                     //             // ));
//                     //
//                     //           });
//                     //
//                     //
//                     //         },
//                     //
//                     //         child: Row(
//                     //           mainAxisAlignment: MainAxisAlignment.center,
//                     //           children: [
//                     //             Container(
//                     //               margin: EdgeInsets.only(left: 10),
//                     //               decoration: BoxDecoration(
//                     //                 borderRadius: BorderRadius.all(Radius.circular(5)),
//                     //                 gradient: LinearGradient(colors: [
//                     //                   Colors.black,
//                     //                   Colors.black,
//                     //                   Colors.black
//                     //                 ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                     //               ),
//                     //               padding: EdgeInsets.fromLTRB(45, 12, 45, 12,),
//                     //               child: Text(
//                     //                 "Event",
//                     //                 style: TextStyle(
//                     //                   //fontSize: 20,
//                     //                     color: Colors.white,fontWeight: FontWeight.bold
//                     //                 ),
//                     //               ),
//                     //             ),
//                     //           ],
//                     //         ),
//                     //       ),
//                     //       InkWell(
//                     //         onTap: () {
//                     //          // _selectDate(context);
//                     //
//                     //         },
//                     //         child: Container(
//                     //             margin: EdgeInsets.only(left: 20,),
//                     //             height: 40,width: 40,
//                     //
//                     //             child: Image.asset('assets/images/Calendar.jpg', )),
//                     //       ),
//                     //
//                     //
//                     //       // Container(
//                     //       //   width: MediaQuery.of(context).size.width * 0.40,
//                     //       //   height: MediaQuery.of(context).size.height * 0.06,
//                     //       //   margin: EdgeInsets.only(left: 10),
//                     //       //
//                     //       //     child: TextField(
//                     //       //
//                     //       //
//                     //       //       focusNode: AlwaysDisabledFocusNode(),
//                     //       //       textAlign: TextAlign.center,
//                     //       //
//                     //       //
//                     //       //       controller: _textEditingController1,
//                     //       //       autofocus: true,
//                     //       //
//                     //       //
//                     //       //       onTap: () {
//                     //       //         // tableResponseModel.data.aaData[0].date;
//                     //       //         // selectedDate = _selectDate(context);
//                     //       //         // getDetails(selectedDate);
//                     //       //       },
//                     //       //
//                     //       //       decoration: InputDecoration(
//                     //       //         // suffixIcon: InkWell(
//                     //       //         //     onTap: () {
//                     //       //         //       _selectDate(context);
//                     //       //         //
//                     //       //         //
//                     //       //         //     },
//                     //       //         //     child: Icon(Icons.calendar_month_outlined,color: Colors.black,)),
//                     //       //
//                     //       //         fillColor: Colors.white,
//                     //       //
//                     //       //         focusedBorder: OutlineInputBorder(
//                     //       //
//                     //       //           borderSide:
//                     //       //           const BorderSide(color: Colors.black, width: 0.5),
//                     //       //           borderRadius: BorderRadius.circular(5.0),
//                     //       //
//                     //       //
//                     //       //         ),
//                     //       //
//                     //       //         enabledBorder: OutlineInputBorder(
//                     //       //           borderSide:
//                     //       //           const BorderSide(color: Colors.black, width: 0.5),
//                     //       //           borderRadius: BorderRadius.circular(5.0),
//                     //       //
//                     //       //
//                     //       //
//                     //       //         ),
//                     //       //
//                     //       //
//                     //       //
//                     //       //       ),
//                     //       //
//                     //       //
//                     //       //     ),
//                     //       //
//                     //       //
//                     //       // ),
//                     //
//                     //
//                     //     ],
//                     //   ),
//                     // ),
//                     Divider(color: Colors.grey,),
//
//                     Container(
//                       margin: EdgeInsets.only(top: 15,left: 15),
//                       child: Row(
//                         children: [
//
//                           CircularPercentIndicator(
//                             radius: 30.0,
//                             lineWidth: 5.0,
//                             percent: 0.7,
//                             center: new Text("70%",style: TextStyle(color: Colors.black),),
//                             progressColor: Colors.black,
//                           ),
//                           Column(
//                             children: [
//                               Container(
//                                   margin: EdgeInsets.only(left: 30),
//                                   child: Text("Booking Table",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                               Row(
//                                 children: [
//                                   Container(
//                                       margin: EdgeInsets.only(left: 20),
//                                       child: Text("70/",style: TextStyle(color: Colors.black,fontSize: 18,),)),
//                                   Text("100",style: TextStyle(color: Colors.black,fontSize: 18,),)
//                                 ],
//                               )
//                             ],
//                           )
//
//
//                         ],
//                       ),
//                     ),
//
//
//                     Container(
//
//                       margin: EdgeInsets.only(top: 10,left: 20),
//                       child: Column(
//                         children: [
//                           Container(
//                               margin: EdgeInsets.only(top: 10,),
//                               alignment: Alignment.topLeft,
//
//                               child: Text("Total Check-ins.",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                           Container(
//                               alignment: Alignment.topLeft,
//                               margin: EdgeInsets.only(top: 10,left: 30),
//
//                               child: Text("70",style: TextStyle(color: Colors.black,fontSize: 30,fontWeight: FontWeight.bold),)),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Container(
//                                   margin: EdgeInsets.only(top: 20,),
//                                   alignment: Alignment.topLeft,
//                                   child: Text("Checkin Activity",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                               // Container(
//                               //     margin: EdgeInsets.only(top: 20,right: 10),
//                               //     child: Text("12;45",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))
//                             ],
//                           ),
//
//                         ],
//                       ),
//                     ),
//                     Divider(color: Colors.grey,),
//                     // Expanded(
//                     //   child: SingleChildScrollView(
//                     //     child: FutureBuilder(
//                     //        // future: booking(selectedDate),
//                     //         builder: (context, snapshot) {
//                     //           if (!snapshot.hasData) {
//                     //             return Container(
//                     //               // color:Colors.red,
//                     //               // padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
//                     //               margin: EdgeInsets.only(top: 0),
//                     //               width: MediaQuery
//                     //                   .of(context)
//                     //                   .size
//                     //                   .width * 1.0,
//                     //               height: MediaQuery
//                     //                   .of(context)
//                     //                   .size
//                     //                   .height * 0.72,
//                     //               child: tableResponseModel.data.iTotalRecords == 0
//                     //                   ? Container(
//                     //                   margin: EdgeInsets.only(left: 20),
//                     //                   child: Center(child: Text("No Data Found !")))
//                     //                   : ListView.builder(
//                     //                   shrinkWrap: true,
//                     //                   scrollDirection: Axis.vertical,
//                     //                   itemCount:
//                     //                   tableResponseModel.data.aaData.length,
//                     //                   itemBuilder: (context, index) {
//                     //                     return GestureDetector(
//                     //                       onTap: () {
//                     //                         print(tableResponseModel
//                     //                             .data.aaData[index].checkinStatus);
//                     //                         if (tableResponseModel.data
//                     //                             .aaData[index].checkinStatus ==
//                     //                             0) {
//                     //                           print('hii');
//                     //                         } else {
//                     //
//                     //                         }
//                     //                       },
//                     //                       child:
//                     //                       Column(
//                     //                         children: [
//                     //                           Container(
//                     //                             //  margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                     //                             child: Card(
//                     //                               elevation: 5,
//                     //                               shape: RoundedRectangleBorder(
//                     //                                 borderRadius: BorderRadius.circular(
//                     //                                     10),
//                     //                               ),
//                     //                               child: Column(
//                     //                                 children: [
//                     //                                 ],
//                     //                               ),
//                     //                             ),
//                     //
//                     //                           ),
//                     //                         ],
//                     //                       ),
//                     //                     );
//                     //                   }),
//                     //             );
//                     //           }
//                     //         }),
//                     //   ),
//                     // ),
//                     Expanded(
//                       child: SingleChildScrollView(
//                         child: Column(
//                           children: [
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table1    ",),
//                                   Text("12:45"),
//
//                                 ],),
//
//                             ),
//
//
//
//                             Divider(color: Colors.grey,),
//                             SizedBox(height: 2,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table2    ",),
//                                   Text("1:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table3    ",),
//                                   Text("2:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table4    ",),
//                                   Text("2:15")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table5    ",),
//                                   Text("2:30")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table6    ",),
//                                   Text("2:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table7    ",),
//                                   Text("3:00")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table8    ",),
//                                   Text("3:35")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table9    ",),
//                                   Text("3:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table10    ",),
//                                   Text("3:59")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Table11    ",),
//                                   Text("4:00")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//
//
//
//
//
//
//
//
//
//                           ],
//                         ),
//
//                       ),
//                     ),
//                   ],
//                   ),
//
//                   // second tab bar view widget
//                   Column(children: [
//
//                     // Container(
//                     //   margin: EdgeInsets.only(left: 10,right: 10,top: 5),
//                     //   child: Row(
//                     //     mainAxisAlignment: MainAxisAlignment.center,
//                     //     children: [
//                     //       InkWell(
//                     //         onTap: () {
//                     //           setState((){
//                     //             // _booking1(
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].bookingUid,
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].date,
//                     //             //     "table");
//                     //             // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//                     //             //   content: Text("Check in successfully"),
//                     //             // ));
//                     //
//                     //           });
//                     //
//                     //
//                     //         },
//                     //
//                     //         child: Row(
//                     //           mainAxisAlignment: MainAxisAlignment.center,
//                     //           children: [
//                     //             Container(
//                     //               // margin: EdgeInsets.only(left: 10),
//                     //               decoration: BoxDecoration(
//                     //                 borderRadius: BorderRadius.all(Radius.circular(5)),
//                     //                 gradient: LinearGradient(colors: [
//                     //                   Colors.black,
//                     //                   Colors.black,
//                     //                   Colors.black
//                     //                 ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                     //               ),
//                     //               padding: EdgeInsets.fromLTRB(45, 12, 45, 12,),
//                     //               child: Text(
//                     //                 "Table",
//                     //                 style: TextStyle(
//                     //                   //fontSize: 20,
//                     //                     color: Colors.white,fontWeight: FontWeight.bold
//                     //                 ),
//                     //               ),
//                     //             ),
//                     //           ],
//                     //         ),
//                     //       ),
//                     //
//                     //       InkWell(
//                     //         onTap: () {
//                     //           setState((){
//                     //             // _booking1(
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].bookingUid,
//                     //             //     tableResponseModel.data.aaData
//                     //             //     [index].date,
//                     //             //     "table");
//                     //             // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//                     //             //   content: Text("Check in successfully"),
//                     //             // ));
//                     //
//                     //           });
//                     //
//                     //
//                     //         },
//                     //
//                     //         child: Row(
//                     //           mainAxisAlignment: MainAxisAlignment.center,
//                     //           children: [
//                     //             Container(
//                     //               margin: EdgeInsets.only(left: 10),
//                     //               decoration: BoxDecoration(
//                     //                 borderRadius: BorderRadius.all(Radius.circular(5)),
//                     //                 gradient: LinearGradient(colors: [
//                     //                   Colors.black,
//                     //                   Colors.black,
//                     //                   Colors.black
//                     //                 ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                     //               ),
//                     //               padding: EdgeInsets.fromLTRB(45, 12, 45, 12,),
//                     //               child: Text(
//                     //                 "Event",
//                     //                 style: TextStyle(
//                     //                   //fontSize: 20,
//                     //                     color: Colors.white,fontWeight: FontWeight.bold
//                     //                 ),
//                     //               ),
//                     //             ),
//                     //           ],
//                     //         ),
//                     //       ),
//                     //       InkWell(
//                     //         onTap: () {
//                     //          // _selectDate(context);
//                     //
//                     //         },
//                     //         child: Container(
//                     //             margin: EdgeInsets.only(left: 20,),
//                     //             height: 40,width: 40,
//                     //
//                     //             child: Image.asset('assets/images/Calendar.jpg', )),
//                     //       ),
//                     //
//                     //
//                     //       // Container(
//                     //       //   width: MediaQuery.of(context).size.width * 0.40,
//                     //       //   height: MediaQuery.of(context).size.height * 0.06,
//                     //       //   margin: EdgeInsets.only(left: 10),
//                     //       //
//                     //       //     child: TextField(
//                     //       //
//                     //       //
//                     //       //       focusNode: AlwaysDisabledFocusNode(),
//                     //       //       textAlign: TextAlign.center,
//                     //       //
//                     //       //
//                     //       //       controller: _textEditingController1,
//                     //       //       autofocus: true,
//                     //       //
//                     //       //
//                     //       //       onTap: () {
//                     //       //         // tableResponseModel.data.aaData[0].date;
//                     //       //         // selectedDate = _selectDate(context);
//                     //       //         // getDetails(selectedDate);
//                     //       //       },
//                     //       //
//                     //       //       decoration: InputDecoration(
//                     //       //         // suffixIcon: InkWell(
//                     //       //         //     onTap: () {
//                     //       //         //       _selectDate(context);
//                     //       //         //
//                     //       //         //
//                     //       //         //     },
//                     //       //         //     child: Icon(Icons.calendar_month_outlined,color: Colors.black,)),
//                     //       //
//                     //       //         fillColor: Colors.white,
//                     //       //
//                     //       //         focusedBorder: OutlineInputBorder(
//                     //       //
//                     //       //           borderSide:
//                     //       //           const BorderSide(color: Colors.black, width: 0.5),
//                     //       //           borderRadius: BorderRadius.circular(5.0),
//                     //       //
//                     //       //
//                     //       //         ),
//                     //       //
//                     //       //         enabledBorder: OutlineInputBorder(
//                     //       //           borderSide:
//                     //       //           const BorderSide(color: Colors.black, width: 0.5),
//                     //       //           borderRadius: BorderRadius.circular(5.0),
//                     //       //
//                     //       //
//                     //       //
//                     //       //         ),
//                     //       //
//                     //       //
//                     //       //
//                     //       //       ),
//                     //       //
//                     //       //
//                     //       //     ),
//                     //       //
//                     //       //
//                     //       // ),
//                     //
//                     //
//                     //     ],
//                     //   ),
//                     // ),
//                     Divider(color: Colors.grey,),
//
//                     Container(
//                       margin: EdgeInsets.only(top: 15,left: 15),
//                       child: Row(
//                         children: [
//
//                           CircularPercentIndicator(
//                             radius: 30.0,
//                             lineWidth: 5.0,
//                             percent: 0.4,
//                             center: new Text("40%",style: TextStyle(color: Colors.black),),
//                             progressColor: Colors.black,
//                           ),
//                           Column(
//                             children: [
//                               Container(
//                                   margin: EdgeInsets.only(left: 30),
//                                   child: Text("Booking Event",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                               Row(
//                                 children: [
//                                   Container(
//                                       margin: EdgeInsets.only(left: 20),
//                                       child: Text("40/",style: TextStyle(color: Colors.black,fontSize: 18,),)),
//                                   Text("100",style: TextStyle(color: Colors.black,fontSize: 18,),)
//                                 ],
//                               )
//                             ],
//                           )
//
//
//                         ],
//                       ),
//                     ),
//
//
//                     Container(
//
//                       margin: EdgeInsets.only(top: 10,left: 20),
//                       child: Column(
//                         children: [
//                           Container(
//                               margin: EdgeInsets.only(top: 10,),
//                               alignment: Alignment.topLeft,
//
//                               child: Text("Total Check-ins.",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                           Container(
//                               alignment: Alignment.topLeft,
//                               margin: EdgeInsets.only(top: 10,left: 30),
//
//                               child: Text("40",style: TextStyle(color: Colors.black,fontSize: 30,fontWeight: FontWeight.bold),)),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Container(
//                                   margin: EdgeInsets.only(top: 20,),
//                                   alignment: Alignment.topLeft,
//                                   child: Text("Checkin Activity",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),)),
//                               // Container(
//                               //     margin: EdgeInsets.only(top: 20,right: 10),
//                               //     child: Text("12;45",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))
//                             ],
//                           ),
//
//                         ],
//                       ),
//                     ),
//                     Divider(color: Colors.grey,),
//                     // Expanded(
//                     //   child: SingleChildScrollView(
//                     //     child: FutureBuilder(
//                     //        // future: booking(selectedDate),
//                     //         builder: (context, snapshot) {
//                     //           if (!snapshot.hasData) {
//                     //             return Container(
//                     //               // color:Colors.red,
//                     //               // padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
//                     //               margin: EdgeInsets.only(top: 0),
//                     //               width: MediaQuery
//                     //                   .of(context)
//                     //                   .size
//                     //                   .width * 1.0,
//                     //               height: MediaQuery
//                     //                   .of(context)
//                     //                   .size
//                     //                   .height * 0.72,
//                     //               child: tableResponseModel.data.iTotalRecords == 0
//                     //                   ? Container(
//                     //                   margin: EdgeInsets.only(left: 20),
//                     //                   child: Center(child: Text("No Data Found !")))
//                     //                   : ListView.builder(
//                     //                   shrinkWrap: true,
//                     //                   scrollDirection: Axis.vertical,
//                     //                   itemCount:
//                     //                   tableResponseModel.data.aaData.length,
//                     //                   itemBuilder: (context, index) {
//                     //                     return GestureDetector(
//                     //                       onTap: () {
//                     //                         print(tableResponseModel
//                     //                             .data.aaData[index].checkinStatus);
//                     //                         if (tableResponseModel.data
//                     //                             .aaData[index].checkinStatus ==
//                     //                             0) {
//                     //                           print('hii');
//                     //                         } else {
//                     //
//                     //                         }
//                     //                       },
//                     //                       child:
//                     //                       Column(
//                     //                         children: [
//                     //                           Container(
//                     //                             //  margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                     //                             child: Card(
//                     //                               elevation: 5,
//                     //                               shape: RoundedRectangleBorder(
//                     //                                 borderRadius: BorderRadius.circular(
//                     //                                     10),
//                     //                               ),
//                     //                               child: Column(
//                     //                                 children: [
//                     //                                 ],
//                     //                               ),
//                     //                             ),
//                     //
//                     //                           ),
//                     //                         ],
//                     //                       ),
//                     //                     );
//                     //                   }),
//                     //             );
//                     //           }
//                     //         }),
//                     //   ),
//                     // ),
//                     Expanded(
//                       child: SingleChildScrollView(
//                         child: Column(
//                           children: [
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event    ",),
//                                   Text("12:45"),
//
//                                 ],),
//
//                             ),
//
//
//
//                             Divider(color: Colors.grey,),
//                             SizedBox(height: 2,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event1    ",),
//                                   Text("1:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event2    ",),
//                                   Text("2:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event3    ",),
//                                   Text("2:15")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event4    ",),
//                                   Text("2:30")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event5    ",),
//                                   Text("2:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event5    ",),
//                                   Text("3:00")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event5    ",),
//                                   Text("3:35")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event6    ",),
//                                   Text("3:45")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event7    ",),
//                                   Text("3:59")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//                             Container(
//                               margin: EdgeInsets.only(left: 15,right: 15),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Text("Event8    ",),
//                                   Text("4:00")
//
//                                 ],),
//
//                             ),
//                             Divider(color: Colors.grey,),
//
//
//
//
//
//
//
//
//
//
//
//                           ],
//                         ),
//
//                       ),
//                     ),
//                   ],
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//   _selectDate(BuildContext context) async {
//     DateTime newSelectedDate = await showDatePicker(
//         context: context,
//         initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
//         firstDate: DateTime(2000),
//         lastDate: DateTime(2040),
//         builder: (BuildContext context, Widget child) {
//           return Theme(
//             data: ThemeData.dark().copyWith(
//               colorScheme: ColorScheme.dark(
//                 primary: Colors.blue.shade900,
//                 onPrimary: Colors.white,
//                 surface: Colors.blue.shade900,
//                 onSurface: Colors.white,
//               ),
//               dialogBackgroundColor: Colors.blue[500],
//             ),
//             child: child,
//           );
//         });
//
//     if (newSelectedDate != null) {
//       _selectedDate = newSelectedDate;
//       final DateFormat formatter = DateFormat('yyyy-MM-dd');
//
//       final String formatted = formatter.format(_selectedDate);
//       _textEditingController1
//         ..text = formatted
//         ..selection = TextSelection.fromPosition(TextPosition(
//             offset: _textEditingController1.text.length,
//             affinity: TextAffinity.upstream));
//       print(formatted);
//       getDetails(formatted);
//     }
//   }
//
//   getEventDetails(String currentDate) {}
//
//
// }
