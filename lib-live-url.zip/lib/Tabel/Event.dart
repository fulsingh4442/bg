import 'package:bookings/api_confi/api_client.dart';
import 'package:bookings/models/details_response_model.dart';
import 'package:flutter/material.dart';

import '../models/single_item_response_model.dart';
class tabel extends StatefulWidget {


   // String bookingUid;
   // String totalRecords;
   // String guestname;
   // List<AaDatumSM> dataListSM;
   // AaDatum aaData;
   // bool fromDetails;
  // tabel(
  //     this.bookingUid,
  //     this.totalRecords,
  //     this.fromDetails, {
  //       this.dataListSM,
  //       this.aaData,
  //       this.guestname,
  //     });


  @override
  State<tabel> createState() => _tabelState();

}

class _tabelState extends State<tabel> {
  bool _checkbox = false;
  bool _checkboxListTile = false;
  bool _checkboxList = false;
  bool _checkbo = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back)),
          title: Center(
            child: Container(
              margin: EdgeInsets.only(right: 55),
                height: 40,width: 40,

                child: Image.asset('assets/images/appicon.png',color: Colors.white )),
          ),
        ),

        body: SafeArea(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 10,right: 281),

                child: Text(
                  "Table",
                  style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
                ),
              ),
              // Container(
              //   color: Colors.blue,
              //
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //     children: [
              //       InkWell(
              //         onTap: () {
              //           Navigator.pop(context);
              //           // Navigator.of(context).pushAndRemoveUntil(
              //           //     MaterialPageRoute(
              //           //         builder: (context) => ScanQrScreen()),
              //           //     (Route<dynamic> route) => false);
              //         },
              //         child: Container(
              //             padding: EdgeInsets.fromLTRB(20, 15, 0, 20),
              //             child: Icon(Icons.arrow_back_ios)),
              //       ),
              //
              //       Container(
              //         child: Text(
              //           widget.dataListSM != null
              //               ? widget.dataListSM[0].firstName +
              //               widget.dataListSM[0].lastName
              //               : widget.guestname,
              //           style: TextStyle(
              //             fontSize: 16,
              //             fontWeight: FontWeight.bold,
              //           ),
              //         ),
              //       ),
              //
              //       Container(
              //         margin: EdgeInsets.only(right: 20, bottom: 10),
              //         height: MediaQuery.of(context).size.height * 0.07,
              //         width: MediaQuery.of(context).size.width * 0.17,
              //         decoration: BoxDecoration(
              //           image: DecorationImage(
              //             fit: BoxFit.fill,
              //             image: AssetImage('assets/images/appicon.png'),
              //           ),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              // Container(
              //   child: Text(
              //     widget.dataListSM != null
              //         ? widget.dataListSM[0].firstName +
              //             widget.dataListSM[0].lastName
              //         : widget.guestname,
              //     style: TextStyle(
              //       fontSize: 16,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              // ),
              Container(
                margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      // Center(
                      //   child: Container(
                      //     child: Text("",
                      //       // widget.dataListSM != null
                      //       //     ? widget.dataListSM[0].firstName +
                      //       //     widget.dataListSM[0].lastName
                      //       //     : widget.guestname,
                      //       style: TextStyle(
                      //         fontSize: 16,
                      //         fontWeight: FontWeight.bold,
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Booking ID:",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 50),
                              child: Text(
                                "E1245",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            Container(
                              child: Text(" Date: 01/08/2022",
                                // " ${widget.bookingUid}",
                                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(

                              "Guest: ",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Container(
                              child: Text(
                                // widget.dataListSM != null
                                //     ? " ${widget.dataListSM[0].quantity??""}"
                                //     : widget.aaData != null
                                //     ? " ${widget.aaData.quantity}"
                                     "   Ashutosh Singh",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(

                              "Table:",
                              style: TextStyle(fontSize: 15,fontWeight:FontWeight.bold ),
                            ),
                            Container(
                              child: Text(
                                // widget.dataListSM != null
                                //     ? widget.dataListSM[0].events.isEmpty
                                //     ? " "
                                //     : " ${widget.dataListSM[0].events[0].name}"
                                //     : widget.aaData != null
                                //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
                                     "     VIP Area - Table 1 ",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Container(
                      //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                      //   child: Row(
                      //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //     children: [
                      //       Text(
                      //
                      //         "Date: ",
                      //         style: TextStyle(fontSize: 15),
                      //       ),
                      //
                      //       Container(
                      //         child: Text(
                      //           // widget.dataListSM != null
                      //           //     ? " ${widget.dataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
                      //           //     : widget.aaData != null
                      //           //     ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
                      //                " ",
                      //           style: TextStyle(fontSize: 15),
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(

                              "Paid Amount:",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Row(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(left: 10),
                                    height: 25,width: 20,

                                    child: Image.asset('assets/images/rr.jpg', )),
                                Container(
                                  child: Text(
                                    // widget.dataListSM != null
                                    //     ? "${widget.dataListSM[0].total??""} GBP"
                                    //     : widget.aaData != null
                                    //     ? " ${widget.aaData.total} GBP"
                                         "200GBP ",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(right: 10,),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              margin: EdgeInsets.only(right: 20,),
                              child: Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(left: 10),
                                      height: 25,width: 20,

                                      child: Image.asset('assets/images/chack.png', )),
                                  // Checkbox(
                                  //
                                  //   value: _checkbox,
                                  //   onChanged: (value) {
                                  //     setState(() {
                                  //       _checkbox = !_checkbox;
                                  //     });
                                  //   },
                                  // ),
                                  Text(' Checked: IN',style: TextStyle(fontWeight: FontWeight.bold),),
                                ],
                              ),
                            ),

                            // Container(
                            //   child: Text(
                            //     "Check In Time",
                            //     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            //   ),
                            // ),
                            Container(
                              child: Text(
                                " Time: 4:44 PM",
                                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          // checkIn(widget.bookingUid, DateTime.now().toString(), "1",
                          //     widget.fromDetails, context);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.only(bottom: 10,top: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(5)),
                                gradient: LinearGradient(colors: [
                                  Colors.black,
                                  Colors.black,
                                  Colors.black
                                ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                              ),
                              padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                              child: Text(
                                "Check In",
                                style: TextStyle(
                                    //fontSize: 20,
                                    color: Colors.white,fontWeight: FontWeight.bold
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),


              Container(
                margin: EdgeInsets.only(top: 10,right: 281),

                child: Text(
                  "Event",
                  style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
                ),
              ),

              Container(
                margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      // Center(
                      //   child: Container(
                      //     child: Text("",
                      //       // widget.aaDataListSM != null
                      //       //     ? (widget.aaDataListSM[0].firstName ?? "") +
                      //       //     (widget.aaDataListSM[0].lastName ?? "")
                      //       //     : widget.guestname,
                      //       style: TextStyle(
                      //         fontSize: 16,
                      //         fontWeight: FontWeight.bold,
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,

                          children: [

                            Row(
                              children: [
                                Text(
                                  "Booking ID:",
                                  style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "  Et2345 ",
                                  style: TextStyle(fontSize: 15),
                                ),
                              ],
                            ),


                            Container(
                              child: Text(" Date: 01/08/2022",
                                // " ${widget.bookingUid}",
                                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [

                            Text(

                              "Guest:",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Container(
                              child: Text(
                                // widget.aaDataListSM != null
                                //     ? " ${widget.aaDataListSM[0].quantity??""}"
                                //     : widget.aaData != null
                                //     ? " ${widget.aaData.quantity}"
                                     "   Ashutosh Singh ",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                          //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [

                            Text(

                              "Event:",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Container(
                              child: Text(
                                // widget.aaDataListSM != null
                                //     ? widget.aaDataListSM[0].events.isEmpty
                                //     ? " "
                                //     : "Event Name: ${widget.aaDataListSM[0].events[0].name}"
                                //     : widget.aaData != null
                                //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
                                     "  AFROBASH - 1st Belease  ",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Container(
                      //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                      //   child: Row(
                      //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //     children: [
                      //
                      //       Text(
                      //
                      //         "No of Guerts:  6 ",
                      //         style: TextStyle(fontSize: 15),
                      //       ),
                      //       Container(
                      //         child: Text("Check in guert:  6"
                      //           // widget.aaDataListSM != null
                      //           //     ? " ${widget.aaDataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
                      //           //     : widget.aaData != null
                      //           //     ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
                      //                " ",
                      //           style: TextStyle(fontSize: 15),
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(

                              "Paid Amount :",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                            ),
                            Row(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(left: 10),
                                    height: 25,width: 20,

                                    child: Image.asset('assets/images/rr.jpg', )),
                                Container(
                                  child: Text(
                                    // widget.aaDataListSM != null
                                    //     ? "${widget.aaDataListSM[0].total??""} GBP"
                                    //     : widget.aaData != null
                                    //     ? " ${widget.aaData.total} GBP"
                                         "100GBP ",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(left: 10,top: 10,right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(

                              child: Text(
                                "No of Guest: 5",
                                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                              ),
                            ),

                            Container(

                              child: Text(
                                " Chacked: In Guest: 4",
                                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                              ),
                            ),


                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          // checkIn(widget.bookingUid, DateTime.now().toString(), "1",
                          //     widget.fromDetails, context);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.only(bottom: 10,top: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(5)),
                                gradient: LinearGradient(colors: [
                                  Colors.black,
                                  Colors.black,
                                  Colors.black
                                ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                              ),
                              padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                              child: Text(
                                "Check In",
                                style: TextStyle(
                                  //fontSize: 20,
                                    color: Colors.white,fontWeight: FontWeight.bold
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Row(
                      //   children: [
                      //     Container(
                      //       child: Text(
                      //         widget.aaDataListSM != null
                      //             ? "Checked In Time: ${widget.aaDataListSM[0].arrivedAt??""}"
                      //             : widget.aaData != null
                      //                 ? "Checked In Time: ${widget.aaData.arrivedAt}"
                      //                 : "Checked In Time: ",
                      //         style: TextStyle(fontSize: 15),
                      //       ),
                      //     ),
                      //   ],
                      // ),
                    ],
                  ),
                ),
              ),
              // InkWell(
              //   onTap: () {
              //     // Navigator.of(context).pushAndRemoveUntil(
              //     //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
              //     //         (Route<dynamic> route) => false);
              //   },
              //   child: Container(
              //     decoration: BoxDecoration(
              //       color: Colors.amber,
              //       borderRadius: BorderRadius.all(Radius.circular(8)),
              //       gradient: LinearGradient(colors: [
              //         Colors.black,
              //         Colors.black,
              //         Colors.black
              //       ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              //     ),
              //     padding: EdgeInsets.fromLTRB(130, 8, 130, 8),
              //     child: Text(
              //       "Check in ",
              //       style: TextStyle(
              //         fontSize: 20,
              //         color: Colors.white,fontWeight: FontWeight.bold
              //       ),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}


//
// import 'dart:convert';
// import 'package:bookings/api_confi/api_client.dart';
// import 'package:bookings/models/Table_Response_model.dart';
// import 'package:bookings/models/single_item_response_model.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';
// import 'package:http/http.dart' as http;
// import 'package:http/http.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import 'models/details_response_model.dart';
//
// class Event_Screen1 extends StatefulWidget {
//   //const Event_Screen1({Key key}) : super(key: key);
//
//   String bookingUid;
//   String totalRecords;
//   String guestname;
//   List<AaDatumSM> dataListSM;
//   AaDatum aaData;
//   bool fromDetails;
//   // tabel(
//   //     this.bookingUid,
//   //     this.totalRecords,
//   //     this.fromDetails, {
//   //       this.dataListSM,
//   //       this.aaData,
//   //       this.guestname,
//   //     });
//
//
//   @override
//   _Event_Screen1State createState() => _Event_Screen1State();
// }
//
// class _Event_Screen1State extends State<Event_Screen1> {
//
//   //  // postApidata() async{
//   //  //   var url = Uri.parse("https://app-api.teaseme.co.in/api/booking");
//   //  //   Response responce = await http.post(url);
//   //  //   print(responce);
//   //  //     headers: <String, String>{
//   //  //       'Content-Type': 'application/json; charset=UTF-8',
//   //  //       'token':"7cff459d59d2210b5c484d5475bad947 ",
//   //  //     },
//   //  //     body: jsonEncode(<String, String>{
//   //  //       'booking_id':"LIZ10025 ",
//   //  //     }),
//   //
//   //
//   //
//   // // List<EventResponsemodelclass> eventResponse = [];
//   //
//   //    if(responce.statusCode== 200){
//   //      print(true);
//   //      final data=jsonDecode(responce.body);
//   //      print(data);
//   //      final
//   //      // var status=data["status"];
//   //      // var message=data["message"];
//   //      // String responceBody = responce.body;
//   //      // var jsonBody = json.decode(responceBody);
//   //      // for(var data in jsonBody){
//   //      //   eventResponse.add(new EventResponsemodelclass(
//   //      //       data['date'],data['id'],data['quantity'],data['paid_amount'],data['booking_uid'],data['arrived_at'],
//   //      //     data['checkin_status'],data['name'],data[''],data['guest'],data['checkin_time'],data[''],data[''],));
//   //      // }
//   //     //  if(status== true){
//   //     //    print(status);
//   //     //  //  print(message);
//   //     //    return EventResponsemodelclass.fromJson(data);
//   //     //
//   //     //  }
//   //     // else{
//   //
//   //
//   //     // }
//   //    }
//   //    else{
//   //      print("failuer2");
//   //     // return EventResponsemodelclass.fromJson(data);
//   //    }
//   //  }
//
//   SharedPreferences Response;
//
//   String token;
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     initial();
//   }
//
//   void initial() async {
//     Response = await SharedPreferences.getInstance();
//     setState(() {
//       token =Response.getString('token').toString();
//     });
//   }
//
//
//
//
//
//   Future<TableResponseModel> booking()async {
//     http.Response responce = await http.post(
//       Uri.parse("https://app-api.teaseme.co.in/api/booking"),
//       headers: <String, String>{
//         //'Content-Type': 'application/json; charset=UTF-8',
//         'token':token
//
//       },
//       body: (<String, String>{
//         'booking_id': "LIZ10001",
//       }),
//     );
//     var data = jsonDecode(responce.body.toString());
//     var status = data["status"];
//     if (responce.statusCode == 200) {
//       print(responce.body);
//       // print(data);
//       print(token);
//
//
//       if (status == true) {
//         return TableResponseModel.fromJson(data);
//       } else {
//         return TableResponseModel.fromJson(data);
//       }
//     } else {
//       return TableResponseModel.fromJson(data);
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     // String _formatted=DateFormat.yMMMd().format(DateTime.now());
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.black,
//         leading: InkWell(
//             onTap: () {
//               Navigator.pop(context);
//             },
//             child: Icon(Icons.arrow_back)),
//         title: Center(
//           child: Container(
//               margin: EdgeInsets.only(right: 55),
//               height: 45,width: 45,
//
//               child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
//         ),
//       ),
//       backgroundColor: Colors.white,
//       body: SafeArea(
//         child: Container(
//           margin: EdgeInsets.only(left: 5,right: 5),
//           child: Column(
//             children: [ Expanded(
//               child: FutureBuilder<TableResponseModel>(
//                   future: booking(),
//                   builder: (context, snapshot) {
//                     if (!snapshot.hasData) {
//                       return Center(child: CircularProgressIndicator());
//                     } else {
//                       return ListView.builder(
//                           itemCount: snapshot.data.data.length ,
//                           itemBuilder: (context, index) {
//                             return
//                               Column(
//                                 children: [
//                                   Container(
//                                     margin: EdgeInsets.only(
//                                         top: 10, right: 281),
//
//                                     child: Text(
//                                       "Table",
//                                       style: TextStyle(fontSize: 20,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//                                   // Container(
//                                   //   color: Colors.blue,
//                                   //
//                                   //   child: Row(
//                                   //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   //     children: [
//                                   //       InkWell(
//                                   //         onTap: () {
//                                   //           Navigator.pop(context);
//                                   //           // Navigator.of(context).pushAndRemoveUntil(
//                                   //           //     MaterialPageRoute(
//                                   //           //         builder: (context) => ScanQrScreen()),
//                                   //           //     (Route<dynamic> route) => false);
//                                   //         },
//                                   //         child: Container(
//                                   //             padding: EdgeInsets.fromLTRB(20, 15, 0, 20),
//                                   //             child: Icon(Icons.arrow_back_ios)),
//                                   //       ),
//                                   //
//                                   //       Container(
//                                   //         child: Text(
//                                   //           widget.dataListSM != null
//                                   //               ? widget.dataListSM[0].firstName +
//                                   //               widget.dataListSM[0].lastName
//                                   //               : widget.guestname,
//                                   //           style: TextStyle(
//                                   //             fontSize: 16,
//                                   //             fontWeight: FontWeight.bold,
//                                   //           ),
//                                   //         ),
//                                   //       ),
//                                   //
//                                   //       Container(
//                                   //         margin: EdgeInsets.only(right: 20, bottom: 10),
//                                   //         height: MediaQuery.of(context).size.height * 0.07,
//                                   //         width: MediaQuery.of(context).size.width * 0.17,
//                                   //         decoration: BoxDecoration(
//                                   //           image: DecorationImage(
//                                   //             fit: BoxFit.fill,
//                                   //             image: AssetImage('assets/images/appicon.png'),
//                                   //           ),
//                                   //         ),
//                                   //       ),
//                                   //     ],
//                                   //   ),
//                                   // ),
//                                   // Container(
//                                   //   child: Text(
//                                   //     widget.dataListSM != null
//                                   //         ? widget.dataListSM[0].firstName +
//                                   //             widget.dataListSM[0].lastName
//                                   //         : widget.guestname,
//                                   //     style: TextStyle(
//                                   //       fontSize: 16,
//                                   //       fontWeight: FontWeight.bold,
//                                   //     ),
//                                   //   ),
//                                   // ),
//                                   Container(
//                                     margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                                     child: Card(
//                                       elevation: 5,
//                                       shape: RoundedRectangleBorder(
//                                         borderRadius: BorderRadius.circular(
//                                             10),
//                                       ),
//                                       child: Column(
//                                         children: [
//                                           // Center(
//                                           //   child: Container(
//                                           //     child: Text("",
//                                           //       // widget.dataListSM != null
//                                           //       //     ? widget.dataListSM[0].firstName +
//                                           //       //     widget.dataListSM[0].lastName
//                                           //       //     : widget.guestname,
//                                           //       style: TextStyle(
//                                           //         fontSize: 16,
//                                           //         fontWeight: FontWeight.bold,
//                                           //       ),
//                                           //     ),
//                                           //   ),
//                                           // ),
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment
//                                                   .spaceBetween,
//                                               children: [
//                                                 Text(
//                                                   "Booking ID:",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Container(
//                                                   margin: EdgeInsets.only(
//                                                       right: 50),
//                                                   child: Text(snapshot.data.data[index].bookingUid.toString(),
//                                                     // "E1245",
//                                                     style: TextStyle(
//                                                         fontSize: 15),
//                                                   ),
//                                                 ),
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                       child: Text(
//                                                         " Date:",
//                                                         // " ${widget.bookingUid}",
//                                                         style: TextStyle(
//                                                             fontSize: 15,
//                                                             fontWeight: FontWeight
//                                                                 .bold),
//                                                       ),
//                                                     ),
//                                                     Text(snapshot.data.data[index].date.toString(),
//
//                                                       // " ${widget.bookingUid}",
//                                                       style: TextStyle(
//                                                           fontSize: 15,
//                                                           fontWeight: FontWeight
//                                                               .bold),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Text(
//
//                                                   "Guest: ",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(snapshot.data.data[index].guest.toString(),
//                                                     // widget.dataListSM != null
//                                                     //     ? " ${widget.dataListSM[0].quantity??""}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.quantity}"
//                                                     // "   Ashutosh Singh",
//                                                     style: TextStyle(
//                                                         fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Text(
//
//                                                   "Table:",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(snapshot.data.data[index].name.toString(),
//                                                     // widget.dataListSM != null
//                                                     //     ? widget.dataListSM[0].events.isEmpty
//                                                     //     ? " "
//                                                     //     : " ${widget.dataListSM[0].events[0].name}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
//                                                     // "     VIP Area - Table 1 ",
//                                                     style: TextStyle(
//                                                         fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           // Container(
//                                           //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                           //   child: Row(
//                                           //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                           //     children: [
//                                           //       Text(
//                                           //
//                                           //         "Date: ",
//                                           //         style: TextStyle(fontSize: 15),
//                                           //       ),
//                                           //
//                                           //       Container(
//                                           //         child: Text(
//                                           //           // widget.dataListSM != null
//                                           //           //     ? " ${widget.dataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
//                                           //           //     : widget.aaData != null
//                                           //           //     ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
//                                           //                " ",
//                                           //           style: TextStyle(fontSize: 15),
//                                           //         ),
//                                           //       ),
//                                           //     ],
//                                           //   ),
//                                           // ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Text(
//
//                                                   "Paid Amount:",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                         margin: EdgeInsets
//                                                             .only(left: 10),
//                                                         height: 25, width: 20,
//
//                                                         child: Image.asset(
//                                                           'assets/images/rr.jpg',)),
//                                                     Container(
//                                                       child: Text(snapshot.data.data[index].paidAmount.toString(),
//                                                         // widget.dataListSM != null
//                                                         //     ? "${widget.dataListSM[0].total??""} GBP"
//                                                         //     : widget.aaData != null
//                                                         //     ? " ${widget.aaData.total} GBP"
//                                                         // "200GBP ",
//                                                         style: TextStyle(
//                                                             fontSize: 15),
//                                                       ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Column(
//                                               children: [
//                                                 if(snapshot.data.data
//                                                 [index].checkinStatus ==
//                                                     "0")...{
//                                                   // checkin_status == 0;
//                                                   Container(
//                                                     margin: EdgeInsets.only(right: 10,bottom: 10),
//                                                     child: Row(
//                                                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                                       children: [
//                                                         Container(
//                                                           margin: EdgeInsets.only(right: 20,),
//                                                           child: Row(
//                                                             children: [
//                                                               Container(
//                                                                   margin: EdgeInsets.only(left: 10),
//                                                                   height: 25,width: 20,
//
//                                                                   child: Image.asset('assets/images/chack.png', )),
//                                                               // Checkbox(
//                                                               //
//                                                               //   value: _checkbox,
//                                                               //   onChanged: (value) {
//                                                               //     setState(() {
//                                                               //       _checkbox = !_checkbox;
//                                                               //     });
//                                                               //   },
//                                                               // ),
//                                                               Text(' Checked: IN',style: TextStyle(fontWeight: FontWeight.bold),),
//                                                             ],
//                                                           ),
//                                                         ),
//
//                                                         // Container(
//                                                         //   child: Text(
//                                                         //     "Check In Time",
//                                                         //     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                         //   ),
//                                                         // ),
//                                                         Container(
//                                                           child: Text(snapshot.data.data[index].checkinTime.toString(),
//
//                                                             style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                           ),
//                                                         ),
//                                                       ],
//                                                     ),
//                                                   ),
//
//
//
//                                                   // InkWell(
//                                                   //   onTap: () async{
//                                                   //
//                                                   //     // if (!checkin_status) {
//                                                   //     //   checkin_status = true;
//                                                   //     //   // await Your normal function
//                                                   //     // } else {
//                                                   //     //   var isClicked;
//                                                   //     //   isClicked.show(
//                                                   //     //       "You click already on this button", context,
//                                                   //     //       duration: isClicked.LENGTH_LONG, gravity: isClicked.BOTTOM);
//                                                   //     // }
//                                                   //     // check1In(widget.bookingUid, DateTime.now().toString(), "1",
//                                                   //     //     widget.fromDetails, context);
//                                                   //   },
//                                                   //
//                                                   //   child: Row(
//                                                   //     mainAxisAlignment: MainAxisAlignment.center,
//                                                   //     children: [
//                                                   //       Container(
//                                                   //         margin: EdgeInsets.only(bottom: 10,top: 10),
//                                                   //         decoration: BoxDecoration(
//                                                   //           borderRadius: BorderRadius.all(Radius.circular(5)),
//                                                   //           gradient: LinearGradient(colors: [
//                                                   //             Colors.black,
//                                                   //             Colors.black,
//                                                   //             Colors.black
//                                                   //           ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                                                   //         ),
//                                                   //         padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
//                                                   //         child: Text(
//                                                   //           "Check In",
//                                                   //           style: TextStyle(
//                                                   //             //fontSize: 20,
//                                                   //               color: Colors.white,fontWeight: FontWeight.bold
//                                                   //           ),
//                                                   //         ),
//                                                   //       ),
//                                                   //     ],
//                                                   //   ),
//                                                   // ),
//                                                 }else...{
//                                                   // Container(
//                                                   //   margin: EdgeInsets.only(right: 10,bottom: 10),
//                                                   //   child: Row(
//                                                   //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                                   //     children: [
//                                                   //       Container(
//                                                   //         margin: EdgeInsets.only(right: 20,),
//                                                   //         child: Row(
//                                                   //           children: [
//                                                   //             Container(
//                                                   //                 margin: EdgeInsets.only(left: 10),
//                                                   //                 height: 25,width: 20,
//                                                   //
//                                                   //                 child: Image.asset('assets/images/chack.png', )),
//                                                   //             // Checkbox(
//                                                   //             //
//                                                   //             //   value: _checkbox,
//                                                   //             //   onChanged: (value) {
//                                                   //             //     setState(() {
//                                                   //             //       _checkbox = !_checkbox;
//                                                   //             //     });
//                                                   //             //   },
//                                                   //             // ),
//                                                   //             Text(' Checked: IN',style: TextStyle(fontWeight: FontWeight.bold),),
//                                                   //           ],
//                                                   //         ),
//                                                   //       ),
//                                                   //
//                                                   //       // Container(
//                                                   //       //   child: Text(
//                                                   //       //     "Check In Time",
//                                                   //       //     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                   //       //   ),
//                                                   //       // ),
//                                                   //       Container(
//                                                   //         child: Text(snapshot.data.data[index].checkinTime.toString(),
//                                                   //
//                                                   //           style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                   //         ),
//                                                   //       ),
//                                                   //     ],
//                                                   //   ),
//                                                   // ),
//                                                   InkWell(
//                                                     onTap: () {
//                                                       checkIn(widget.bookingUid, DateTime.now().toString(), "1",
//                                                           widget.fromDetails, context);
//                                                     },
//
//                                                     child: Row(
//                                                       mainAxisAlignment: MainAxisAlignment.center,
//                                                       children: [
//                                                         Container(
//                                                           margin: EdgeInsets.only(bottom: 10,top: 10),
//                                                           decoration: BoxDecoration(
//                                                             borderRadius: BorderRadius.all(Radius.circular(5)),
//                                                             gradient: LinearGradient(colors: [
//                                                               Colors.black,
//                                                               Colors.black,
//                                                               Colors.black
//                                                             ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                                                           ),
//                                                           padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
//                                                           child: Text(
//                                                             "Check In",
//                                                             style: TextStyle(
//                                                               //fontSize: 20,
//                                                                 color: Colors.white,fontWeight: FontWeight.bold
//                                                             ),
//                                                           ),
//                                                         ),
//                                                       ],
//                                                     ),
//                                                   ),
//                                                 }
//                                               ]),
//
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//
//
//                                   Container(
//                                     margin: EdgeInsets.only(
//                                         top: 10, right: 281),
//
//                                     child: Text(
//                                       "Event",
//                                       style: TextStyle(fontSize: 20,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//
//                                   Container(
//                                     margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                                     child: Card(
//                                       elevation: 5,
//                                       shape: RoundedRectangleBorder(
//                                         borderRadius: BorderRadius.circular(
//                                             10),
//                                       ),
//                                       child: Column(
//                                         children: [
//                                           // Center(
//                                           //   child: Container(
//                                           //     child: Text("",
//                                           //       // widget.aaDataListSM != null
//                                           //       //     ? (widget.aaDataListSM[0].firstName ?? "") +
//                                           //       //     (widget.aaDataListSM[0].lastName ?? "")
//                                           //       //     : widget.guestname,
//                                           //       style: TextStyle(
//                                           //         fontSize: 16,
//                                           //         fontWeight: FontWeight.bold,
//                                           //       ),
//                                           //     ),
//                                           //   ),
//                                           // ),
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment
//                                                   .spaceBetween,
//
//                                               children: [
//
//                                                 Row(
//                                                   children: [
//                                                     Text(
//                                                       "Booking ID:",
//                                                       style: TextStyle(
//                                                           fontSize: 15,
//                                                           fontWeight: FontWeight
//                                                               .bold),
//                                                     ),
//                                                     Text(snapshot.data.data[index].bookingUid.toString(),
//
//                                                       style: TextStyle(
//                                                           fontSize: 15),
//                                                     ),
//                                                   ],
//                                                 ),
//
//
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                       child: Text(
//                                                         " Date:",
//                                                         // " ${widget.bookingUid}",
//                                                         style: TextStyle(
//                                                             fontSize: 15,
//                                                             fontWeight: FontWeight
//                                                                 .bold),
//                                                       ),
//                                                     ),
//                                                     Text(snapshot.data.data[index].date.toString(),
//
//                                                       // " ${widget.bookingUid}",
//                                                       style: TextStyle(
//                                                           fontSize: 15,
//                                                           fontWeight: FontWeight
//                                                               .bold),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//
//                                                 Text(
//
//                                                   "Guest:",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(snapshot.data.data[index].guest.toString(),
//                                                     // widget.aaDataListSM != null
//                                                     //     ? " ${widget.aaDataListSM[0].quantity??""}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.quantity}"
//                                                     // "   Ashutosh Singh ",
//                                                     style: TextStyle(
//                                                         fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               //mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//
//                                                 Text(
//
//                                                   "Event:",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(snapshot.data.data[index].name.toString(),
//                                                     // widget.aaDataListSM != null
//                                                     //     ? widget.aaDataListSM[0].events.isEmpty
//                                                     //     ? " "
//                                                     //     : "Event Name: ${widget.aaDataListSM[0].events[0].name}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
//                                                     // "  AFROBASH - 1st Belease  ",
//                                                     style: TextStyle(
//                                                         fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           // Container(
//                                           //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                           //   child: Row(
//                                           //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                           //     children: [
//                                           //
//                                           //       Text(
//                                           //
//                                           //         "No of Guerts:  6 ",
//                                           //         style: TextStyle(fontSize: 15),
//                                           //       ),
//                                           //       Container(
//                                           //         child: Text("Check in guert:  6"
//                                           //           // widget.aaDataListSM != null
//                                           //           //     ? " ${widget.aaDataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
//                                           //           //     : widget.aaData != null
//                                           //           //     ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
//                                           //                " ",
//                                           //           style: TextStyle(fontSize: 15),
//                                           //         ),
//                                           //       ),
//                                           //     ],
//                                           //   ),
//                                           // ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Text(
//
//                                                   "Paid Amount :",
//                                                   style: TextStyle(
//                                                       fontSize: 15,
//                                                       fontWeight: FontWeight
//                                                           .bold),
//                                                 ),
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                         margin: EdgeInsets
//                                                             .only(left: 10),
//                                                         height: 25, width: 20,
//
//                                                         child: Image.asset(
//                                                           'assets/images/rr.jpg',)),
//                                                     Container(
//                                                       child: Text(snapshot.data.data[index].paidAmount.toString(),
//                                                         // widget.aaDataListSM != null
//                                                         //     ? "${widget.aaDataListSM[0].total??""} GBP"
//                                                         //     : widget.aaData != null
//                                                         //     ? " ${widget.aaData.total} GBP"
//                                                         //"100GBP ",
//                                                         style: TextStyle(
//                                                             fontSize: 15),
//                                                       ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(
//                                                 left: 10, top: 10, right: 10),
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment
//                                                   .spaceBetween,
//                                               children: [
//                                                 Container(
//
//                                                   child: Text(
//                                                     "No of Guest: 5",
//                                                     style: TextStyle(
//                                                         fontSize: 15,
//                                                         fontWeight: FontWeight
//                                                             .bold),
//                                                   ),
//                                                 ),
//
//                                                 Container(
//
//                                                   child: Text(snapshot.data.data[index].checkinStatus.toString(),
//                                                     //  " Chacked: In Guest: 4",
//                                                     style: TextStyle(
//                                                         fontSize: 15,
//                                                         fontWeight: FontWeight
//                                                             .bold),
//                                                   ),
//                                                 ),
//
//
//                                               ],
//                                             ),
//                                           ),
//                                           InkWell(
//                                             onTap: () {
//                                               // checkIn(widget.bookingUid, DateTime.now().toString(), "1",
//                                               //     widget.fromDetails, context);
//                                             },
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment
//                                                   .center,
//                                               children: [
//                                                 Container(
//                                                   margin: EdgeInsets.only(
//                                                       bottom: 10, top: 10),
//                                                   decoration: BoxDecoration(
//                                                     borderRadius: BorderRadius
//                                                         .all(
//                                                         Radius.circular(5)),
//                                                     gradient: LinearGradient(
//                                                         colors: [
//                                                           Colors.black,
//                                                           Colors.black,
//                                                           Colors.black
//                                                         ],
//                                                         begin: Alignment
//                                                             .topCenter,
//                                                         end: Alignment
//                                                             .bottomCenter),
//                                                   ),
//                                                   padding: EdgeInsets
//                                                       .fromLTRB(
//                                                     135, 10, 135, 10,),
//                                                   child: Text(
//                                                     "Check In",
//                                                     style: TextStyle(
//                                                       //fontSize: 20,
//                                                         color: Colors.white,
//                                                         fontWeight: FontWeight
//                                                             .bold
//                                                     ),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//
//
//                                 ],
//                               );
//                           }
//
//
//
//
//
//
//
//                       );
//                     }
//                   }
//
//
//
//               ),
//             ),
//
//
//
//
//             ],
//           ),
//
//         ),
//       ),
//     );
//   }
//
// }



