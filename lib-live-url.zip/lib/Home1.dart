
import 'package:bookings/Event_Screen.dart';
import 'package:bookings/Login.dart';
import 'package:bookings/Tabel/Event.dart';
import 'package:bookings/Tabel/Totle_Rekod.dart';
import 'package:bookings/Table_Screen.dart';
import 'package:bookings/demoScreen.dart';
import 'package:bookings/screens/details.dart';
import 'package:bookings/screens/homeScreen.dart';
import 'package:bookings/screens/scan_qr.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
class home extends StatefulWidget {

  const home({Key key}) : super(key: key);


  @override
  _homeState createState() => _homeState();
}
class _homeState extends State<home> {

   SharedPreferences Response;
    String username;
     String email;
    String token;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initial();
  }

  void initial() async {
    Response = await SharedPreferences.getInstance();
    setState(() {
      username =Response.getString('username');
      token =Response.getString('token');
      email =Response.getString('email');
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
     // backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Center(
        child: Container(
          margin: EdgeInsets.only(right: 55),
        height: 40,width: 40,

        child: Image.asset('assets/images/appicon.png',color: Colors.white )),
    ),
        //title: Text("Lizard_Lounge",style: TextStyle(fontWeight: FontWeight.bold),),
    ),

      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 5,),
                  width: MediaQuery.of(context).size.width * 1.0,
                 // height: MediaQuery.of(context).size.height * 0.07,
                  child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,


                  children: [

                    Container(
                      margin: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width * 0.4,
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (context) => Table_Screen()),);

                        },
                        child: Card(
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Column(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(top: 10),
                                    height: 60,width: 60,

                                    child: Image.asset('assets/images/t.jpg', )),
                                SizedBox(height: 0,),
                                Container(
                                  margin: EdgeInsets.only(bottom: 30),
                                  child: Center(
                                    child: Column(
                                      children: [
                                        Text("Table",
                                          style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                        ),
                                        Text("Booking",
                                          style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),






                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 20),
                      width: MediaQuery.of(context).size.width * 0.4,
                      child:  InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (context) => Event_Screen()),);

                        },
                        child: Card(
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Column(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(top: 10),
                                    height: 60,width: 60,

                                    child: Image.asset('assets/images/eeeee.jpg', )),
                                SizedBox(height: 0,),

                                Container(
                                  margin: EdgeInsets.only(bottom: 30),
                                  child: Center(
                                    child: Column(
                                      children: [
                                        Text("Event",
                                            style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                          ),
                                        Text("Booking ",
                                          style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                        ),

                                      ],
                                    ),
                                  ),
                                ),






                              ],
                            ),
                          ),
                        ),
                      ),
                    ),

                ],),
                ),
                Container(
                  margin: EdgeInsets.only(top: 10,left: 50,right: 50),
                 // width: MediaQuery.of(context).size.width * 1.0,
                   height: MediaQuery.of(context).size.height * 0.4,
                  child:
                      Container(
                      //  margin: EdgeInsets.only(left: 10,),


                       // width: MediaQuery.of(context).size.width * 0.3,
                        child:  InkWell(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => ScanQrScreen()),);

                          },
                          child: Card(
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Column(
                                children: [
                                  Container(
                                     // margin: EdgeInsets.only(top: 10),
                                    //  height: 180,width: 200,

                                      child: Image.asset('assets/images/q.png',fit: BoxFit.fill, )),
                                  // SizedBox(height: 0,),
                                  //
                                  // Container(
                                  //   margin: EdgeInsets.only(bottom: 30),
                                  //   child: Center(
                                  //     child: Column(
                                  //       children: [
                                  //         Text("Scan ",
                                  //           style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                  //         ),
                                  //         Text("Booking",
                                  //           style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                  //         ),
                                  //       ],
                                  //     ),
                                  //   ),
                                  // ),






                                ],
                              ),
                            ),
                          ),
                        ),
                      ),


                ),

                // Container(
                //   alignment: Alignment.topLeft,
                //
                //   margin: EdgeInsets.only(right: 170,top: 10),
                //   width: MediaQuery.of(context).size.width * 0.4,
                //   child:  InkWell(
                //     onTap: () {
                //      //Navigator.of(context).push(MaterialPageRoute(builder: (context) =>DetailsScreen1()),);
                //
                //     },
                //     child: Card(
                //
                //
                //       elevation: 5,
                //       shape: RoundedRectangleBorder(
                //         borderRadius: BorderRadius.circular(10),
                //       ),
                //       child: Center(
                //         child: Column(
                //           children: [
                //             Container(
                //                 margin: EdgeInsets.only(top: 10),
                //                 height: 80,width: 80,
                //
                //                 child: Image.asset('assets/images/Membership.jpeg', )),
                //             SizedBox(height: 0,),
                //
                //             Container(
                //               margin: EdgeInsets.only(bottom: 30),
                //               child: Center(
                //                 child: Column(
                //                   children: [
                //                     Text("Membership",
                //                       style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                //                     ),
                //                     // Text("Booking ",
                //                     //   style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                //                     // ),
                //
                //                   ],
                //                 ),
                //               ),
                //             ),
                //
                //
                //
                //
                //
                //
                //           ],
                //         ),
                //
                //     ),
                //   ),
                // ),
                // ),

              ],
            ),
          ),
        ),
      ),



      drawer: Container(
        width: MediaQuery.of(context).size.width * 0.6,
        child: Drawer(
          child: ListView(

            children: [


              Container(
                height: MediaQuery.of(context).size.height * 0.23,
                child: const UserAccountsDrawerHeader( // <-- SEE HERE
                  decoration: BoxDecoration(color: Colors.black),
                  accountName: Text( "username",
                   // "Ashutosh Singh",

                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  accountEmail: Text(
                   // '$email',
                   "AshutoshSingh@gmail.com",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),




                  currentAccountPicture:CircleAvatar(

                      backgroundColor: Colors.white,
                      backgroundImage:AssetImage('assets/images/appicon.png',)),


                  // CircleAvatar(backgroundImage: AssetImage('assets/images/appicon.png',),
                  //   radius: 35,),
                ),
              ),
              Column(
                children: [
                  Container(
                    height: 35,
                    child: ListTile(
                    //   leading: Icon(
                    //   Icons.home,
                    // ),
                      title: const Text('Home'),
                      onTap: () {
                        Navigator.pop(context);
                      },

                    ),
                  ),
                  Divider(),


              Container(
                height: 35,
                child: ListTile(

                //   leading: Icon(
                //   Icons.home,
                // ),
                  title: const Text('Booking scanner'),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => ScanQrScreen()),);
                  },

                ),
              ),
                  Divider(),
              Container(
                height: 35,
                child: ListTile(
                  //   leading: Icon(
                  //   Icons.home,
                  // ),
                  title: const Text('Table Booking'),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => Table_Screen()),);
                  },

                ),
              ),
                  Divider(),
              Container(
                height: 35,
                child: ListTile(
                  //   leading: Icon(
                  //   Icons.home,
                  // ),
                  title: const Text('Event Booking'),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => Event_Screen()),);
                  },

                ),
              ),
                  Divider(),

                  Container(
                    height: 35,
                    child: ListTile(
                      //   leading: Icon(
                      //   Icons.home,
                      // ),
                      title: const Text('Share'),
                      onTap: () {
                        Share.share('check out my website https://example.com', subject: 'Look what I made!');

                      },

                    ),
                  ),
                  // Divider(),
                  // Container(
                  //   height: 35,
                  //   child: ListTile(
                  //     //   leading: Icon(
                  //     //   Icons.home,
                  //     // ),
                  //     title: const Text('Check in event/table '),
                  //     onTap: () {
                  //       Navigator.pushReplacement(context,
                  //           MaterialPageRoute(builder: (BuildContext ctx) => Totle_Rekod()));
                  //
                  //
                  //     },
                  //
                  //   ),
                  // ),
                  Divider(),
                  Container
                    (

                    padding: EdgeInsets.only(right: 130 ),
                    child: TextButton(onPressed: ()


                    {
                      showDialog(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: Column(
                            children: [
                              Container(
                                  margin: EdgeInsets.only(right: 80,bottom: 20),

                                  child: Text("Choose Options")),

                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,

                                children: [


                                  Container(
                                    //margin: EdgeInsets.only(left: 10,top: 10),
                                    height: 40,
                                    width: 100,

                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(5)),
                                      gradient: LinearGradient(colors: [
                                        Colors.black,
                                        Colors.black,
                                        Colors.black
                                      ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                    ),
                                    child: TextButton(
                                      onPressed: () async {
                                        SharedPreferences prefs = await SharedPreferences.getInstance();
                                        prefs.remove('email');
                                        Navigator.pushReplacement(context,
                                            MaterialPageRoute(builder: (BuildContext ctx) => Login()));
                                      },


                                        child: Text("Logout",style: TextStyle(fontSize: 15,color: Colors.white),
                                        ),

                                    ),
                                  ),

                                  Container(
                                    height: 40,
                                      width: 100,

                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(5)),
                                      gradient: LinearGradient(colors: [
                                        Colors.black,
                                        Colors.black,
                                        Colors.black
                                      ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                    ),

                                    child: TextButton(
                                      onPressed: () {
                                        Navigator.of(ctx).pop();
                                      },
                                      child: Text("Cancle",style: TextStyle(fontSize: 15,color: Colors.white)),
                                    ),
                                  ),


                                ],
                              ),

                            ],
                          ),

                        ),
                      );
                    },
                      // {
                      //   SharedPreferences prefs = await SharedPreferences.getInstance();
                      //   prefs.remove('email');
                      //   Navigator.pushReplacement(context,
                      //       MaterialPageRoute(builder: (BuildContext ctx) => Login()));
                      // },
                      child: Text("Logout",style: TextStyle(fontSize: 15,color: Colors.black87),
                      ),
                    ),
                  ),

















// Container(
                  //   height: 35,
                  //   child: ListTile(
                  //     //   leading: Icon(
                  //     //   Icons.home,
                  //     // ),
                  //     title: const Text('Logout'),
                  //     onTap: () {
                  //       Navigator.pop(context);
                  //     },
                  //
                  //   ),
                  // ),
                  Divider(),
                  ]
              ),







            ],


          ),

        ),
      ),
    );

  }
}
