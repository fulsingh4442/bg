import 'dart:convert';
/// status : true
/// data : [{"id":3,"date":"02-07-2022","quantity":"2","paid_amount":"Â£0","booking_uid":"LIZ10025","arrived_at":null,"checkin_status":0,"name":"Free ticket - I love Old skool","guest":null,"checkin_time":"","type":"event"}]

EventResponsemodelclass eventResponsemodelclassFromJson(String str) => EventResponsemodelclass.fromJson(json.decode(str));
String eventResponsemodelclassToJson(EventResponsemodelclass data) => json.encode(data.toJson());
class EventResponsemodelclass {
  EventResponsemodelclass( {
      bool status,
      List<Data> data,}){
    _status = status;
    _data = data;
}

  EventResponsemodelclass.fromJson(dynamic json) {
    _status = json['status'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(Data.fromJson(v));
      });
    }
  }
  bool _status;
  List<Data> _data;

  //get length => null;
EventResponsemodelclass copyWith({  bool status,
  List<Data> data,
}) => EventResponsemodelclass(  status: status ?? _status,
  data: data ?? _data,
);
  bool get status => _status;
  List<Data> get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 3
/// date : "02-07-2022"
/// quantity : "2"
/// paid_amount : "Â£0"
/// booking_uid : "LIZ10025"
/// arrived_at : null
/// checkin_status : 0
/// name : "Free ticket - I love Old skool"
/// guest : null
/// checkin_time : ""
/// type : "event"

Data dataFromJson(String str) => Data.fromJson(json.decode(str));
String dataToJson(Data data) => json.encode(data.toJson());
class Data {
  Data({
      num id,
      String date,
      String quantity,
      String paidAmount,
      String bookingUid,
      dynamic arrivedAt, 
      num checkinStatus,
      String name,
      dynamic guest, 
      String checkinTime,
      String type,}){
    _id = id;
    _date = date;
    _quantity = quantity;
    _paidAmount = paidAmount;
    _bookingUid = bookingUid;
    _arrivedAt = arrivedAt;
    _checkinStatus = checkinStatus;
    _name = name;
    _guest = guest;
    _checkinTime = checkinTime;
    _type = type;
}

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _date = json['date'];
    _quantity = json['quantity'];
    _paidAmount = json['paid_amount'];
    _bookingUid = json['booking_uid'];
    _arrivedAt = json['arrived_at'];
    _checkinStatus = json['checkin_status'];
    _name = json['name'];
    _guest = json['guest'];
    _checkinTime = json['checkin_time'];
    _type = json['type'];
  }
  num _id;
  String _date;
  String _quantity;
  String _paidAmount;
  String _bookingUid;
  dynamic _arrivedAt;
  num _checkinStatus;
  String _name;
  dynamic _guest;
  String _checkinTime;
  String _type;
Data copyWith({  num id,
  String date,
  String quantity,
  String paidAmount,
  String bookingUid,
  dynamic arrivedAt,
  num checkinStatus,
  String name,
  dynamic guest,
  String checkinTime,
  String type,
}) => Data(  id: id ?? _id,
  date: date ?? _date,
  quantity: quantity ?? _quantity,
  paidAmount: paidAmount ?? _paidAmount,
  bookingUid: bookingUid ?? _bookingUid,
  arrivedAt: arrivedAt ?? _arrivedAt,
  checkinStatus: checkinStatus ?? _checkinStatus,
  name: name ?? _name,
  guest: guest ?? _guest,
  checkinTime: checkinTime ?? _checkinTime,
  type: type ?? _type,
);
  num get id => _id;
  String get date => _date;
  String get quantity => _quantity;
  String get paidAmount => _paidAmount;
  String get bookingUid => _bookingUid;
  dynamic get arrivedAt => _arrivedAt;
  num get checkinStatus => _checkinStatus;
  String get name => _name;
  dynamic get guest => _guest;
  String get checkinTime => _checkinTime;
  String get type => _type;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['date'] = _date;
    map['quantity'] = _quantity;
    map['paid_amount'] = _paidAmount;
    map['booking_uid'] = _bookingUid;
    map['arrived_at'] = _arrivedAt;
    map['checkin_status'] = _checkinStatus;
    map['name'] = _name;
    map['guest'] = _guest;
    map['checkin_time'] = _checkinTime;
    map['type'] = _type;
    return map;
  }

}