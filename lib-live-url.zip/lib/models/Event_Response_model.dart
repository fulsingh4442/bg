import 'dart:convert';
/// status : true
/// data : {"iTotalRecords":1,"aaData":[{"id":1,"date":"19-08-2022","quantity":"4","paid_amount":"£80","booking_uid":"LIZ10001","checkin_status":0,"name":"Ticket #1 - API Test Event","guest":"Ashutosh Singh","event_ticket_id":"19","checkin_time":"","type":"event","checkin_guest":"0"}]}

EventResponseModel eventResponseModelFromJson(String str) => EventResponseModel.fromJson(json.decode(str));
String eventResponseModelToJson(EventResponseModel data) => json.encode(data.toJson());
class EventResponseModel {
  EventResponseModel({
      bool status,
      Data data,}){
    _status = status;
    _data = data;
}

  EventResponseModel.fromJson(dynamic json) {
    _status = json['status'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }
  bool _status;
  Data _data;
EventResponseModel copyWith({  bool status,
  Data data,
}) => EventResponseModel(  status: status ?? _status,
  data: data ?? _data,
);
  bool get status => _status;
  Data get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.toJson();
    }
    return map;
  }

}

/// iTotalRecords : 1
/// aaData : [{"id":1,"date":"19-08-2022","quantity":"4","paid_amount":"£80","booking_uid":"LIZ10001","checkin_status":0,"name":"Ticket #1 - API Test Event","guest":"Ashutosh Singh","event_ticket_id":"19","checkin_time":"","type":"event","checkin_guest":"0"}]

Data dataFromJson(String str) => Data.fromJson(json.decode(str));
String dataToJson(Data data) => json.encode(data.toJson());
class Data {
  Data({
      num iTotalRecords,
      List<AaData> aaData,}){
    _iTotalRecords = iTotalRecords;
    _aaData = aaData;
}

  Data.fromJson(dynamic json) {
    _iTotalRecords = json['iTotalRecords'];
    if (json['aaData'] != null) {
      _aaData = [];
      json['aaData'].forEach((v) {
        _aaData?.add(AaData.fromJson(v));
      });
    }
  }
  num _iTotalRecords;
  List<AaData> _aaData;
Data copyWith({  num iTotalRecords,
  List<AaData> aaData,
}) => Data(  iTotalRecords: iTotalRecords ?? _iTotalRecords,
  aaData: aaData ?? _aaData,
);
  num get iTotalRecords => _iTotalRecords;
  List<AaData> get aaData => _aaData;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['iTotalRecords'] = _iTotalRecords;
    if (_aaData != null) {
      map['aaData'] = _aaData?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 1
/// date : "19-08-2022"
/// quantity : "4"
/// paid_amount : "£80"
/// booking_uid : "LIZ10001"
/// checkin_status : 0
/// name : "Ticket #1 - API Test Event"
/// guest : "Ashutosh Singh"
/// event_ticket_id : "19"
/// checkin_time : ""
/// type : "event"
/// checkin_guest : "0"

AaData aaDataFromJson(String str) => AaData.fromJson(json.decode(str));
String aaDataToJson(AaData data) => json.encode(data.toJson());
class AaData {
  AaData({
      num id,
      String date,
      String quantity,
      String paidAmount,
      String bookingUid,
      num checkinStatus,
      String name,
      String guest,
      String eventTicketId,
      String checkinTime,
      String type,
      String checkinGuest,}){
    _id = id;
    _date = date;
    _quantity = quantity;
    _paidAmount = paidAmount;
    _bookingUid = bookingUid;
    _checkinStatus = checkinStatus;
    _name = name;
    _guest = guest;
    _eventTicketId = eventTicketId;
    _checkinTime = checkinTime;
    _type = type;
    _checkinGuest = checkinGuest;
}

  AaData.fromJson(dynamic json) {
    _id = json['id'];
    _date = json['date'];
    _quantity = json['quantity'];
    _paidAmount = json['paid_amount'];
    _bookingUid = json['booking_uid'];
    _checkinStatus = json['checkin_status'];
    _name = json['name'];
    _guest = json['guest'];
    _eventTicketId = json['event_ticket_id'];
    _checkinTime = json['checkin_time'];
    _type = json['type'];
    _checkinGuest = json['checkin_guest'];
  }
  num _id;
  String _date;
  String _quantity;
  String _paidAmount;
  String _bookingUid;
  num _checkinStatus;
  String _name;
  String _guest;
  String _eventTicketId;
  String _checkinTime;
  String _type;
  String _checkinGuest;
AaData copyWith({  num id,
  String date,
  String quantity,
  String paidAmount,
  String bookingUid,
  num checkinStatus,
  String name,
  String guest,
  String eventTicketId,
  String checkinTime,
  String type,
  String checkinGuest,
}) => AaData(  id: id ?? _id,
  date: date ?? _date,
  quantity: quantity ?? _quantity,
  paidAmount: paidAmount ?? _paidAmount,
  bookingUid: bookingUid ?? _bookingUid,
  checkinStatus: checkinStatus ?? _checkinStatus,
  name: name ?? _name,
  guest: guest ?? _guest,
  eventTicketId: eventTicketId ?? _eventTicketId,
  checkinTime: checkinTime ?? _checkinTime,
  type: type ?? _type,
  checkinGuest: checkinGuest ?? _checkinGuest,
);
  num get id => _id;
  String get date => _date;
  String get quantity => _quantity;
  String get paidAmount => _paidAmount;
  String get bookingUid => _bookingUid;
  num get checkinStatus => _checkinStatus;
  String get name => _name;
  String get guest => _guest;
  String get eventTicketId => _eventTicketId;
  String get checkinTime => _checkinTime;
  String get type => _type;
  String get checkinGuest => _checkinGuest;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['date'] = _date;
    map['quantity'] = _quantity;
    map['paid_amount'] = _paidAmount;
    map['booking_uid'] = _bookingUid;
    map['checkin_status'] = _checkinStatus;
    map['name'] = _name;
    map['guest'] = _guest;
    map['event_ticket_id'] = _eventTicketId;
    map['checkin_time'] = _checkinTime;
    map['type'] = _type;
    map['checkin_guest'] = _checkinGuest;
    return map;
  }

}