import 'dart:convert';
import 'dart:io';
import 'package:bookings/Home1.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';
class Login extends StatefulWidget {
  Login({Key key}) : super(key: key);

  @override
  State<Login> createState() =>LoginState();

}
class LoginState extends State<Login> {

  final _formKey = GlobalKey<FormState>();
  bool _isHidden = true;
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
 // String token = pref.getString(ContentType.TOKEN);




  void Login(String username,password) async {
    if(_formKey.currentState.validate()){

      try{

        //var token;

        Response response = await post(
            Uri.parse("https://lizard.reserveyourvenue.com/api/users/login"),
            // headers: {
            //
            //   'Content-Type': 'application/json; charset=UTF-8',
            //   'authorization': 'Bearer $token',
            // },

            body:{
              'username':username,
              'password':password,
            }
        );
        if(response.statusCode==200){
          var responseData = json.decode(response.body);
          var status= responseData["status"];
          print(response.body);

          if(status == true)
          {
            var data = responseData["data"];
            pageRoute(data['username'],data['email'],data['token']);
            print(response.body);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("Login Succesfully"),
            ));




          }
          else{

            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(""+ responseData["error"]),
            ));

          }

        }else{
          var responseData = json.decode(response.body);
        //  var message = responseData["status"];

          print("username"+username);
          print("password"+password);

        }
      }catch(e){
        print(e.toString());
        Fluttertoast.showToast(
            msg: ""+e.toString(),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    }


  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkLogin();
  }

  void checkLogin() async{

    SharedPreferences pref = await SharedPreferences.getInstance();
  //  String token = pref.getString("token");
    String val = pref.getString("email");
    if(val != null){
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => home()), (route) => false);
    }
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(

        child:   Container(
        //  color:Colors.black ,
          width: MediaQuery.of(context).size.width * 1.0,
          height: MediaQuery.of(context).size.height * 1.0,

          child: Column(

            children: [


             Center(
                  child: Container(

                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          // Container(
                          //   height: 10,
                          //   width: 200,
                          //   margin: EdgeInsets.only(top: 2),
                          //
                          //
                          // ),
                          Container(
                            margin: EdgeInsets.only(top: 60),
                              height: 100,width: 100,

                              child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
                          SizedBox(height: 120,),

                          Text("Login ",style: TextStyle(fontSize: 20,color: Colors.white),),
                          SizedBox(height: 20,),




                          Container(

                            height: 60,
                            width: 300,
                            margin: EdgeInsets.only(top: 0),
                            child: TextFormField(
                              style: TextStyle(color: Colors.white),
                              cursorColor: Colors.white,

                              decoration: InputDecoration(
                                  suffixIcon: new Icon(
                                    Icons.person_add_rounded,
                                    color: Colors.white,
                                  ),
                                  //filled: true, //<-- SEE HERE
                                //  fillColor: Colors.deepPurpleAccent,

                                // labelText: "Resevior Name",
                                  fillColor: Colors.white,
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white, width: 2.0),
                                ),
                                labelText: "Username",labelStyle: TextStyle(color: Colors.white),
                                 // fillColor: Colors.white,
                                 // labelText: "Username1",labelStyle: TextStyle(color: Colors.white),
                                contentPadding: EdgeInsets.only(left: 15),
                                  hintText: 'Username',
                                hintStyle: TextStyle( color: Colors.white),

                              ),
                              validator: (value){
                                if(value.isEmpty){
                                  return "Username No cannot be empty";
                                }
                                return null;
                              },
                              autofocus: false,
                              controller: usernameController,
                            ),
                          ),
                          SizedBox(height: 20,),

                          Container(
                            height: 60,
                            width: 300,
                            child: TextFormField(
                              style: TextStyle(color: Colors.white),
                              cursorColor: Colors.white,

                              obscureText: _isHidden,
                              decoration: InputDecoration(

                               // labelText: "Resevior Name",
                                fillColor: Colors.white,
                                enabledBorder: OutlineInputBorder(
                                  //borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide(color: Colors.white, width: 2.0),
                                ),
                                labelText: "Password",labelStyle: TextStyle(color: Colors.white),
                                contentPadding: EdgeInsets.only(left: 15),
                                hintText: ' Password',
                                hintStyle: TextStyle( color: Colors.white),
                              //  labelText: " Password",labelStyle: TextStyle(color: Colors.white),

                                suffix: Container(
                                  //padding: EdgeInsets.only(top: 15),
                                  child: InkWell(
                                    onTap: _togglePasswordView,
                                    child: Icon(_isHidden?
                                    Icons.visibility:
                                    Icons.visibility_off,color: Colors.white,

                                    ),
                                  ),
                                ),



                              ),
                              validator: (value){
                                if(value.isEmpty){
                                  return "Password No cannot be empty";
                                }
                                return null;
                              },
                              autofocus: false,
                              controller: passwordController,
                            ),
                          ),

                          SizedBox(height: 40,),

                          InkWell(
                            onTap: () {
                              Login(usernameController.text.toString(), passwordController.text.toString());

                            },

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  margin: EdgeInsets.only(bottom: 10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(5)),
                                    gradient: LinearGradient(colors: [
                                      Colors.white,
                                      Colors.white,
                                      Colors.white
                                    ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                  ),
                                  padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                                  child: Text(
                                    "Login",
                                    style: TextStyle(
                                      //fontSize: 20,
                                        color: Colors.black,fontWeight: FontWeight.bold
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Container(
                          //
                          //
                          //   width: 300,
                          //   height: 40,
                          //
                          //   child:
                          //   RaisedButton(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5),side: BorderSide(color: Colors.white60),),
                          //     color: Colors.white,
                          //     onPressed: (){
                          //       //  style: ElevatedButton.styleFrom(primary: Colors.red);
                          //       Login(usernameController.text.toString(), passwordController.text.toString());
                          //
                          //
                          //
                          //       // Navigator.of(context).push(MaterialPageRoute(builder: (context) => home()),);
                          //     },
                          //     child: Text('Login',style: TextStyle(fontSize: 20,color: Colors.black,),),),
                          //
                          //
                          //
                          // ),


                        ],
                      ),
                    ),
                  ),

              ),
              // ),
            ],
          ),
        ),
      ),
    );
  }


  void _togglePasswordView() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  void pageRoute(String username, email,token) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
   // await pref.setString("id", id);
    await pref.setString("username", username);
    await pref.setString("email", email);
    await pref.setString("token", token);
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => home()), (route) => false);
  }
}


