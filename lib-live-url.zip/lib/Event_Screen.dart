// import 'dart:async';
//
// import 'package:bookings/api_confi/api_client.dart';
// import 'package:bookings/models/details_response_model.dart';
// import 'package:bookings/screens/guest_details_checkin.dart';
// import 'package:bookings/screens/guest_details_close.dart';
// import 'package:bookings/screens/scan_qr.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
//
// import 'models/single_item_response_model.dart';
//
// class Event_Screen extends StatefulWidget {
//   String bookingUid;
//   String totalRecords;
//   String guestname;
//   List<AaDatumSM> dataListSM;
//   AaDatum aaData;
//   bool fromDetails;
//   // Event_Screen (
//   //     this.bookingUid,
//   //     this.totalRecords,
//   //     this.fromDetails, {
//   //       this.dataListSM,
//   //       this.aaData,
//   //       this.guestname,
//   //     });
//
//
//
//   @override
//   _Event_ScreenState createState() => _Event_ScreenState();
// }
//
// class _Event_ScreenState extends State<Event_Screen> {
//   DetailsResponseModel eventResponse;
//   Future _getDetails;
//   DateTime _selectedDate;
//   String _formatted;
//   TextEditingController _textEditingController = TextEditingController();
//
//   // getDetails() {
//   //   setState(() {
//   //     _getDetails = details().then((value) {
//   //       detailsResponseModel = value;
//   //       print(
//   //           "---------------------------${detailsResponseModel.data.aaData[0].category}");
//   //     });
//   //   });
//   // }
//
//   getDetails(String currentDate) {
//     print("inside get details");
//     setState(() {
//       _getDetails = getEventDetails(currentDate).then((value) {
//         eventResponse = value;
//       });
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     if (_textEditingController.text.isEmpty) {
//       final DateFormat _formatter = DateFormat('yyyy-MM-dd');
//       _textEditingController.text = _formatter.format(DateTime.now());
//       _formatted =
//           _formatter.format(DateTime.parse(_textEditingController.text));
//       print("formatted ---- $_formatted");
//       getDetails(_formatted);
//     }
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//    // String _formatted=DateFormat.yMMMd().format(DateTime.now());
//     return Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.black,
//           leading: InkWell(
//               onTap: () {
//                 Navigator.pop(context);
//               },
//               child: Icon(Icons.arrow_back)),
//           title: Center(
//             child: Container(
//                 margin: EdgeInsets.only(right: 55),
//                 height: 45,width: 45,
//
//                 child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
//           ),
//         ),
//         backgroundColor: Colors.white,
//         body: SafeArea(
//           child: Container(
//             margin: EdgeInsets.only(left: 10,right: 10),
//             child: Column(
//               children: [
//                 // Padding(
//                 //   padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
//                 //   child: Row(
//                 //     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 //     children: [
//                 //       InkWell(
//                 //         onTap: () {
//                 //           Navigator.of(context).pushAndRemoveUntil(
//                 //               MaterialPageRoute(
//                 //                   builder: (context) => ScanQrScreen()),
//                 //               (Route<dynamic> route) => false);
//                 //         },
//                 //         child: Container(
//                 //             padding: EdgeInsets.fromLTRB(20, 15, 0, 20),
//                 //             child: Icon(Icons.arrow_back_ios)),
//                 //       ),
//                 //       Container(
//                 //         decoration: BoxDecoration(
//                 //           // color: Colors.amber,
//                 //           borderRadius: BorderRadius.all(Radius.circular(10)),
//                 //           gradient: LinearGradient(
//                 //               colors: [
//                 //                 Colors.white,
//                 //                 Colors.blue.shade900,
//                 //                 Colors.lightBlue
//                 //               ],
//                 //               begin: Alignment.topCenter,
//                 //               end: Alignment.bottomCenter),
//                 //         ),
//                 //         padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
//                 //         child: Text(
//                 //           "Today's List",
//                 //           style: TextStyle(
//                 //             fontSize: 20,
//                 //             color: Colors.white,
//                 //           ),
//                 //         ),
//                 //       ),
//                 //       Container(
//                 //         height: MediaQuery.of(context).size.height * 0.06,
//                 //         width: MediaQuery.of(context).size.width * 0.15,
//                 //         // color: Colors.lightBlue,
//                 //         decoration: BoxDecoration(
//                 //           image: DecorationImage(
//                 //             fit: BoxFit.fill,
//                 //             image: AssetImage('assets/images/appicon.png'),
//                 //           ),
//                 //         ),
//                 //       ),
//                 //     ],
//                 //   ),
//                 // ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                         margin: EdgeInsets.only(right: 40,top: 10),
//                         child: Text("Event Booking",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)
//
//
//                     ),
//                     Container(
//                       width: MediaQuery.of(context).size.width * 0.45,
//                       height: MediaQuery.of(context).size.height * 0.07,
//                       margin: EdgeInsets.only(top: 5,left: 0),
//                       child: TextField(
//
//                         focusNode: AlwaysDisabledFocusNode(),
//                         controller: _textEditingController,
//                         onTap: () {
//                           _selectDate(context);
//                         },
//
//                         decoration: InputDecoration(
//                           suffixIcon: Icon(Icons.calendar_month_outlined,color: Colors.black,),
//
//                           fillColor: Colors.white,
//
//                           // focusedBorder: OutlineInputBorder(
//                           //
//                           //   borderSide:
//                           //   const BorderSide(color: Colors.black, width: 0.5),
//                           //   borderRadius: BorderRadius.circular(10.0),
//                           //
//                           //
//                           // ),
//
//                           enabledBorder: OutlineInputBorder(
//                             borderSide:
//                             const BorderSide(color: Colors.black, width: 0.5),
//                             borderRadius: BorderRadius.circular(10.0),
//
//
//
//                           ),
//
//
//
//                         ),
//
//
//                       ),
//
//                     ),
//
//                     // InkWell(
//                     //   onTap: () {
//                     //     print(_selectedDate);
//                     //     _selectedDate == null
//                     //         ? getDetails(_formatted)
//                     //         : getDetails(_selectedDate.toString());
//                     //   },
//                     //   child: Container(
//                     //     padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                     //     margin: EdgeInsets.fromLTRB(10, 25, 10, 10),
//                     //     decoration: BoxDecoration(
//                     //       // color: Colors.amber,
//                     //       borderRadius: BorderRadius.all(Radius.circular(20)),
//                     //       gradient: LinearGradient(
//                     //           colors: [
//                     //             Colors.white,
//                     //             Colors.blue.shade900,
//                     //             Colors.lightBlue
//                     //           ],
//                     //           begin: Alignment.topCenter,
//                     //           end: Alignment.bottomCenter),
//                     //     ),
//                     //     child: Text(
//                     //       "Go",
//                     //       style: TextStyle(
//                     //         fontSize: 20,
//                     //         color: Colors.white,
//                     //       ),
//                     //     ),
//                     //   ),
//                     // ),
//                   ],
//                 ),
//                 Divider(color: Colors.grey,),
//
//
//
//
//                 FutureBuilder(
//                     future: _getDetails,
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return CircularProgressIndicator();
//                       } else {
//                         return Container(
//                           // color:Colors.red,
//                           // padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
//                           margin: EdgeInsets.only(top: 10),
//                           width: MediaQuery.of(context).size.width * 1.0,
//                           height: MediaQuery.of(context).size.height * 0.76,
//                           child: eventResponse.data.iTotalRecords == 0
//                               ? Container(
//                               margin: EdgeInsets.only(left: 20),
//                               child: Text("No Data Found !"))
//                               : ListView.builder(
//                               shrinkWrap: true,
//                               scrollDirection: Axis.vertical,
//                               itemCount:
//                               eventResponse.data.aaData.length,
//                               itemBuilder: (context, index) {
//                                 return GestureDetector(
//                                   onTap: () {
//                                     print(eventResponse
//                                         .data.aaData[index].checkinStatus);
//                                     if (eventResponse.data
//                                         .aaData[index].checkinStatus ==
//                                         "0") {
//                                       print('hii');
//                                       print(
//                                         eventResponse
//                                             .data.aaData[index].events,
//                                       );
//                                       Navigator.push(
//                                           context,
//                                           MaterialPageRoute(
//                                               builder: (context) =>
//                                                   GuestDetailsCheckIn(
//                                                     eventResponse
//                                                         .data
//                                                         .aaData[index]
//                                                         .bookingUid,
//                                                     eventResponse
//                                                         .data.iTotalRecords
//                                                         .toString(),
//                                                     true,
//                                                     aaData:
//                                                     eventResponse
//                                                         .data
//                                                         .aaData[index],
//                                                     guestname: (eventResponse
//                                                         .data
//                                                         .aaData[index]
//                                                         .firstName ??
//                                                         "") +
//                                                         (eventResponse
//                                                             .data
//                                                             .aaData[index]
//                                                             .lastName ??
//                                                             ""),
//                                                   ))).then((value) {
//                                         print("value ------  $value");
//                                         if (value == true) {
//                                           print(_textEditingController.text);
//                                           getDetails(
//                                               _textEditingController.text);
//                                         }
//                                       });
//                                     } else {
//                                       Navigator.push(
//                                           context,
//                                           MaterialPageRoute(
//                                               builder: (context) =>
//                                                   GuestDetailsClose(
//                                                     eventResponse
//                                                         .data
//                                                         .aaData[index]
//                                                         .bookingUid,
//                                                     eventResponse
//                                                         .data.iTotalRecords
//                                                         .toString(),
//                                                     aaData:
//                                                     eventResponse
//                                                         .data
//                                                         .aaData[index],
//                                                     guestname: (eventResponse
//                                                         .data
//                                                         .aaData[index]
//                                                         .firstName ??
//                                                         "") +
//                                                         (eventResponse
//                                                             .data
//                                                             .aaData[index]
//                                                             .lastName ??
//                                                             ""),
//                                                   )));
//                                     }
//                                   },
//                                   child:Container(
//                                    // margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                                     child: Card(
//                                       elevation: 5,
//                                       shape: RoundedRectangleBorder(
//                                         borderRadius: BorderRadius.circular(10),
//                                       ),
//                                       child: Column(
//                                         children: [
//                                           // Center(
//                                           //   child: Container(
//                                           //     child: Text("",
//                                           //       // widget.aaDataListSM != null
//                                           //       //     ? (widget.aaDataListSM[0].firstName ?? "") +
//                                           //       //     (widget.aaDataListSM[0].lastName ?? "")
//                                           //       //     : widget.guestname,
//                                           //       style: TextStyle(
//                                           //         fontSize: 16,
//                                           //         fontWeight: FontWeight.bold,
//                                           //       ),
//                                           //     ),
//                                           //   ),
//                                           // ),
//                                           Container(
//                                             margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//
//                                               children: [
//
//                                                 Row(
//                                                   children: [
//                                                     Text(
//                                                       "Booking ID:",
//                                                       style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                     ),
//                                                     Text(
//                                                        " ${widget.bookingUid}",
//                                                       style: TextStyle(fontSize: 15),
//                                                     ),
//                                                   ],
//                                                 ),
//
//
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                       child: Text(" Date:",
//
//                                                         style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                       ),
//                                                     ),
//                                                     Container(
//                                                       child: Text( " 19/08/2022",
//                                                         // " ${widget.bookingUid}",
//                                                         style: TextStyle(fontSize: 15,),
//                                                       ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             child: Row(
//                                               // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//
//                                                 Text(
//
//                                                   "Guest:",
//                                                   style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(
//                                                     // widget.aaDataListSM != null
//                                                     //     ? " ${widget.aaDataListSM[0].quantity??""}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.quantity}"
//                                                     "   Ashutosh Singh ",
//                                                     style: TextStyle(fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             child: Row(
//                                               //mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//
//                                                 Text(
//
//                                                   "Event:",
//                                                   style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                 ),
//                                                 Container(
//                                                   child: Text(
//                                                     // widget.aaDataListSM != null
//                                                     //     ? widget.aaDataListSM[0].events.isEmpty
//                                                     //     ? " "
//                                                     //     : "Event Name: ${widget.aaDataListSM[0].events[0].name}"
//                                                     //     : widget.aaData != null
//                                                     //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
//                                                     "  AFROBASH - 1st Belease  ",
//                                                     style: TextStyle(fontSize: 15),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           // Container(
//                                           //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                           //   child: Row(
//                                           //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                           //     children: [
//                                           //
//                                           //       Text(
//                                           //
//                                           //         "No of Guerts:  6 ",
//                                           //         style: TextStyle(fontSize: 15),
//                                           //       ),
//                                           //       Container(
//                                           //         child: Text("Check in guert:  6"
//                                           //           // widget.aaDataListSM != null
//                                           //           //     ? " ${widget.aaDataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
//                                           //           //     : widget.aaData != null
//                                           //           //     ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
//                                           //                " ",
//                                           //           style: TextStyle(fontSize: 15),
//                                           //         ),
//                                           //       ),
//                                           //     ],
//                                           //   ),
//                                           // ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             child: Row(
//                                               // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Text(
//
//                                                   "Paid Amount :",
//                                                   style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                 ),
//                                                 Row(
//                                                   children: [
//                                                     Container(
//                                                         margin: EdgeInsets.only(left: 10),
//                                                         height: 25,width: 20,
//
//                                                         child: Image.asset('assets/images/rr.jpg', )),
//                                                     Container(
//                                                       child: Text(
//                                                         // widget.aaDataListSM != null
//                                                         //     ? "${widget.aaDataListSM[0].total??""} GBP"
//                                                         //     : widget.aaData != null
//                                                         //     ? " ${widget.aaData.total} GBP"
//                                                         "Â£0 ",
//                                                         style: TextStyle(fontSize: 15),
//                                                       ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           Container(
//                                             margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 Container(
//
//                                                   child: Text(
//                                                     "No of Guest: 5",
//                                                     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                   ),
//                                                 ),
//
//                                                 Container(
//
//                                                   child: Text(
//                                                     " Chacked: In Guest: 4",
//                                                     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                   ),
//                                                 ),
//
//
//                                               ],
//                                             ),
//                                           ),
//                                           InkWell(
//                                             onTap: () {
//                                               checkIn(widget.bookingUid, DateTime.now().toString(), "1",
//                                                   widget.fromDetails, context);
//                                               // Navigator.of(context).pushAndRemoveUntil(
//                                               //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
//                                               //         (Route<dynamic> route) => false);
//                                             },
//                                             child: Row(
//                                               mainAxisAlignment: MainAxisAlignment.center,
//                                               children: [
//                                                 Container(
//                                                   margin: EdgeInsets.only(bottom: 10,top: 10),
//                                                   decoration: BoxDecoration(
//                                                     borderRadius: BorderRadius.all(Radius.circular(5)),
//                                                     gradient: LinearGradient(colors: [
//                                                       Colors.black,
//                                                       Colors.black,
//                                                       Colors.black
//                                                     ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                                                   ),
//                                                   padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
//                                                   child: Text(
//                                                     "Check In",
//                                                     style: TextStyle(
//                                                       //fontSize: 20,
//                                                         color: Colors.white,fontWeight: FontWeight.bold
//                                                     ),
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//
//                                           // Row(
//                                           //   children: [
//                                           //     Container(
//                                           //       child: Text(
//                                           //         widget.aaDataListSM != null
//                                           //             ? "Checked In Time: ${widget.aaDataListSM[0].arrivedAt??""}"
//                                           //             : widget.aaData != null
//                                           //                 ? "Checked In Time: ${widget.aaData.arrivedAt}"
//                                           //                 : "Checked In Time: ",
//                                           //         style: TextStyle(fontSize: 15),
//                                           //       ),
//                                           //     ),
//                                           //   ],
//                                           // ),
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                 );
//                               }),
//                         );
//                       }
//                     }),
//               ],
//             ),
//           ),
//         ));
//   }
//
//   _selectDate(BuildContext context) async {
//     DateTime newSelectedDate = await showDatePicker(
//         context: context,
//         initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
//         firstDate: DateTime(2000),
//         lastDate: DateTime(2040),
//         builder: (BuildContext context, Widget child) {
//           return Theme(
//             data: ThemeData.dark().copyWith(
//               colorScheme: ColorScheme.dark(
//                 primary: Colors.blue.shade900,
//                 onPrimary: Colors.white,
//                 surface: Colors.blue.shade900,
//                 onSurface: Colors.white,
//               ),
//               dialogBackgroundColor: Colors.blue[500],
//             ),
//             child: child,
//           );
//         });
//
//     if (newSelectedDate != null) {
//       _selectedDate = newSelectedDate;
//       final DateFormat formatter = DateFormat('yyyy-MM-dd');
//       final String formatted = formatter.format(_selectedDate);
//       _textEditingController
//         ..text = formatted
//         ..selection = TextSelection.fromPosition(TextPosition(
//             offset: _textEditingController.text.length,
//             affinity: TextAffinity.upstream));
//       print(formatted);
//       getDetails(formatted);
//     }
//   }
// }
//
// class AlwaysDisabledFocusNode extends FocusNode {
//   @override
//   bool get hasFocus => false;
// }



//
// import 'dart:convert';
//
// // import 'package:bookings/models/EventResponse.dart';
// // import 'package:bookings/models/EventResponse.dart';
// // import 'package:bookings/models/EventResponsemodel.dart';
// // import 'package:bookings/models/Responseevent.dart';
// import 'package:bookings/models/TableResponseModel.dart';
// import 'package:bookings/models/eventResponsemodelclass.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:http/http.dart';
//
//
// import 'models/single_item_response_model.dart';
//
// class Event_Screen1 extends StatefulWidget {
//
//
//
//   @override
//   _Event_Screen1State createState() => _Event_Screen1State();
// }
//
// class _Event_Screen1State extends State<Event_Screen1> {
//
//  //  // postApidata() async{
//  //  //   var url = Uri.parse("https://app-api.teaseme.co.in/api/booking");
//  //  //   Response responce = await http.post(url);
//  //  //   print(responce);
//  //  //     headers: <String, String>{
//  //  //       'Content-Type': 'application/json; charset=UTF-8',
//  //  //       'token':"7cff459d59d2210b5c484d5475bad947 ",
//  //  //     },
//  //  //     body: jsonEncode(<String, String>{
//  //  //       'booking_id':"LIZ10025 ",
//  //  //     }),
//  //
//  //
//  //
//  // // List<EventResponsemodelclass> eventResponse = [];
//  //
//  //    if(responce.statusCode== 200){
//  //      print(true);
//  //      final data=jsonDecode(responce.body);
//  //      print(data);
//  //      final
//  //      // var status=data["status"];
//  //      // var message=data["message"];
//  //      // String responceBody = responce.body;
//  //      // var jsonBody = json.decode(responceBody);
//  //      // for(var data in jsonBody){
//  //      //   eventResponse.add(new EventResponsemodelclass(
//  //      //       data['date'],data['id'],data['quantity'],data['paid_amount'],data['booking_uid'],data['arrived_at'],
//  //      //     data['checkin_status'],data['name'],data[''],data['guest'],data['checkin_time'],data[''],data[''],));
//  //      // }
//  //     //  if(status== true){
//  //     //    print(status);
//  //     //  //  print(message);
//  //     //    return EventResponsemodelclass.fromJson(data);
//  //     //
//  //     //  }
//  //     // else{
//  //
//  //
//  //     // }
//  //    }
//  //    else{
//  //      print("failuer2");
//  //     // return EventResponsemodelclass.fromJson(data);
//  //    }
//  //  }
//
//
//   Future<TableResponseModel> booking()async {
//     Response responce = await http.post(
//       Uri.parse("https://app-api.teaseme.co.in/api/booking"),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//         'token': "7cff459d59d2210b5c484d5475bad947 ",
//       },
//       body: jsonEncode(<String, String>{
//         'booking_id': "IV10018 ",
//       }),
//     );
//     var data = jsonDecode(responce.body.toString());
//     var status = data[true];
//     if (responce.statusCode == 200) {
//       if (status == "status") {
//         return TableResponseModel.fromJson(data);
//       } else {
//         return TableResponseModel.fromJson(data);
//       }
//     } else {
//       return TableResponseModel.fromJson(data);
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     // String _formatted=DateFormat.yMMMd().format(DateTime.now());
//     return Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.black,
//           leading: InkWell(
//               onTap: () {
//                 Navigator.pop(context);
//               },
//               child: Icon(Icons.arrow_back)),
//           title: Center(
//             child: Container(
//                 margin: EdgeInsets.only(right: 55),
//                 height: 45,width: 45,
//
//                 child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
//           ),
//         ),
//         backgroundColor: Colors.white,
//         body: SafeArea(
//           child: Container(
//             margin: EdgeInsets.only(left: 10,right: 10),
//             child: Column(
//               children: [
//
//                 Expanded(
//                     child: FutureBuilder<TableResponseModel>(
//                         future: booking(),
//                         builder: (context, snapshot) {
//                           if (!snapshot.hasData) {
//                             return Center(child: CircularProgressIndicator());
//                           } else {
//                             return ListView.builder(
//                                 itemCount: snapshot.data.data.length,
//                                 itemBuilder: (context, index)  {
//                                   return
//                                     Container(
//                                       // margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
//                                       child: Card(
//                                         elevation: 5,
//                                         shape: RoundedRectangleBorder(
//                                           borderRadius: BorderRadius.circular(10),
//                                         ),
//                                         child: Column(
//                                           children: [
//
//                                             Container(
//                                               margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                               child: Row(
//                                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//
//                                                 children: [
//
//                                                   Row(
//                                                     children: [
//                                                       Text(
//                                                         "Booking ID:",
//                                                         style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                       ),
//                                                       Text(snapshot.data.data[index].bookingUid.toString() ?? '',
//                                                         // snapshot.data.data[index].bookingUid
//                                                         //     .toString(),
//
//                                                         style: TextStyle(fontSize: 15),
//                                                       ),
//                                                     ],
//                                                   ),
//
//
//                                                   // Container(
//                                                   //   child: Text(snapshot.data.data[index].date.toString(),
//                                                   //     // " ${widget.bookingUid}",
//                                                   //     style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                                   //   ),
//                                                   // ),
//                                                 ],
//                                               ),
//                                             ),
//
//                                             // Container(
//                                             //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             //   child: Row(
//                                             //     // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                             //     children: [
//                                             //
//                                             //       Text(
//                                             //
//                                             //         "Guest:",
//                                             //         style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                             //       ),
//                                             //       // Container(
//                                             //       //   child: Text(
//                                             //       //     // widget.aaDataListSM != null
//                                             //       //     //     ? " ${widget.aaDataListSM[0].quantity??""}"
//                                             //       //     //     : widget.aaData != null
//                                             //       //     //     ? " ${widget.aaData.quantity}"
//                                             //       //     snapshot.data.data[index].guest.toString(),
//                                             //       //     style: TextStyle(fontSize: 15),
//                                             //       //   ),
//                                             //       // ),
//                                             //     ],
//                                             //   ),
//                                             // ),
//                                             //
//                                             // Container(
//                                             //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             //   child: Row(
//                                             //     //mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                             //     children: [
//                                             //
//                                             //       Text(
//                                             //
//                                             //         "Event:",
//                                             //         style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                             //       ),
//                                             //       Container(
//                                             //         child: Text(
//                                             //           // widget.aaDataListSM != null
//                                             //           //     ? widget.aaDataListSM[0].events.isEmpty
//                                             //           //     ? " "
//                                             //           //     : "Event Name: ${widget.aaDataListSM[0].events[0].name}"
//                                             //           //     : widget.aaData != null
//                                             //           //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
//                                             //           snapshot.data.data[index].type.toString(),
//                                             //           style: TextStyle(fontSize: 15),
//                                             //         ),
//                                             //       ),
//                                             //     ],
//                                             //   ),
//                                             // ),
//                                             //
//                                             //
//                                             //
//                                             // Container(
//                                             //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             //   child: Row(
//                                             //     // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                             //     children: [
//                                             //       Text(
//                                             //
//                                             //         "Paid Amount :",
//                                             //         style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                             //       ),
//                                             //       Row(
//                                             //         children: [
//                                             //           Container(
//                                             //               margin: EdgeInsets.only(left: 10),
//                                             //               height: 25,width: 20,
//                                             //
//                                             //               child: Image.asset('assets/images/rr.jpg', )),
//                                             //           Container(
//                                             //             child: Text(
//                                             //               // widget.aaDataListSM != null
//                                             //               //     ? "${widget.aaDataListSM[0].total??""} GBP"
//                                             //               //     : widget.aaData != null
//                                             //               //     ? " ${widget.aaData.total} GBP"
//                                             //               snapshot.data.data[index].paidAmount.toString(),
//                                             //               style: TextStyle(fontSize: 15),
//                                             //             ),
//                                             //           ),
//                                             //         ],
//                                             //       ),
//                                             //     ],
//                                             //   ),
//                                             // ),
//                                             //
//                                             // Container(
//                                             //   margin: EdgeInsets.only(left: 10,top: 10,right: 10),
//                                             //   child: Row(
//                                             //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                             //     children: [
//                                             //       Container(
//                                             //
//                                             //         child: Text(
//                                             //           "No of Guest: 5",
//                                             //           style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                             //         ),
//                                             //       ),
//                                             //
//                                             //       Container(
//                                             //
//                                             //         child: Text(
//                                             //           snapshot.data.data[index].checkinStatus.toString(),
//                                             //           style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
//                                             //         ),
//                                             //       ),
//                                             //
//                                             //
//                                             //     ],
//                                             //   ),
//                                             // ),
//                                             // InkWell(
//                                             //   onTap: () {
//                                             //     // checkIn(widget.bookingUid, DateTime.now().toString(), "1",
//                                             //     //     widget.fromDetails, context);
//                                             //     // Navigator.of(context).pushAndRemoveUntil(
//                                             //     //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
//                                             //     //         (Route<dynamic> route) => false);
//                                             //   },
//                                             //   child: Row(
//                                             //     mainAxisAlignment: MainAxisAlignment.center,
//                                             //     children: [
//                                             //       Container(
//                                             //         margin: EdgeInsets.only(bottom: 10,top: 10),
//                                             //         decoration: BoxDecoration(
//                                             //           borderRadius: BorderRadius.all(Radius.circular(5)),
//                                             //           gradient: LinearGradient(colors: [
//                                             //             Colors.black,
//                                             //             Colors.black,
//                                             //             Colors.black
//                                             //           ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
//                                             //         ),
//                                             //         padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
//                                             //         child: Text(
//                                             //           "Check In",
//                                             //           style: TextStyle(
//                                             //             //fontSize: 20,
//                                             //               color: Colors.white,fontWeight: FontWeight.bold
//                                             //           ),
//                                             //         ),
//                                             //       ),
//                                             //     ],
//                                             //   ),
//                                             // ),
//
//
//
//
//                                           ],
//                                         ),
//                                       ),
//                                     );
//
//
//                                 }
//                             );
//
//                           }
//                         }
//
//
//                     ),
//                 ),
//               ],
//             ),
//
//             ),
//           ),
//         );
//   }
// }
import 'dart:convert';
import 'package:bookings/demoScreen.dart';
import 'package:bookings/models/Event_Response_model.dart';
import 'package:bookings/models/Guest_Checj_Response.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'package:group_radio_button/group_radio_button.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
class Event_Screen extends StatefulWidget {
  const Event_Screen({Key key}) : super(key: key);

  @override
  _Event_ScreenState createState() => _Event_ScreenState();
}
class _Event_ScreenState extends State<Event_Screen> {
  bool viaTextField = false;
  TextEditingController textEditingController = TextEditingController();
 TextEditingController PerDay=TextEditingController();

  _printLatestValue() {
    print("text field: ${textEditingController.text}");
  }
  Future<List> fetchSimpleData() async {
    await Future.delayed(Duration(milliseconds: 2000));
    List eventResponseModel = <dynamic>[];
    return eventResponseModel;
  }

  String level1 = '';
  bool _isVisible = false;
  bool isLoading = false;

  void hideWidget() {
    setState(() {
      _isVisible = !_isVisible;
    });
  }
  EventResponseModel eventResponseModel;
  GuestChecjResponse guestChecjResponse;
  // Future booking;
  DateTime _selectedDate;
  String _formatted;
  TextEditingController _textEditingController = TextEditingController();
  getDetails(String currentDate) {
    print("inside get details");
    setState(() {
      booking(currentDate).then((value) {
        eventResponseModel = value;
      });
    });
  }
  checkInBooking(String bookingId,bookingDate,ticketId,bookingType){
    setState(() {
      _booking(bookingId,bookingDate,ticketId,bookingType).then((value) {
        if(value.status == true){
          // Fluttertoast.showToast(
          //     msg:"Checked In",
          //     toastLength: Toast.LENGTH_SHORT,
          //     timeInSecForIosWeb: 2,
          //     backgroundColor: Colors.black, //ColorRes.primaryColor,
          //     textColor: Colors.white,
          //     fontSize: 20.0,
          //     gravity: ToastGravity.BOTTOM);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Check in successfully"),
          ));

          getDetails(bookingDate);
          // Navigator.of(context).pushAndRemoveUntil(
          //     MaterialPageRoute(builder: (context) => Guest_Checked_In_Successfully()),
          //         (Route<dynamic> route) => false);
        }else{
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(value.message.toString()),
          ));
        }
      });
    });
  }
  @override
  void initState() {
    super.initState();
    if (_textEditingController.text.isEmpty) {
     /// var _formatter = DateFormat('dd/MM/yyyy');
     // final _formatter = formatDate(DateTime.now(), [dd, '-', mm, '-', yyyy]);


      final DateFormat _formatter = DateFormat('yyyy-MM-dd');
      _textEditingController.text = _formatter.format(DateTime.now());
      _formatted =
          _formatter.format(DateTime.parse(_textEditingController.text));
      print("formatted$_formatted");
      getDetails(_formatted);
      selectedDate = _formatted;
    }
    initial();
   // textEditingController.addListener(_printLatestValue);
  }
  SharedPreferences Response;
  String token;
  String selectedDate;

  void initial() async {
    Response = await SharedPreferences.getInstance();
    token = Response.getString('token').toString();
  }

  Future<EventResponseModel> booking(String booking_date)async {
    Response = await SharedPreferences.getInstance();
    token = Response.getString('token').toString();
    var requestBody = {
      "booking_date": booking_date,
      'booking_type': "event",
    };
  //https://app-api.teaseme.co.in
    http.Response responce = await http.post(
      Uri.parse("https://lizard.reserveyourvenue.com/api/booking"),
      headers: <String, String>{
        //'Content-Type': 'application/json; charset=UTF-8',
        'token':token
      },

        body: requestBody
    );

    var data = jsonDecode(responce.body.toString());
    var status = data["status"];
    if (responce.statusCode == 200) {
      print(responce.body);
      // print(data);
      print(token);
      print(data);
      if (status == true) {
        return EventResponseModel.fromJson(data);
      } else {
        return EventResponseModel.fromJson(data);
      }
    } else {
      return EventResponseModel.fromJson(data);
    }
  }
  Future<GuestChecjResponse> _booking(String booking_id,booking_date,event_ticket_id,booking_type)async {
    var requestBody = {
      'booking_id': booking_id,
      'booking_type': booking_type,
      'booking_date': booking_date,
      "event_ticket_id":event_ticket_id

    };
    Response = await SharedPreferences.getInstance();
    token = Response.getString('token').toString();

    http.Response responce = await http.post(
      Uri.parse("https://lizard.reserveyourvenue.com/api/booking/checkin"),
      headers: <String, String>{
        //'Content-Type': 'application/json; charset=UTF-8',
        'token':token

      },

        body: requestBody

    );

   // print(requestBody);
    print(guestChecjResponse);
    var data = jsonDecode(responce.body.toString());
    var status = data["status"];
    if (responce.statusCode == 200) {
      print(responce.body);
      // print(data);
      print(token);


      if (status == true) {
        return GuestChecjResponse.fromJson(data);
      } else {
        return GuestChecjResponse.fromJson(data);

      }

    } else {
      return GuestChecjResponse.fromJson(data);
    }
  }

  Filiter(String result) async {
    setState(() {
      isLoading = true;
      print("isLoading $isLoading");
    });
    if (viaTextField == true) {
      print("---------calling scan data ----------");
      await getDetails(result).then((value) {
        eventResponseModel = value;
      });

      setState(() {
        isLoading = false;
        print("isLoading  -----  $isLoading");
      });

      if (eventResponseModel.data.iTotalRecords == 0) {
        print("invalid ----- ");
        Fluttertoast.showToast(
            msg: "No Data Found !",
            toastLength: Toast.LENGTH_SHORT,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.black, //ColorRes.primaryColor,
            textColor: Colors.white,
            fontSize: 20.0,
            gravity: ToastGravity.BOTTOM);
        // Navigator.of(context).pushAndRemoveUntil(
        //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
        //     (Route<dynamic> route) => false);
        setState(() {
          textEditingController.text = "";
        });
      } else {
        print("here in if");
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Event_Screen1(
                  result,
                  eventResponseModel.data.iTotalRecords.toString(),
                  false,
                 // dataListSM: eventResponseModel.data.aaData,
                )));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // String _formatted=DateFormat.yMMMd().format(DateTime.now());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back)),
        title: Center(
          child: Container(
              margin: EdgeInsets.only(right: 55),
              height: 45,width: 45,

              child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
          child: Container(
            margin: EdgeInsets.only(left: 0,right: 0),
            child: Column(

              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                        margin: EdgeInsets.only(right: 15,top: 10),
                        child: Text("Event Booking",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),)
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.45,
                      height: MediaQuery.of(context).size.height * 0.07,
                      margin: EdgeInsets.only(top: 5,left: 0),
                      child: TextField(
                        focusNode: AlwaysDisabledFocusNode(),
                        controller: _textEditingController,
                        onTap: () {
                         // eventResponseModel.data.aaData[0].date;
                          getDetails( eventResponseModel.data.aaData[0].date);
                        },
                        decoration: InputDecoration(
                          suffixIcon: InkWell(
                                     onTap: () {
                                       _selectDate(context);
                                     },
                              child: Icon(Icons.calendar_month_outlined,color: Colors.black,size: 30,)),

                          fillColor: Colors.white,
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                            const BorderSide(color: Colors.black, width: 0.5),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide:
                            const BorderSide(color: Colors.black, width: 0.5),
                            borderRadius: BorderRadius.circular(10.0),

                          ),
                        ),
                      ),
                    ),
                         InkWell(
                           onTap: () {

                             setState(() {
                               hideWidget();
                              // _isVisible = true;
                             });

                           },
                            child: Container(
                          margin: EdgeInsets.only(left: 20,top: 5,),
                          height: 30,width: 30,

                          child: Image.asset('assets/images/img_15.png', )),
                    ),

                  ],
                ),
                Divider(color: Colors.grey,),
                Visibility(
                  visible: _isVisible,


                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 15),
                        child: Container(
                            alignment: Alignment.centerLeft,
                            margin: EdgeInsets.only(left: 0),
                            child: Text("Filter by",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),)),
                      ),

                      Row(
                        children: [
                          RadioButton(
                            description: "Booking ID",
                            value: "Booking ID",
                            groupValue: level1,
                            onChanged: (value) => setState(
                                  () => level1 = value.toString(),
                            ),
                          ),
                          RadioButton(
                            description: "Name",
                            value: "Name",
                            groupValue: level1,
                            onChanged: (value) => setState(
                                  () => level1 = value.toString(),
                            ),
                          ),

                          RadioButton(
                            description: "Email",
                            value: "Email",
                            groupValue: level1,
                            onChanged: (value) => setState(
                                  () => level1 = value.toString(),
                            ),
                          ),

                        ],
                      ),
                      // Container(
                      //     margin: EdgeInsets.only(left: 15),
                      //     alignment: Alignment.centerLeft,
                      //     child: Text(level1,style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),)),
                      Padding(
                        padding: const EdgeInsets.only(left: 8,right: 8),
                        child: Form(

                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            height: MediaQuery.of(context).size.height * 0.07,
                            margin: EdgeInsets.only(top: 0),
                            child: TextField(
                              controller: textEditingController,
                              style: TextStyle(color: Colors.black),
                              decoration: InputDecoration(
                                suffixIcon: Container(
                                  child: InkWell(
                                    onTap: () {
                                      print("hiiii");
                                      setState(() {
                                        print("inside ontap");
                                        viaTextField = true;
                                        print(textEditingController.text);

                                        //getDetails("");

                                      });
                                    },
                                    child: new Icon(
                                      Icons.search,size: 40,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),

                                labelText: "$level1",labelStyle: TextStyle(color: Colors.grey,),
                                contentPadding: EdgeInsets.only(top: 15,left: 15),
                                hintText: " $level1",suffixStyle: TextStyle(fontWeight: FontWeight.bold,),

                                fillColor: Colors.black,
                                focusedBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      color: Colors.black, width: 0.5),
                                  borderRadius: BorderRadius.circular(0.0),

                                ),


                                enabledBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      color: Colors.black, width: 0.5),
                                  borderRadius: BorderRadius.circular(5),

                                ),

                              ),

                            ),
                          ),


                        ),
                      ),
                      Divider(color: Colors.grey,),
                    ],
                  ),

                ),
                SizedBox(height: 0,),
                Expanded(
                child: FutureBuilder<EventResponseModel>(
                    future: booking(selectedDate),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Center(child: CircularProgressIndicator());
                      } else {
                        return Container(
                            // color:Colors.red,
                            // padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                            margin: EdgeInsets.only(top: 0),
                      width: MediaQuery.of(context).size.width * 1.0,
                      height: MediaQuery.of(context).size.height * 0.72,
                      child: eventResponseModel.data.iTotalRecords == 0
                      ? Container(
                      margin: EdgeInsets.only(left: 20),
                      child: Center(child: Text("No Data Found !",style: TextStyle(color: Colors.black),)))
                         : ListView.builder(
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                                itemCount: eventResponseModel.data.aaData.length,
                                 itemBuilder: (context, index){
                              return GestureDetector(
                                  onTap: () {
                                if (eventResponseModel.data
                                    .aaData[index].checkinStatus ==
                                    "0") {
                                  print('hii');
                                  print(
                                    eventResponseModel
                                      .data.aaData[index].type,
                                  );
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              Event_Screen1(
                                                eventResponseModel
                                                    .data
                                                    .aaData[index]
                                                    .bookingUid,
                                                eventResponseModel
                                                    .data.iTotalRecords
                                                    .toString(),
                                                true,

                                              ))).then((value) {
                                    print("value ------  $value");
                                    if (value == true) {
                                      getDetails(eventResponseModel
                                          .data
                                          .aaData[index]
                                          .date);
                                    }
                                  });
                                } else {

                                }
                              },
                                   child:

                                Column(

                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                                      child: Card(
                                        elevation: 5,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              10),
                                        ),
                                        child: Column(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 0),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment
                                                    .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Booking ID:",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        right: 10),
                                                    child: Text(  "${eventResponseModel.data.aaData[index].bookingUid}",
                                                      // "E1245",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Text(
                                                          "Date:",
                                                          // " ${widget.bookingUid}",
                                                          style: TextStyle(
                                                              fontSize: 15,
                                                              fontWeight: FontWeight
                                                                  .bold),
                                                        ),
                                                      ),
                                                      Container(
                                                        width: MediaQuery.of(context).size.width * 0.33,
                                                        height: MediaQuery.of(context).size.height * 0.02,

                                                        // margin: EdgeInsets.only(top: 5,left: 10),
                                                        child: TextField(


                                                          focusNode: AlwaysDisabledFocusNode(),
                                                          controller: _textEditingController,
                                                          onTap: () {
                                                            // _selectDate(context);
                                                          },

                                                          decoration: InputDecoration(



                                                            focusedBorder: OutlineInputBorder(

                                                              borderSide:
                                                              const BorderSide(color: Colors.white, width: 0.0),
                                                              borderRadius: BorderRadius.circular(0.0),


                                                            ),

                                                            enabledBorder: OutlineInputBorder(
                                                              borderSide:
                                                              const BorderSide(color: Colors.white, width: 0),
                                                              borderRadius: BorderRadius.circular(0.0),



                                                            ),



                                                          ),


                                                        ),

                                                      ),
                                                      // Text( "${eventResponseModel.data.aaData[index].date}",
                                                      //
                                                      //   // " ${widget.bookingUid}",
                                                      //   style: TextStyle(
                                                      //       fontSize: 15,
                                                      //       ),
                                                      // ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(

                                                    "Guest Name: ",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text( "${eventResponseModel.data.aaData[index].guest}",

                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text("Event:",

                                                   // snapshot.data.data.aaData[index].type.toString(),
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text( "${eventResponseModel.data.aaData[index].name}",
                                                      // widget.dataListSM != null
                                                      //     ? widget.dataListSM[0].events.isEmpty
                                                      //     ? " "
                                                      //     : " ${widget.dataListSM[0].events[0].name}"
                                                      //     : widget.aaData != null
                                                      //     ? " ${widget.aaData.firstName ?? ""} ${widget.aaData.lastName ?? ""}"
                                                      // "     VIP Area - Table 1 ",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),



                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(

                                                    "Paid Amount:",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Row(
                                                    children: [
                                                      // Container(
                                                      //     margin: EdgeInsets
                                                      //         .only(left: 10),
                                                      //     height: 25, width: 20,
                                                      //
                                                      //     child: Image.asset(
                                                      //       'assets/images/rr.jpg',)),
                                                      Container(
                                                        child: Text( "${eventResponseModel.data.aaData[index].paidAmount}",
                                                          // widget.dataListSM != null
                                                          //     ? "${widget.dataListSM[0].total??""} GBP"
                                                          //     : widget.aaData != null
                                                          //     ? " ${widget.aaData.total} GBP"

                                                          style: TextStyle(
                                                              fontSize: 15),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Text(

                                                        "No of Tickets:",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            fontWeight: FontWeight
                                                                .bold),
                                                      ),
                                                      Text(  "${eventResponseModel.data.aaData[index].quantity}",
                                                        // widget.dataListSM != null
                                                        //   ? "${widget.dataListSM[index].quantity??""}"
                                                        //   : widget.aaData != null
                                                        //   ? " ${widget.aaData.quantity}"
                                                        //   : " ",


                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            ),
                                                      ),
                                                    ],
                                                  ),

                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Row(
                                                          children: [

                                                            Text(
                                                              "Checked-In:",
                                                              style: TextStyle(
                                                                  fontSize: 15,fontWeight: FontWeight.bold),
                                                            ),

                                                            Text( "${eventResponseModel.data.aaData[index].checkinGuest}",
                                                              // widget.dataListSM != null
                                                              //   ? "${widget.dataListSM[index].checkinStatus}"
                                                              //   : widget.aaData != null
                                                              //   ? " Guest Check-In: "
                                                              //   : " ",
                                                              style: TextStyle(
                                                                  fontSize: 15),
                                                            ),




                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Column(
                                                children: [
                                                  if(eventResponseModel.data.aaData
                                                  [index].checkinStatus ==
                                                      0)...{
                                                    InkWell(
                                                      onTap: () {

                                                        checkInBooking(
                                                            eventResponseModel.data.aaData
                                                            [index].bookingUid,
                                                            eventResponseModel.data.aaData
                                                            [index].date,
                                                            eventResponseModel.data.aaData
                                                            [index].eventTicketId,
                                                            "event");


                                                        // setState((){
                                                        //
                                                        // });
                                                        // Fluttertoast.showToast(
                                                        //
                                                        //     msg:"Checked-In all guest",
                                                        //     toastLength: Toast.LENGTH_SHORT,
                                                        //     timeInSecForIosWeb: 2,
                                                        //     backgroundColor: Colors.black, //ColorRes.primaryColor,
                                                        //     textColor: Colors.white,
                                                        //     fontSize: 20.0,
                                                        //     gravity: ToastGravity.BOTTOM);
                                                      },

                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(bottom: 10,top: 10),
                                                            decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.all(Radius.circular(5)),
                                                              gradient: LinearGradient(colors: [
                                                                Colors.black,
                                                                Colors.black,
                                                                Colors.black
                                                              ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                                            ),
                                                            padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                                                            child: Text(
                                                              "Checked In",
                                                              style: TextStyle(
                                                                //fontSize: 20,
                                                                  color: Colors.white,fontWeight: FontWeight.bold
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  }else...{
                                                    Container(
                                                      margin: EdgeInsets.only(right: 10,bottom: 10),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(right: 20,),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                    margin: EdgeInsets.only(left: 10,top: 5),
                                                                    height: 25,width: 20,

                                                                    child: Image.asset('assets/images/img_6.png', )),
                                                                // Checkbox(
                                                                //
                                                                //   value: _checkbox,
                                                                //   onChanged: (value) {
                                                                //     setState(() {
                                                                //       _checkbox = !_checkbox;
                                                                //     });
                                                                //   },
                                                                // ),
                                                                Text(' Checked: IN',style: TextStyle(fontWeight: FontWeight.bold),),
                                                              ],
                                                            ),
                                                          ),

                                                          Container(
                                                            child: Row(
                                                              children: [
                                                                Text(
                                                                  "Time:",
                                                                  style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                                                ),

                                                                Container(
                                                                  child: Text(
                                                                   "${eventResponseModel.data.aaData[index].checkinTime}",
                                                                    style: TextStyle(fontSize: 15,),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),

                                                        ],
                                                      ),
                                                    ),




                                                  }
                                                ]),

                                          ],
                                        ),
                                      ),
                                    ),


                                  ],
                                ),

                                );


                            }
                          ),







                          );

                      }
                    }



                ),
              ),
              ],
            ),
          ),
      ),
    );
  }
  _selectDate(BuildContext context) async {
    DateTime newSelectedDate = await showDatePicker(
        context: context,
        initialDate: _selectedDate != null ?_selectedDate : DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2040),
        builder: (BuildContext context, Widget child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: Colors.blue.shade900,
                onPrimary: Colors.white,
                surface: Colors.blue.shade900,
                onSurface: Colors.white,
              ),
              dialogBackgroundColor: Colors.blue[500],
            ),
            child: child,
          );
        });

    if (newSelectedDate != null) {
      _selectedDate = newSelectedDate;
      DateFormat formatter = DateFormat('yyyy-MM-dd');
      //final formatter = formatDate(DateTime.now(), [dd, '/', mm, '/', yyyy, ' ', HH, ':' nn]);
     // final DateFormat formatter = DateFormat('dd-MM-yyyy');

      final String formatted = formatter.format(_selectedDate);
      _textEditingController
        ..text = formatted
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _textEditingController.text.length,
            affinity: TextAffinity.upstream));
      print(formatted);
      getDetails(formatted);
      selectedDate = formatted;
    }
  }
  getEventDetails(String currentDate1) {}
}
class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}







