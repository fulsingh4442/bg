import 'dart:async';
import 'dart:convert';
import 'package:bookings/screens/scan_qr.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:lottie/lottie.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/Event_Table_Response.dart';

// https://lizard.reserveyourvenue.com/     live url

Widget showLoader(con) {
  showDialog(
    context: con,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return Center(
          child: Container(
              height: MediaQuery.of(context).size.height / 5,
              width: MediaQuery.of(context).size.width / 5,
              child: Lottie.asset("assets/image/loader.json")));
    },
  );
}

// Future<DetailsResponseModel> details() async {
//   DetailsResponseModel detailsResponse;
//   final response = await http
//       .get(Uri.parse('https://lizard.reserveyourvenue.com/api/booking'));
//   var jsonData = json.decode(response.body);
//   print("calling details api  https://lizard.reserveyourvenue.com/api/booking");
//   print("------------------json data details-----------------$jsonData");
//   if (response.statusCode == 200) {
//     final DetailsResponseModel detailsResponseModel =
//         detailsResponseModelFromJson(response.body);
//     return detailsResponseModel;
//   } else if (response.statusCode == 401) {
//     return detailsResponse;
//   } else {
//     return detailsResponse;
//   }
// }

// Future<DetailsResponseModel> getEventDetails(String currentDate) async {
//   DetailsResponseModel detailsResponse;
//   String Date = currentDate.replaceAll(" 00:00:00.000", "");
//   print(
//       'calling get event details api  https://lizard.reserveyourvenue.com/api/booking/date/${Date.toString()}');
//   print("Date  $Date");
//   final response = await http.get(Uri.parse(
//       'https://lizard.reserveyourvenue.com/api/booking/date/${Date.toString()}'));
//   var jsonData = json.decode(response.body);
//   print("------------------json data get events-----------------$jsonData");
//   if (response.statusCode == 200) {
//     final DetailsResponseModel detailsResponseModel =
//         detailsResponseModelFromJson(response.body);
//     return detailsResponseModel;
//   } else if (response.statusCode == 401) {
//     return detailsResponse;
//   } else {
//     return detailsResponse;
//   }
// }
SharedPreferences Response;
String token;
@override
void initState() {
  // TODO: implement initState
  initState();
  initial();
}

void initial() async {
  final response = await SharedPreferences.getInstance();
  token = response.getString('token').toString();
}




Future<EventTableResponse> scanData(String bookingId) async {
  EventTableResponse eventTableResponse;
  print(
      'calling scandata with url ---> https://app-api.teaseme.co.in/api/booking/' +
          bookingId);
  var requestBody = {
    "booking_id": bookingId
  };
  final tokenResponse = await SharedPreferences.getInstance();
  token = tokenResponse.getString('token').toString();
 print(token);
  final response = await http.post(Uri.parse(
      'https://lizard.reserveyourvenue.com/api/booking/' + bookingId.toString()),
    headers: <String, String>{
      //'Content-Type': 'application/json; charset=UTF-8',
      'token':token
    },
      body: requestBody
  );
  var jsonData = json.decode(response.body);
  print("json response --> $jsonData");
  if (response.statusCode == 200) {
    final EventTableResponse eventTableResponse =
        eventTableResponseFromJson(response.body);
    return eventTableResponse;
  } else if (response.statusCode == 401) {
    return eventTableResponse;
  } else {
    return eventTableResponse;
  }
}









void checkIn(String bookingUid, String arrivedAt, String checkInStatus,
    bool route, BuildContext context) async {
  var requestBody = {
    "booking_uid": bookingUid,
    "arrived_at": arrivedAt,
    "checkin_status": checkInStatus
  };
  final response = await http.post(
      Uri.parse("https://lizard.reserveyourvenue.com/api/booking/updatetime"),
      body: requestBody);
  print(
      "calling check in api  https://lizard.reserveyourvenue.com/api/booking/updatetime");
  print("route ------- $route");

  print(response.statusCode);
  // print(response.body.status);
  var jsonData = json.decode(response.body);
  print(jsonData);
  print(jsonData['status']);

  if (response.statusCode == 200 && jsonData['status'] == true) {
    ShowToast(context);
    // Fluttertoast.showToast(
    //     msg: "Checked In Successfully",
    //     toastLength: Toast.LENGTH_SHORT,
    //     timeInSecForIosWeb: 2,
    //     backgroundColor: Colors.black, //ColorRes.primaryColor,
    //     textColor: Colors.white,
    //     fontSize: 20.0,
    //     gravity: ToastGravity.BOTTOM);
    if (route == false) {
      print(route);
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => ScanQrScreen()),
          (Route<dynamic> route) => false);
    } else {
      print(route);

      Navigator.pop(context, route);
    }
  } else if (response.statusCode == 200 && jsonData['status'] == false) {
    Fluttertoast.showToast(
        msg: "Something Went Wrong",
        toastLength: Toast.LENGTH_SHORT,
        timeInSecForIosWeb: 2,
        backgroundColor: Colors.black, //ColorRes.primaryColor,
        textColor: Colors.white,
        fontSize: 20.0,
        gravity: ToastGravity.BOTTOM);
  } else {
    Fluttertoast.showToast(
        msg: "Something Went Wrong",
        toastLength: Toast.LENGTH_SHORT,
        timeInSecForIosWeb: 2,
        backgroundColor: Colors.black, //ColorRes.primaryColor,
        textColor: Colors.white,
        fontSize: 20.0,
        gravity: ToastGravity.BOTTOM);
  }
  print("this is response body  " + response.body);
}

void ShowToast(BuildContext context) {
  FToast fToast = FToast();
  fToast.init(context);
  return fToast.showToast(
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25.0),
        color: Colors.green,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 12.0,
          ),
          Text("Checked in"),
          SizedBox(width: 2),
          Icon(Icons.check),
        ],
      ),
    ),
  );

}

// Future<TableResponseModel> booking(String currentDate) async {
//   TableResponseModel tableResponse;
//   String Date = currentDate.replaceAll(" 00:00:00.000", "");
//   print(
//       'calling get event details api  https://app-api.teaseme.co.in/api/booking/date/${Date.toString()}');
//   print("Date  $Date");
//   final response = await http.post(Uri.parse(
//       'https://app-api.teaseme.co.in/api/booking/${Date.toString()}'));
//   var jsonData = json.decode(response.body);
//   print("------------------json data get events-----------------$jsonData");
//   if (response.statusCode == 200 && jsonData['status'] == true) {
//     final TableResponseModel tableResponseModel =
//     tableResponseModelFromJson(response.body);
//     return tableResponseModel;
//   } else if (response.statusCode == 401) {
//     return tableResponse;
//   } else {
//     return tableResponse;
//   }
// }





