import 'package:bookings/api_confi/api_client.dart';
import 'package:bookings/demoScreen.dart';
import 'package:flutter/material.dart';
import 'dart:developer';
import 'dart:io';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import '../Home1.dart';
import '../models/Event_Table_Response.dart';
class ScanQrScreen extends StatefulWidget {
  @override
  _ScanQrScreenState createState() => _ScanQrScreenState();
}

class _ScanQrScreenState extends State<ScanQrScreen> {
  Barcode result;
  QRViewController controller;
  final GlobalKey qrKey = GlobalKey(debugLabel:'QR');
  EventTableResponse eventTableResponse;
  bool scanned = false;
  bool isLoading = false;
  bool firstDetection = true;
  bool viaTextField = false;
  int status = 1;
  TextEditingController textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();

    //getDetails();
  }

  scan(String result) async {
    setState(() {
      isLoading = true;
      print("isLoading $isLoading");
    });
    if (scanned == true || viaTextField == true) {
      print("---------calling scan data ----------");
      await scanData(result).then((value) {
        eventTableResponse = value;
      });

      setState(() {
        isLoading = false;
        print("isLoading  -----  $isLoading");
      });

      if (eventTableResponse.data.iTotalRecords == 0) {
        print("invalid ----- ");
        Fluttertoast.showToast(
            msg: "No Data Found !",
            toastLength: Toast.LENGTH_SHORT,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.black, //ColorRes.primaryColor,
            textColor: Colors.white,
            fontSize: 20.0,
            gravity: ToastGravity.BOTTOM);
        // Navigator.of(context).pushAndRemoveUntil(
        //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
        //     (Route<dynamic> route) => false);
        setState(() {
          textEditingController.text = "";
        });
      } else {
        print("here in if");
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Event_Screen1(
                  result,
                  eventTableResponse.data.iTotalRecords.toString(),
                  false,
                  dataListSM: eventTableResponse.data.aaData,
                )));
      }
    }
  }

  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller.pauseCamera();
    }
    controller.resumeCamera();
  }

  @override
  Widget build(BuildContext context) {
    if(controller != null && mounted) {
      controller.pauseCamera();
      controller.resumeCamera();
    }

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => home()),
                      (Route<dynamic> route) => false);
             // Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back)),
        backgroundColor: Colors.black,
        title: Center(
          child: Container(
            margin: EdgeInsets.only(right: 55),
              height: 40,width: 40,

              child: Image.asset('assets/images/appicon.png',color: Colors.white )),
        ),
      // title: Text("Lizard_Lounge",style: TextStyle(fontWeight: FontWeight.bold),),
      ),

      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
          child: SingleChildScrollView(
            child: Column(
              children: [

                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.66,
                  // color:Colors.amber,
                  child: isLoading
                      ? Center(child: CircularProgressIndicator())
                      : _buildQrView(context),
                ),
                SizedBox(height: 20,),
                Row(
                    children: <Widget>[
                      Expanded(
                          child: Container(margin: EdgeInsets.only(left: 40),
                              child: Divider(color: Colors.black,))
                      ),

                      Text("OR"),

                      Expanded(
                          child: Container(margin: EdgeInsets.only(right: 40),
                              child: Divider(color: Colors.black,))
                      ),
                    ]
                ),
                SizedBox(height: 20,),

                // Expanded(flex: 4, child: _buildQrView(context)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.67,
                      height: MediaQuery.of(context).size.height * 0.07,
                      margin: EdgeInsets.only(top: 9),
                      child: TextField(
                        controller: textEditingController,
                        style: TextStyle(color: Colors.black),
                        decoration: InputDecoration(
                          prefixIcon: Container(
                            child: new Icon(
                              Icons.search,
                              color: Colors.grey,
                            ),
                          ),

                          labelText: "Search via Booking ID",labelStyle: TextStyle(color: Colors.grey,),
                          contentPadding: EdgeInsets.only(top: 15),
                          hintText: " Booking ID.....",suffixStyle: TextStyle(fontWeight: FontWeight.bold,),

                          fillColor: Colors.black,
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: Colors.black, width: 0.5),
                            borderRadius: BorderRadius.circular(0.0),

                          ),


                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: Colors.black, width: 0.5),
                            borderRadius: BorderRadius.circular(0.0),

                          ),

                        ),

                      ),
                    ),
                    InkWell(
                      onTap: () {
                        print("hiiii");
                        setState(() {
                          print("inside ontap");
                          viaTextField = true;
                          print(textEditingController.text);
                          scan(textEditingController.text);
                        });
                      },
                      child: Container(

                        alignment: Alignment.center,
                        height:48,
                        width: MediaQuery.of(context).size.width * 0.12,
                       // padding: EdgeInsets.fromLTRB(5, 15, 5, 5),
                        margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        decoration: BoxDecoration(
                          // color: Colors.amber,
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                          gradient: LinearGradient(
                              colors: [
                                Colors.black,
                                Colors.black,
                                Colors.black
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter),
                        ),
                        child: Text(
                          "Go",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                // Center(child: Text("Search via Booking ID",style: TextStyle(fontWeight: FontWeight.bold),))
              ],
            ),
          ),
        ),
      ),




    );

  }

  Widget _buildQrView(BuildContext context) {

    // For this example we check how width or tall the device is and change the scanArea and overlay accordingly.
    var scanArea = (MediaQuery.of(context).size.width < 400 ||
            MediaQuery.of(context).size.height < 400)
        ? 180.0
        : 320.0;
    // To ensure the Scanner view is properly sizes after rotation
    // we need to listen for Flutter SizeChanged notification and update controller
    return Padding(
      padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
      child: QRView(
        key: qrKey,
        onQRViewCreated: _onQRViewCreated,
        overlay: QrScannerOverlayShape(
            borderColor: Colors.red,
            borderRadius: 5,
            borderLength: 30,
            borderWidth: 5,

            cutOutSize: scanArea),
        onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
      ),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    setState(() {
      this.controller = controller;
      firstDetection = true;
    });
    controller.scannedDataStream.listen((scanData) async {
      print("scanData  -----  $scanData");
      if (firstDetection) {
        print("firstDetection  -----  $firstDetection");
        setState(() {
          firstDetection = false;
          print("-----------scan data------------${scanData.code}");
          result = scanData;
          print("-----------result------------${result.code}");
          scanned = true;
          print(scanned);
          print("firstDetection  -----  $firstDetection");
          scan(result.code);
        });
      }
    });
  }

  void _onPermissionSet(BuildContext context,QRViewController ctrl, bool p) {
    log('${DateTime.now().toIso8601String()}_onPermissionSet $p');
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),
      );
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

 }




//
// import 'dart:async';
//
// import 'package:bookings/api_confi/api_client.dart';
// import 'package:bookings/models/details_response_model.dart';
// import 'package:bookings/models/single_item_response_model.dart';
// import 'package:bookings/screens/details.dart';
// import 'package:bookings/screens/guest_details_checkin.dart';
// import 'package:bookings/screens/guest_details_close.dart';
// import 'package:flutter/material.dart';
// import 'dart:developer';
// import 'dart:io';
//
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:qr_code_scanner/qr_code_scanner.dart';
//
// class ScanQrScreen extends StatefulWidget {
//   @override
//   _ScanQrScreenState createState() => _ScanQrScreenState();
// }
//
// class _ScanQrScreenState extends State<ScanQrScreen> {
//   Barcode result;
//   QRViewController controller;
//   final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
//   SingleItemResponseModel singleItemResponseModel;
//   bool scanned = false;
//   bool isLoading = false;
//   bool firstDetection = true;
//   bool viaTextField = false;
//   int status = 1;
//   DetailsResponseModel detailsResponseModel;
//   Future _getDetails;
//   TextEditingController textEditingController = TextEditingController();
//
//   getDetails() {
//     setState(() {
//       _getDetails = details().then((value) {
//         detailsResponseModel = value;
//       });
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//
//     getDetails();
//   }
//
//   scan(String result) async {
//     setState(() {
//       isLoading = true;
//       print("isLoading  -----  $isLoading");
//     });
//     if (scanned == true || viaTextField == true) {
//       print("---------calling scan data ----------");
//       await scanData(result).then((value) {
//         singleItemResponseModel = value;
//       });
//       setState(() {
//         isLoading = false;
//         print("isLoading  -----  $isLoading");
//       });
//       if (singleItemResponseModel.data.iTotalRecords == 0) {
//         print("invalid ----- ");
//         Fluttertoast.showToast(
//             msg: "No Data Found !",
//             toastLength: Toast.LENGTH_SHORT,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.black, //ColorRes.primaryColor,
//             textColor: Colors.white,
//             fontSize: 20.0,
//             gravity: ToastGravity.BOTTOM);
//         // Navigator.of(context).pushAndRemoveUntil(
//         //     MaterialPageRoute(builder: (context) => ScanQrScreen()),
//         //     (Route<dynamic> route) => false);
//         setState(() {
//           textEditingController.text = "";
//         });
//       } else {
//         if (singleItemResponseModel.data.aaData[0].checkinStatus == "0") {
//           print("here in if");
//           Navigator.push(
//               context,
//               MaterialPageRoute(
//                   builder: (context) => GuestDetailsCheckIn(
//                     result,
//                     singleItemResponseModel.data.iTotalRecords.toString(),
//                     false,
//                     dataListSM: singleItemResponseModel.data.aaData,
//                   )));
//         } else {
//           print("here in else");
//           Navigator.push(
//               context,
//               MaterialPageRoute(
//                   builder: (context) => GuestDetailsClose(
//                     result,
//                     singleItemResponseModel.data.iTotalRecords.toString(),
//                     aaDataListSM: singleItemResponseModel.data.aaData,
//                   )));
//         }
//       }
//     }
//   }
//
//   @override
//   void reassemble() {
//     super.reassemble();
//     if (Platform.isAndroid) {
//       controller.pauseCamera();
//     }
//     controller.resumeCamera();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Padding(
//           padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: [
//                     InkWell(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => DetailsScreen()));
//                       },
//                       child: Container(
//                         padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
//                         decoration: BoxDecoration(
//                           color: Colors.amber,
//                           borderRadius: BorderRadius.all(Radius.circular(10)),
//                           gradient: LinearGradient(
//                               colors: [
//                                 Colors.white,
//                                 Colors.blue.shade900,
//                                 Colors.lightBlue
//                               ],
//                               begin: Alignment.topCenter,
//                               end: Alignment.bottomCenter),
//                         ),
//                         child: Text(
//                           "Today's List",
//                           style: TextStyle(
//                             fontSize: 20,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                     Container(
//                       height: MediaQuery.of(context).size.height * 0.07,
//                       width: MediaQuery.of(context).size.width * 0.17,
//                       decoration: BoxDecoration(
//                         image: DecorationImage(
//                           fit: BoxFit.fill,
//                           image: AssetImage('assets/images/appicon.png'),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 Container(
//                   width: MediaQuery.of(context).size.width,
//                   height: MediaQuery.of(context).size.height * 0.70,
//                   // color:Colors.amber,
//                   child: isLoading
//                       ? Center(child: CircularProgressIndicator())
//                       : _buildQrView(context),
//                 ),
//
//                 // Expanded(flex: 4, child: _buildQrView(context)),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                       width: MediaQuery.of(context).size.width * 0.50,
//                       height: MediaQuery.of(context).size.height * 0.07,
//                       child: TextField(
//                         controller: textEditingController,
//                         style: TextStyle(color: Colors.black),
//                         decoration: InputDecoration(
//                           fillColor: Colors.black,
//                           focusedBorder: OutlineInputBorder(
//                             borderSide: const BorderSide(
//                                 color: Colors.black, width: 0.5),
//                             borderRadius: BorderRadius.circular(25.0),
//                           ),
//                           enabledBorder: OutlineInputBorder(
//                             borderSide: const BorderSide(
//                                 color: Colors.black, width: 0.5),
//                             borderRadius: BorderRadius.circular(25.0),
//                           ),
//                         ),
//                       ),
//                     ),
//                     InkWell(
//                       onTap: () {
//                         print("hiiii");
//                         setState(() {
//                           print("inside ontap");
//                           viaTextField = true;
//                           print(textEditingController.text);
//                           scan(textEditingController.text);
//                         });
//                       },
//                       child: Container(
//                         padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                         margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                         decoration: BoxDecoration(
//                           // color: Colors.amber,
//                           borderRadius: BorderRadius.all(Radius.circular(20)),
//                           gradient: LinearGradient(
//                               colors: [
//                                 Colors.white,
//                                 Colors.blue.shade900,
//                                 Colors.lightBlue
//                               ],
//                               begin: Alignment.topCenter,
//                               end: Alignment.bottomCenter),
//                         ),
//                         child: Text(
//                           "Go",
//                           style: TextStyle(
//                             fontSize: 20,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 Center(child: Text("Search via Booking ID"))
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildQrView(BuildContext context) {
//     // For this example we check how width or tall the device is and change the scanArea and overlay accordingly.
//     var scanArea = (MediaQuery.of(context).size.width < 400 ||
//         MediaQuery.of(context).size.height < 400)
//         ? 150.0
//         : 300.0;
//     // To ensure the Scanner view is properly sizes after rotation
//     // we need to listen for Flutter SizeChanged notification and update controller
//     return Padding(
//       padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
//       child: QRView(
//         key: qrKey,
//         onQRViewCreated: _onQRViewCreated,
//         overlay: QrScannerOverlayShape(
//             borderColor: Colors.red,
//             borderRadius: 10,
//             borderLength: 30,
//             borderWidth: 10,
//             cutOutSize: scanArea),
//         onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
//       ),
//     );
//   }
//
//   void _onQRViewCreated(QRViewController controller) {
//     setState(() {
//       this.controller = controller;
//       firstDetection = true;
//     });
//     controller.scannedDataStream.listen((scanData) async {
//       print("scanData  -----  $scanData");
//       if (firstDetection) {
//         print("firstDetection  -----  $firstDetection");
//         setState(() {
//           firstDetection = false;
//           print("-----------scan data------------${scanData.code}");
//           result = scanData;
//           print("-----------result------------${result.code}");
//           scanned = true;
//           print(scanned);
//           print("firstDetection  -----  $firstDetection");
//           scan(result.code);
//         });
//       }
//     });
//   }
//
//   void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
//     log('${DateTime.now().toIso8601String()}_onPermissionSet $p');
//     if (!p) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('no Permission')),
//       );
//     }
//   }
//
//   @override
//   void dispose() {
//     controller?.dispose();
//     super.dispose();
//   }
// }


