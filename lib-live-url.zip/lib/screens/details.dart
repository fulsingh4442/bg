// import 'dart:async';
//
// import 'package:bookings/api_confi/api_client.dart';
// import 'package:bookings/models/details_response_model.dart';
// import 'package:bookings/screens/guest_details_checkin.dart';
// import 'package:bookings/screens/guest_details_close.dart';
// import 'package:bookings/screens/scan_qr.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
//
// class DetailsScreen extends StatefulWidget {
//   @override
//   _DetailsScreenState createState() => _DetailsScreenState();
// }
//
// class _DetailsScreenState extends State<DetailsScreen> {
//   DetailsResponseModel detailsResponseModel;
//   Future _getDetails;
//   DateTime _selectedDate;
//   String _formatted;
//   TextEditingController _textEditingController = TextEditingController();
//
//   // getDetails() {
//   //   setState(() {
//   //     _getDetails = details().then((value) {
//   //       detailsResponseModel = value;
//   //       print(
//   //           "---------------------------${detailsResponseModel.data.aaData[0].category}");
//   //     });
//   //   });
//   // }
//
//   getDetails(String currentDate) {
//     print("inside get details");
//     setState(() {
//       _getDetails = getEventDetails(currentDate).then((value) {
//         detailsResponseModel = value;
//       });
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     if (_textEditingController.text.isEmpty) {
//       final DateFormat _formatter = DateFormat('yyyy-MM-dd');
//       _textEditingController.text = _formatter.format(DateTime.now());
//       _formatted =
//           _formatter.format(DateTime.parse(_textEditingController.text));
//       print("formatted ---- $_formatted");
//       getDetails(_formatted);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         body: SafeArea(
//           child: Column(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: [
//                     InkWell(
//                       onTap: () {
//                         Navigator.of(context).pushAndRemoveUntil(
//                             MaterialPageRoute(
//                                 builder: (context) => ScanQrScreen()),
//                             (Route<dynamic> route) => false);
//                       },
//                       child: Container(
//                           padding: EdgeInsets.fromLTRB(20, 15, 0, 20),
//                           child: Icon(Icons.arrow_back_ios)),
//                     ),
//                     Container(
//                       decoration: BoxDecoration(
//                         // color: Colors.amber,
//                         borderRadius: BorderRadius.all(Radius.circular(10)),
//                         gradient: LinearGradient(
//                             colors: [
//                               Colors.white,
//                               Colors.blue.shade900,
//                               Colors.lightBlue
//                             ],
//                             begin: Alignment.topCenter,
//                             end: Alignment.bottomCenter),
//                       ),
//                       padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
//                       child: Text(
//                         "Today's List",
//                         style: TextStyle(
//                           fontSize: 20,
//                           color: Colors.white,
//                         ),
//                       ),
//                     ),
//                     Container(
//                       height: MediaQuery.of(context).size.height * 0.06,
//                       width: MediaQuery.of(context).size.width * 0.15,
//                       // color: Colors.lightBlue,
//                       decoration: BoxDecoration(
//                         image: DecorationImage(
//                           fit: BoxFit.fill,
//                           image: AssetImage('assets/images/appicon.png'),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Container(
//                     width: MediaQuery.of(context).size.width * 0.35,
//                     margin: EdgeInsets.only(top: 18),
//                     child: TextField(
//                       focusNode: AlwaysDisabledFocusNode(),
//                       controller: _textEditingController,
//                       onTap: () {
//                         _selectDate(context);
//                       },
//                       decoration: InputDecoration(
//                         fillColor: Colors.black,
//                         focusedBorder: OutlineInputBorder(
//                           borderSide:
//                               const BorderSide(color: Colors.black, width: 0.5),
//                           borderRadius: BorderRadius.circular(15.0),
//                         ),
//                         enabledBorder: OutlineInputBorder(
//                           borderSide:
//                               const BorderSide(color: Colors.black, width: 0.5),
//                           borderRadius: BorderRadius.circular(15.0),
//                         ),
//                       ),
//                     ),
//                   ),
//
//                   // InkWell(
//                   //   onTap: () {
//                   //     print(_selectedDate);
//                   //     _selectedDate == null
//                   //         ? getDetails(_formatted)
//                   //         : getDetails(_selectedDate.toString());
//                   //   },
//                   //   child: Container(
//                   //     padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                   //     margin: EdgeInsets.fromLTRB(10, 25, 10, 10),
//                   //     decoration: BoxDecoration(
//                   //       // color: Colors.amber,
//                   //       borderRadius: BorderRadius.all(Radius.circular(20)),
//                   //       gradient: LinearGradient(
//                   //           colors: [
//                   //             Colors.white,
//                   //             Colors.blue.shade900,
//                   //             Colors.lightBlue
//                   //           ],
//                   //           begin: Alignment.topCenter,
//                   //           end: Alignment.bottomCenter),
//                   //     ),
//                   //     child: Text(
//                   //       "Go",
//                   //       style: TextStyle(
//                   //         fontSize: 20,
//                   //         color: Colors.white,
//                   //       ),
//                   //     ),
//                   //   ),
//                   // ),
//                 ],
//               ),
//               SizedBox(
//                 height: 10,
//               ),
//               // Container(
//               //   padding: EdgeInsets.fromLTRB(50, 10, 50, 10),
//               //   // width: MediaQuery.of(context).size.width * 0.8,
//               //   color: Colors.blue.shade100,
//               //   child: Text(
//               //     "Guest Name | No of Tickets | Status",
//               //     style: TextStyle(fontSize: 15),
//               //   ),
//               // ),
//               // Center(child: Text("No Data Found !")),
//
//               FutureBuilder(
//                   future: _getDetails,
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.waiting) {
//                       return CircularProgressIndicator();
//                     } else {
//                       return Container(
//                         // color:Colors.red,
//                         padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
//                         margin: EdgeInsets.only(top: 20),
//                         width: MediaQuery.of(context).size.width * 0.8,
//                         height: MediaQuery.of(context).size.height * 0.58,
//                         child: detailsResponseModel.data.iTotalRecords == 0
//                             ? Text("No Data Found !")
//                             : ListView.builder(
//                                 shrinkWrap: true,
//                                 scrollDirection: Axis.vertical,
//                                 itemCount:
//                                     detailsResponseModel.data.aaData.length,
//                                 itemBuilder: (context, index) {
//                                   return GestureDetector(
//                                     onTap: () {
//                                       print(detailsResponseModel
//                                           .data.aaData[index].checkinStatus);
//                                       if (detailsResponseModel.data
//                                               .aaData[index].checkinStatus ==
//                                           "0") {
//                                         print('hii');
//                                         print(
//                                           detailsResponseModel
//                                               .data.aaData[index].events,
//                                         );
//                                         Navigator.push(
//                                             context,
//                                             MaterialPageRoute(
//                                                 builder: (context) =>
//                                                     GuestDetailsCheckIn(
//                                                       detailsResponseModel
//                                                           .data
//                                                           .aaData[index]
//                                                           .bookingUid,
//                                                       detailsResponseModel
//                                                           .data.iTotalRecords
//                                                           .toString(),
//                                                       true,
//                                                      aaData:
//                                                           detailsResponseModel
//                                                               .data
//                                                               .aaData[index],
//                                                       guestname: (detailsResponseModel
//                                                                   .data
//                                                                   .aaData[index]
//                                                                   .firstName ??
//                                                               "") +
//                                                           (detailsResponseModel
//                                                                   .data
//                                                                   .aaData[index]
//                                                                   .lastName ??
//                                                               ""),
//                                                     ))).then((value) {
//                                           print("value ------  $value");
//                                           if (value == true) {
//                                             print(_textEditingController.text);
//                                             getDetails(
//                                                 _textEditingController.text);
//                                           }
//                                         });
//                                       } else {
//                                         Navigator.push(
//                                             context,
//                                             MaterialPageRoute(
//                                                 builder: (context) =>
//                                                     GuestDetailsClose(
//                                                       detailsResponseModel
//                                                           .data
//                                                           .aaData[index]
//                                                           .bookingUid,
//                                                       detailsResponseModel
//                                                           .data.iTotalRecords
//                                                           .toString(),
//                                                       aaData:
//                                                           detailsResponseModel
//                                                               .data
//                                                               .aaData[index],
//                                                       guestname: (detailsResponseModel
//                                                                   .data
//                                                                   .aaData[index]
//                                                                   .firstName ??
//                                                               "") +
//                                                           (detailsResponseModel
//                                                                   .data
//                                                                   .aaData[index]
//                                                                   .lastName ??
//                                                               ""),
//                                                     )));
//                                       }
//                                     },
//                                     child: Card(
//                                       elevation: 5,
//                                       shape: RoundedRectangleBorder(
//                                         borderRadius: BorderRadius.circular(10),
//                                       ),
//                                       child: Container(
//                                         margin:
//                                             EdgeInsets.fromLTRB(10, 10, 10, 10),
//                                         // color: Colors.amber,
//                                         child: Column(
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.start,
//                                           children: [
//                                             Row(
//                                               children: [
//                                                 Text("Guest Name : ${detailsResponseModel.data.aaData[index].firstName ?? ""}" +
//                                                     "${detailsResponseModel.data.aaData[index].lastName ?? ""}"),
//                                               ],
//                                             ),
//                                             Row(
//                                               children: [
//                                                 Text(
//                                                     "Booking Id : ${detailsResponseModel.data.aaData[index].bookingUid}")
//                                               ],
//                                             ),
//                                             Row(
//                                               children: [
//                                                 Text(detailsResponseModel
//                                                             .data
//                                                             .aaData[index]
//                                                             .quantity ==
//                                                         null
//                                                     ? "Number of Tickets : "
//                                                     : "Number of Tickets : ${detailsResponseModel.data.aaData[index].quantity}")
//                                               ],
//                                             ),
//                                             // Row(
//                                             //   children: [
//                                             //     Text(
//                                             //         "Event Name : ${detailsResponseModel.data.aaData[index].events[index].name}")
//                                             //   ],
//                                             // ),
//                                             // Row(
//                                             //   children: [
//                                             //     Text(
//                                             //         "Date : ${detailsResponseModel.data.aaData[index].events[index].createdAt}")
//                                             //   ],
//                                             // ),
//                                             Row(
//                                               children: [
//                                                 Text(detailsResponseModel
//                                                             .data
//                                                             .aaData[index]
//                                                             .finalrate !=
//                                                         null
//                                                     ? "Amount Paid : ${detailsResponseModel.data.aaData[index].finalrate} GBP"
//                                                     : "Amount Paid : "),
//                                               ],
//                                             ),
//                                             Row(
//                                               children: [
//                                                 Text(detailsResponseModel
//                                                             .data
//                                                             .aaData[index]
//                                                             .checkinStatus ==
//                                                         "1"
//                                                     ? "Status : Checked In"
//                                                     : "Status : Not Checked In")
//                                               ],
//                                             ),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                   );
//                                 }),
//                       );
//                     }
//                   }),
//             ],
//           ),
//         ));
//   }
//
//   _selectDate(BuildContext context) async {
//     DateTime newSelectedDate = await showDatePicker(
//         context: context,
//         initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
//         firstDate: DateTime(2000),
//         lastDate: DateTime(2040),
//         builder: (BuildContext context, Widget child) {
//           return Theme(
//             data: ThemeData.dark().copyWith(
//               colorScheme: ColorScheme.dark(
//                 primary: Colors.blue.shade900,
//                 onPrimary: Colors.white,
//                 surface: Colors.blue.shade900,
//                 onSurface: Colors.white,
//               ),
//               dialogBackgroundColor: Colors.blue[500],
//             ),
//             child: child,
//           );
//         });
//
//     if (newSelectedDate != null) {
//       _selectedDate = newSelectedDate;
//       final DateFormat formatter = DateFormat('yyyy-MM-dd');
//       final String formatted = formatter.format(_selectedDate);
//       _textEditingController
//         ..text = formatted
//         ..selection = TextSelection.fromPosition(TextPosition(
//             offset: _textEditingController.text.length,
//             affinity: TextAffinity.upstream));
//       print(formatted);
//       getDetails(formatted);
//     }
//   }
// }
//
// class AlwaysDisabledFocusNode extends FocusNode {
//   @override
//   bool get hasFocus => false;
// }
// // ///////////////////////////////////////////////////////////////////////////////////////////////////
// // import 'package:flutter/material.dart';
// //
// // import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart'
// //     show CalendarCarousel;
// // import 'package:flutter_calendar_carousel/classes/event.dart';
// // import 'package:flutter_calendar_carousel/classes/event_list.dart';
// // import 'package:intl/intl.dart' show DateFormat;
// //
// // class MyHomePage extends StatefulWidget {
// //   MyHomePage({Key key, this.title}) : super(key: key);
// //
// //   final String title;
// //
// //   @override
// //   _MyHomePageState createState() =>  _MyHomePageState();
// // }
// //
// // class _MyHomePageState extends State<MyHomePage> {
// //   DateTime _currentDate = DateTime(2020, 2, 17);
// //   DateTime _currentDate2 = DateTime(2020, 2, 17);
// //   String _currentMonth = DateFormat.yMMM().format(DateTime(2020, 2, 17));
// //   DateTime _targetDateTime = DateTime(2020, 2, 17);
// // //  List<DateTime> _markedDate = [DateTime(2018, 9, 20), DateTime(2018, 10, 11)];
// //   static Widget _eventIcon =  Container(
// //     decoration:  BoxDecoration(
// //         color: Colors.white,
// //         borderRadius: BorderRadius.all(Radius.circular(1000)),
// //         border: Border.all(color: Colors.blue, width: 2.0)),
// //     child:  Icon(
// //       Icons.person,
// //       color: Colors.amber,
// //     ),
// //   );
// //
// //   EventList<Event> _markedDateMap = EventList<Event>();
// //   CalendarCarousel _calendarCarousel, _calendarCarouselNoHeader;
// //
// //   @override
// //   void initState() {
// //     addMarker(DateTime(2020, 2, 03));
// //     super.initState();
// //   }
// //
// //   addMarker(DateTime startEventDateTime) {
// //
// //     var eventDateTime = startEventDateTime;
// //
// //     for(int i=0; i<5; i++) {
// //       if(eventDateTime.day == 1) {
// //         eventDateTime = eventDateTime.add(Duration(days: (4)));
// //       } else {
// //         eventDateTime = eventDateTime.add(Duration(days: (5)));
// //       }
// //       print(eventDateTime.toLocal());
// //       _markedDateMap.add(
// //           eventDateTime,
// //           Event(
// //             date: eventDateTime,
// //             title: 'Event $i',
// //             icon: _eventIcon,
// //           ));
// //
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     /// Example with custom icon
// //     _calendarCarousel = CalendarCarousel<Event>(
// //       onDayPressed: (DateTime date, List<Event> events) {
// //         this.setState(() => _currentDate = date);
// //         events.forEach((event) => print(event.title));
// //       },
// //       weekendTextStyle: TextStyle(
// //         color: Colors.red,
// //       ),
// //       thisMonthDayBorderColor: Colors.grey,
// // //          weekDays: null, /// for pass null when you do not want to render weekDays
// //       headerText: 'Custom Header',
// // //          markedDates: _markedDate,
// //       weekFormat: true,
// //       markedDatesMap: _markedDateMap,
// //       height: 200.0,
// //       selectedDateTime: _currentDate2,
// //       showIconBehindDayText: true,
// // //          daysHaveCircularBorder: false, /// null for not rendering any border, true for circular border, false for rectangular border
// //       customGridViewPhysics: NeverScrollableScrollPhysics(),
// //       markedDateShowIcon: true,
// //       markedDateIconMaxShown: 2,
// //       selectedDayTextStyle: TextStyle(
// //         color: Colors.yellow,
// //       ),
// //       todayTextStyle: TextStyle(
// //         color: Colors.blue,
// //       ),
// //       markedDateIconBuilder: (event) {
// //         return event.icon;
// //       },
// //       minSelectedDate: _currentDate.subtract(Duration(days: 360)),
// //       maxSelectedDate: _currentDate.add(Duration(days: 360)),
// //       todayButtonColor: Colors.transparent,
// //       todayBorderColor: Colors.green,
// //       markedDateMoreShowTotal:
// //       false, // null for not showing hidden events indicator
// // //          markedDateIconMargin: 9,
// // //          markedDateIconOffset: 3,
// //     );
// //
// //     /// Example Calendar Carousel without header and custom prev & next button
// //     _calendarCarouselNoHeader = CalendarCarousel<Event>(
// //       todayBorderColor: Colors.green,
// //       onDayPressed: (DateTime date, List<Event> events) {
// //         this.setState(() => _currentDate2 = date);
// //         events.forEach((event) => print(event.title));
// //       },
// //       daysHaveCircularBorder: true,
// //       showOnlyCurrentMonthDate: false,
// //       weekendTextStyle: TextStyle(
// //         color: Colors.red,
// //       ),
// //       thisMonthDayBorderColor: Colors.grey,
// //       weekFormat: false,
// // //      firstDayOfWeek: 4,
// //       markedDatesMap: _markedDateMap,
// //       height: 420.0,
// //       selectedDateTime: _currentDate2,
// //       targetDateTime: _targetDateTime,
// //       customGridViewPhysics: NeverScrollableScrollPhysics(),
// //       markedDateCustomShapeBorder: CircleBorder(
// //           side: BorderSide(color: Colors.yellow)
// //       ),
// //       markedDateCustomTextStyle: TextStyle(
// //         fontSize: 18,
// //         color: Colors.blue,
// //       ),
// //       showHeader: false,
// //       // markedDateIconBuilder: (event) {
// //       //   return Container(
// //       //     color: Colors.blue,
// //       //   );
// //       // },
// //       todayTextStyle: TextStyle(
// //         color: Colors.blue,
// //       ),
// //       todayButtonColor: Colors.yellow,
// //       selectedDayTextStyle: TextStyle(
// //         color: Colors.yellow,
// //       ),
// //       minSelectedDate: _currentDate.subtract(Duration(days: 360)),
// //       maxSelectedDate: _currentDate.add(Duration(days: 360)),
// //       prevDaysTextStyle: TextStyle(
// //         fontSize: 16,
// //         color: Colors.pinkAccent,
// //       ),
// //       inactiveDaysTextStyle: TextStyle(
// //         color: Colors.tealAccent,
// //         fontSize: 16,
// //       ),
// //       onCalendarChanged: (DateTime date) {
// //         this.setState(() {
// //           _targetDateTime = date;
// //           _currentMonth = DateFormat.yMMM().format(_targetDateTime);
// //         });
// //       },
// //       onDayLongPressed: (DateTime date) {
// //         print('long pressed date $date');
// //       },
// //     );
// //
// //     return  Scaffold(
// //         appBar:  AppBar(
// //           title:  Text(widget.title),
// //         ),
// //         body: SingleChildScrollView(
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             mainAxisAlignment: MainAxisAlignment.start,
// //             children: <Widget>[
// //               //custom icon
// //               Container(
// //                 margin: EdgeInsets.symmetric(horizontal: 16.0),
// //                 child: _calendarCarousel,
// //               ), // This trailing comma makes auto-formatting nicer for build methods.
// //               //custom icon without header
// //               Container(
// //                 margin: EdgeInsets.only(
// //                   top: 30.0,
// //                   bottom: 16.0,
// //                   left: 16.0,
// //                   right: 16.0,
// //                 ),
// //                 child:  Row(
// //                   children: <Widget>[
// //                     Expanded(
// //                         child: Text(
// //                           _currentMonth,
// //                           style: TextStyle(
// //                             fontWeight: FontWeight.bold,
// //                             fontSize: 24.0,
// //                           ),
// //                         )),
// //                     FlatButton(
// //                       child: Text('PREV'),
// //                       onPressed: () {
// //                         setState(() {
// //                           _targetDateTime = DateTime(_targetDateTime.year, _targetDateTime.month -1);
// //                           _currentMonth = DateFormat.yMMM().format(_targetDateTime);
// //                         });
// //                       },
// //                     ),
// //                     FlatButton(
// //                       child: Text('NEXT'),
// //                       onPressed: () {
// //                         setState(() {
// //                           _targetDateTime = DateTime(_targetDateTime.year, _targetDateTime.month +1);
// //                           _currentMonth = DateFormat.yMMM().format(_targetDateTime);
// //                         });
// //                       },
// //                     )
// //                   ],
// //                 ),
// //               ),
// //               Container(
// //                 margin: EdgeInsets.symmetric(horizontal: 16.0),
// //                 child: _calendarCarouselNoHeader,
// //               ), //
// //             ],
// //           ),
// //         ));
// //   }
// // }

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TestPickerWidget extends StatefulWidget {
  @override
  _TestPickerWidgetState createState() => _TestPickerWidgetState();
}

class _TestPickerWidgetState extends State<TestPickerWidget> {
  DateTime _selectedDate;
  TextEditingController _textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: TextField(
          focusNode: AlwaysDisabledFocusNode(),
          controller: _textEditingController,
          onTap: () {
            _selectDate(context);
          },
        ),
      ),
    );
  }

  _selectDate(BuildContext context) async {
    DateTime newSelectedDate = await showDatePicker(
        context: context,
        initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2040),
        builder: (BuildContext context, Widget child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: Colors.deepPurple,
                onPrimary: Colors.white,
                surface: Colors.blueGrey,
                onSurface: Colors.yellow,
              ),
              dialogBackgroundColor: Colors.blue[500],
            ),
            child: child,
          );
        });

    if (newSelectedDate != null) {
      _selectedDate = newSelectedDate;
      _textEditingController
        ..text = DateFormat.yMMMd().format(_selectedDate)
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _textEditingController.text.length,
            affinity: TextAffinity.upstream));
    }
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}