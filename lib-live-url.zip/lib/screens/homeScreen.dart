import 'dart:async';

import 'package:bookings/api_confi/api_client.dart';
import 'package:bookings/models/details_response_model.dart';
import 'package:bookings/models/single_item_response_model.dart';
import 'package:bookings/screens/guest_details_checkin.dart';
import 'package:bookings/screens/guest_details_close.dart';
import 'package:bookings/screens/scan_qr.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DetailsScreen1 extends StatefulWidget {
  String bookingUid;
  String totalRecords;
  String guestname;
  List<AaDatumSM> dataListSM;
  AaDatum aaData;
  bool fromDetails;
  DetailsScreen1(
      this.bookingUid,
      this.totalRecords,
      this.fromDetails, {
        this.dataListSM,
        this.aaData,
        this.guestname,
      });
  @override
  _DetailsScreen1State createState() => _DetailsScreen1State();
}

class _DetailsScreen1State extends State<DetailsScreen1> {
  DetailsResponseModel detailsResponseModel;
  Future _getDetails;
  DateTime _selectedDate;
  String _formatted;
  TextEditingController _textEditingController = TextEditingController();

  // getDetails() {
  //   setState(() {
  //     _getDetails = details().then((value) {
  //       detailsResponseModel = value;
  //       print(
  //           "---------------------------${detailsResponseModel.data.aaData[0].category}");
  //     });
  //   });
  // }

  getDetails(String currentDate) {
    print("inside get details");
    setState(() {
      _getDetails = getEventDetails(currentDate).then((value) {
        detailsResponseModel = value;
      });
    });
  }

  @override
  void initState() {
    super.initState();
    if (_textEditingController.text.isEmpty) {
      final DateFormat _formatter = DateFormat('yyyy-MM-dd');
      _textEditingController.text = _formatter.format(DateTime.now());
      _formatted =
          _formatter.format(DateTime.parse(_textEditingController.text));
      print("formatted ---- $_formatted");
      getDetails(_formatted);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: InkWell(
        onTap: () {
          Navigator.pop(context);
        },
          child: Icon(Icons.arrow_back)),
        title: Center(
          child: Container(
            margin: EdgeInsets.only(right: 55),
            height: 45,width: 45,

              child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
        ),
      ),
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [



              Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // InkWell(
                    //   onTap: () {
                    //     Navigator.of(context).pushAndRemoveUntil(
                    //         MaterialPageRoute(
                    //             builder: (context) => ScanQrScreen()),
                    //             (Route<dynamic> route) => false);
                    //   },
                    //   child: Container(
                    //       padding: EdgeInsets.fromLTRB(20, 15, 0, 20),
                    //       child: Icon(Icons.arrow_back_ios)),
                    // ),

                    // Container(
                    //   height: MediaQuery.of(context).size.height * 0.06,
                    //   width: MediaQuery.of(context).size.width * 0.15,
                    //   // color: Colors.lightBlue,
                    //   decoration: BoxDecoration(
                    //     image: DecorationImage(
                    //       fit: BoxFit.fill,
                    //       image: AssetImage('assets/images/appicon.png'),
                    //     ),
                    //   ),
                    // ),

                        Container(
                          width: MediaQuery.of(context).size.width * 0.65,
                          height: MediaQuery.of(context).size.height * 0.07,
                          margin: EdgeInsets.only(top: 0,left: 0),
                          child: TextField(

                            focusNode: AlwaysDisabledFocusNode(),
                            controller: _textEditingController,
                            onTap: () {
                              _selectDate(context);
                            },

                            decoration: InputDecoration(
                              suffixIcon: Icon(Icons.calendar_month_outlined,color: Colors.blue,),

                              fillColor: Colors.white,

                              focusedBorder: OutlineInputBorder(

                                borderSide:
                                const BorderSide(color: Colors.black, width: 0.5),
                                borderRadius: BorderRadius.circular(10.0),


                              ),

                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Colors.black, width: 0.5),
                                borderRadius: BorderRadius.circular(10.0),



                              ),



                            ),


                          ),

                        ),

                        InkWell(
                          onTap: () {
                            // setState(() {
                            //   _targetDateTime = DateTime(_targetDateTime.year, _targetDateTime.month +1);
                            //   _currentMonth = DateFormat.yMMM().format(_targetDateTime);
                            // });
                          },

                          child: Container(
                            height: MediaQuery.of(context).size.height * 0.06,
                            width: MediaQuery.of(context).size.width * 0.28,
                            padding: EdgeInsets.fromLTRB(15, 10, 10, 5),
                            margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                            decoration: BoxDecoration(
                              // color: Colors.amber,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              gradient: LinearGradient(
                                  colors: [
                                   // Colors.white,
                                    Colors.black,
                                    Colors.black
                                  ],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter),
                            ),
                            child: Text(
                              "Next Date",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.white,fontWeight: FontWeight.bold
                              ),
                            ),
                          ),
                        ),



                  ],
                ),
              ),

              SizedBox(
                height: 5,
              ),
              // Container(
              //   padding: EdgeInsets.fromLTRB(50, 10, 50, 10),
              //   // width: MediaQuery.of(context).size.width * 0.8,
              //   color: Colors.blue.shade100,
              //   child: Text(
              //     "Guest Name | No of Tickets | Status",
              //     style: TextStyle(fontSize: 15),
              //   ),
              // ),
              // Center(child: Text("No Data Found !")),

              FutureBuilder(
                  future: _getDetails,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    } else {
                      return Container(
                        // color:Colors.red,
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        margin: EdgeInsets.only(top: 0),
                        width: MediaQuery.of(context).size.width * 1.0,
                        height: MediaQuery.of(context).size.height * 0.76,
                        child: detailsResponseModel.data.iTotalRecords == 0
                            ? Container(
                          margin: EdgeInsets.only(left: 20),
                            child: Text("No Data Found !",style: TextStyle(fontWeight: FontWeight.bold),))
                            : ListView.builder(
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount:
                            detailsResponseModel.data.aaData.length,
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  print(detailsResponseModel
                                      .data.aaData[index].checkinStatus);
                                  if (detailsResponseModel.data
                                      .aaData[index].checkinStatus ==
                                      "0") {
                                    print('hii');
                                    print(
                                      detailsResponseModel
                                          .data.aaData[index].events,
                                    );
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                GuestDetailsCheckIn(
                                                  detailsResponseModel
                                                      .data
                                                      .aaData[index]
                                                      .bookingUid,
                                                  detailsResponseModel
                                                      .data.iTotalRecords
                                                      .toString(),
                                                  true,
                                                  aaData:
                                                  detailsResponseModel
                                                      .data
                                                      .aaData[index],
                                                  guestname: (detailsResponseModel
                                                      .data
                                                      .aaData[index]
                                                      .firstName ??
                                                      "") +
                                                      (detailsResponseModel
                                                          .data
                                                          .aaData[index]
                                                          .lastName ??
                                                          ""),
                                                ))).then((value) {
                                      print("value ------  $value");
                                      if (value == true) {
                                        print(_textEditingController.text);
                                        getDetails(
                                            _textEditingController.text);
                                      }
                                    });
                                  } else {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                GuestDetailsClose(
                                                  detailsResponseModel
                                                      .data
                                                      .aaData[index]
                                                      .bookingUid,
                                                  detailsResponseModel
                                                      .data.iTotalRecords
                                                      .toString(),
                                                  aaData:
                                                  detailsResponseModel
                                                      .data
                                                      .aaData[index],
                                                  guestname: (detailsResponseModel
                                                      .data
                                                      .aaData[index]
                                                      .firstName ??
                                                      "") +
                                                      (detailsResponseModel
                                                          .data
                                                          .aaData[index]
                                                          .lastName ??
                                                          ""),
                                                )));
                                  }
                                },
                                child: Card(
                                  elevation: 5,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Container(
                                    margin:
                                    EdgeInsets.fromLTRB(10, 10, 10, 10),
                                    // color: Colors.amber,
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: [



                                        Container(
                                          margin: EdgeInsets.only(top: 8),

                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                  " ${detailsResponseModel.data.aaData[index].bookingUid}",style: TextStyle(fontWeight: FontWeight.bold),),
                                              // Text(
                                              //
                                              //     widget.aaDataListSM != null
                                              //         ? "Date: ${widget.aaDataListSM[0].date.toString().replaceAll("00:00:00.000", "")??""}"
                                              //         : widget.aaData != null
                                              //         ? "Date: ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
                                              //         : "${detailsResponseModel.data.aaData[index].updatedAt}",
                                              //
                                              //    // "${detailsResponseModel.data.aaData[index].updatedAt}"
                                              // ),

                                              Container(


                                                width: MediaQuery.of(context).size.width * 0.30,
                                                height: MediaQuery.of(context).size.height * 0.02,

                                               // margin: EdgeInsets.only(top: 5,left: 10),
                                                child: TextField(


                                                  focusNode: AlwaysDisabledFocusNode(),
                                                  controller: _textEditingController,
                                                  onTap: () {
                                                   // _selectDate(context);
                                                  },

                                                  decoration: InputDecoration(



                                                    focusedBorder: OutlineInputBorder(

                                                      borderSide:
                                                      const BorderSide(color: Colors.white, width: 0.0),
                                                      borderRadius: BorderRadius.circular(0.0),


                                                    ),

                                                    enabledBorder: OutlineInputBorder(
                                                      borderSide:
                                                      const BorderSide(color: Colors.white, width: 0),
                                                      borderRadius: BorderRadius.circular(0.0),



                                                    ),



                                                 ),


                                                ),

                                              ),




                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(top: 10),
                                          child: Row(
                                           // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                            //  Text("Name ",style: TextStyle(fontWeight: FontWeight.bold), ),

                                              Text(" ${detailsResponseModel.data.aaData[index].firstName ?? ""}" +
                                                  "${detailsResponseModel.data.aaData[index].lastName ?? ""}",style: TextStyle(fontWeight: FontWeight.bold),),
                                            ],
                                          ),
                                        ),
                                        // Row(
                                        //   children: [
                                        //     Text(
                                        //         "Booking Id : ${detailsResponseModel.data.aaData[index].bookingUid}")
                                        //   ],
                                        // ),
                                        Container(
                                          padding: EdgeInsets.only(top: 10,left: 5),
                                          child: Row(
                                            children: [
                                              Text("Event/Table: ",style: TextStyle(fontWeight: FontWeight.bold),),
                                              Text(detailsResponseModel
                                                  .data
                                                  .aaData[index]
                                                  .quantity ==
                                                  null
                                                  ? " "
                                                  :"${detailsResponseModel.data.aaData[index].events}"),

                                            ],
                                          ),
                                        ),
                                        // Row(
                                        //   children: [
                                        //     Text(
                                        //         "Event Name : ${detailsResponseModel.data.aaData[index].events[index].name}")
                                        //   ],
                                        // ),
                                        // Row(
                                        //   children: [
                                        //     Text(
                                        //         "Date : ${detailsResponseModel.data.aaData[index].events[index].createdAt}")
                                        //   ],
                                        // ),
                                        Container(
                                          margin: EdgeInsets.only(top: 8,left: 5,bottom: 5),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              //Text("Amount Paid:",style: TextStyle(fontWeight: FontWeight.bold), ),

                                              Text(detailsResponseModel
                                                  .data
                                                  .aaData[index]
                                                  .finalrate !=
                                                  null
                                                  ? "Amount Paid: ${detailsResponseModel.data.aaData[index].finalrate} GBP"
                                                  : "Amount Paid : ",style: TextStyle(fontWeight: FontWeight.bold),),

                                              // Container(
                                              //   //margin: EdgeInsets.all(5),
                                              //   padding: EdgeInsets.all(2),
                                              //   alignment: Alignment.center,
                                              //   decoration: BoxDecoration(
                                              //       color: Colors.black,
                                              //       border: Border.all(
                                              //           color: Colors.black54, // Set border color
                                              //           width: 2.0),   // Set border width
                                              //       borderRadius: BorderRadius.all(
                                              //           Radius.circular(5.0)), // Set rounded corner radius
                                              //       boxShadow: [BoxShadow(blurRadius: 5,color: Colors.black,offset: Offset(1,3))] // Make rounded corner of border
                                              //   ),
                                              //   child: Text("Check in",style: TextStyle(color: Colors.white)),
                                              // )

                                             // Text("Check in",style: TextStyle(fontWeight: FontWeight.bold), ),
                                            ],
                                          ),
                                        ),

                                        InkWell(
                                          onTap: () {
                                            checkIn(widget.bookingUid, DateTime.now().toString(), "1",
                                                widget.fromDetails, context);
                                          },
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.only(bottom: 5,top: 5),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                                  gradient: LinearGradient(colors: [
                                                    Colors.black,
                                                    Colors.black,
                                                    Colors.black
                                                  ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                                ),
                                                padding: EdgeInsets.fromLTRB(140, 10, 135, 10,),
                                                child: Text(
                                                  "Check In",
                                                  style: TextStyle(
                                                    //fontSize: 20,
                                                      color: Colors.white,fontWeight: FontWeight.bold
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        // Row(
                                        //   children: [
                                        //     Text(detailsResponseModel
                                        //         .data
                                        //         .aaData[index]
                                        //         .checkinStatus ==
                                        //         "1"
                                        //         ? "Status : Checked In"
                                        //         : "Status : Not Checked In")
                                        //   ],
                                        // ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
                      );
                    }
                  }),


            ],
          ),

        ),




    );
  }
  _selectDate(BuildContext context) async {
    DateTime newSelectedDate = await showDatePicker(
        context: context,
        initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2040),
        builder: (BuildContext context, Widget child) {

          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: Colors.blue.shade900,
                onPrimary: Colors.white,
                surface: Colors.blue.shade900,
                onSurface: Colors.white,
              ),
              dialogBackgroundColor: Colors.blue[500],
            ),
            child: child,
          );
        });

    if (newSelectedDate != null) {
      _selectedDate = newSelectedDate;
      final DateFormat formatter = DateFormat('yyyy-MM-dd');
      final String formatted = formatter.format(_selectedDate);
      _textEditingController
        ..text = formatted
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _textEditingController.text.length,
            affinity: TextAffinity.upstream));
      print(formatted);
      getDetails(formatted);
    }
  }

  getEventDetails(String currentDate) {}
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}


