
import 'package:bookings/Splash_Screen.dart';
import 'package:bookings/Tabel/Event.dart';
import 'package:bookings/Tabel/Totle_Rekod.dart';
import 'package:bookings/screens/homeScreen.dart';
import 'package:bookings/screens/scan_qr.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      builder: (context, child) {
        return MediaQuery(

            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: child);
      },
      theme: ThemeData(
       // primarySwatch: Colors.black,
        primarySwatch: Colors.blue,
      ),
     // home: ScanQrScreen(),
    //  home: tabel(),
     // home: Splash2(),
      home: SplashScreen(),
      //home: Totle_Rekod(),

    );
  }
}
