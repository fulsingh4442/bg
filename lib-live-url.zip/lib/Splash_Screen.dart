
import 'dart:async';
import 'package:bookings/Login.dart';
import 'package:bookings/Tabel/Event.dart';
import 'package:flutter/material.dart';


class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();


    Timer(
        Duration(seconds: 4),

            () =>
                Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => Login()))
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        child: Center(

          child: Center(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 280),
                  height: 100,
                    width: 100,
                    child: Image.asset('assets/images/appicon.png',color: Colors.white,)),
                SizedBox(height: 20,),

                // Text('Lizard_Lounge',textScaleFactor: 2,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),


                Container(
                  margin: EdgeInsets.only(top: 100),
                  child: CircularProgressIndicator(
                    backgroundColor: Colors.red,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.white, //<-- SEE HERE
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Text("Loading...",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),))





              ],
            ),


          ),


        ),

      ),

    );
  }
}
