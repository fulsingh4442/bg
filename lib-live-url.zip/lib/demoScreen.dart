import 'dart:convert';
import 'package:bookings/models/Chack_in_Response.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'Tabel/Guest_Checked_In_Successfully.dart';
import 'models/Event_Table_Response.dart';
import 'models/Guest_Checj_Response.dart';
class Event_Screen1 extends StatefulWidget {

  String bookingUid;
  String totalRecords;
  String guest;
  String type;
  String checkin_status;
  String name;
  String paidAmount;
  String checkinStatus;
  String checkinTime;
  String quantity;
  String checkin_guest;
  String eventTicketId;
  List<AaData> dataListSM;
  AaData aaData;
  bool fromDetails;
  Event_Screen1(
      this.bookingUid,
      this.totalRecords,
      this.fromDetails, {
        this.dataListSM,
        this.aaData,
        this.guest,
        this.checkin_status,
        this.name,
        this.paidAmount,
        this.checkinStatus,
        this.checkinTime,
        this.quantity,
        this.checkin_guest,
        this.eventTicketId,


      });
  @override
  _Event_Screen1State createState() => _Event_Screen1State();
}
class _Event_Screen1State extends State<Event_Screen1> {
  SharedPreferences Response;
  String token;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initial();
  }

  void initial() async {
    Response = await SharedPreferences.getInstance();
    setState(() {
      token =Response.getString('token').toString();
    });
  }
  GuestChecjResponse guestChecjResponse;
  ChackInResponse chackInResponse;
  checkInBooking(String bookingId,bookingDate,ticketId,bookingType){
    setState(() {
      _booking(bookingId,bookingDate,ticketId,bookingType).then((value) {
        if(value.status == true){
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (context) => Guest_Checked_In_Successfully()),
                  (Route<dynamic> route) => false);
        }else{
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(value.message.toString()),
          ));
        }
      });
    });
  }
  checkInBooking1(String booking_id,booking_date,unit_id,booking_type,category_id){
    setState(() {
      _booking1( booking_id,booking_date,unit_id,booking_type,category_id).then((value) {
        chackInResponse = value;
      });
    });
  }

  Future<ChackInResponse> _booking1(String booking_id,booking_date,unit_id,booking_type,category_id)async {
    var requestBody = {
      'booking_id': booking_id,
      'booking_type': booking_type,
      'unit_id': unit_id,
      'category_id': category_id,
      'booking_date': booking_date


    };
    http.Response responce = await http.post(
      Uri.parse("https://app-api.teaseme.co.in/api/booking/checkin"),
      headers: <String, String>{
        //'Content-Type': 'application/json; charset=UTF-8',
        'token':token

      },
        body: requestBody

    );
    var data = jsonDecode(responce.body.toString());
    var status = data["status"];
    if (responce.statusCode == 200) {
      print(responce.body);
      // print(data);
      print(token);

      if (status == true) {

        return ChackInResponse.fromJson(data);
      } else {
        return ChackInResponse.fromJson(data);
      }
    } else {
      return ChackInResponse.fromJson(data);
    }

  }

  Future<GuestChecjResponse> _booking(String booking_id,booking_date,event_ticket_id,booking_type)async {
    var requestBody = {
      'booking_id': booking_id,
      'booking_type': booking_type,
      'booking_date': booking_date,
      "event_ticket_id":event_ticket_id

    };
    http.Response responce = await http.post(
        Uri.parse("https://app-api.teaseme.co.in/api/booking/checkin"),
        headers: <String, String>{
          //'Content-Type': 'application/json; charset=UTF-8',
          'token':token

        },

        body: requestBody
    );
    var data = jsonDecode(responce.body.toString());
    var status = data["status"];
    if (responce.statusCode == 200) {
      print(responce.body);
      // print(data);
      print(token);


      if (status == true) {
        return GuestChecjResponse.fromJson(data);
      } else {
        return GuestChecjResponse.fromJson(data);
      }
    } else {
      return GuestChecjResponse.fromJson(data);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back)),
        title: Center(
          child: Container(
              margin: EdgeInsets.only(right: 55),
              height: 45,width: 45,

              child: Image.asset('assets/images/appicon.png',color: Colors.white, )),
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.only(left: 0,right: 0),
          child: Column(

            children: [
              Container(
                alignment: Alignment.topLeft,
                  margin: EdgeInsets.only(top: 13,left: 15,bottom: 10),
                  child: Text("Booking Details",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),)


              ),
              Divider(color: Colors.grey,),
              Expanded(
              child: FutureBuilder<EventTableResponse>(
                 // future: scanData().
                  builder: (context, snapshot) {
                    print(snapshot.hasData);
                    if (snapshot.hasData) {

                      return Center(child: CircularProgressIndicator());
                    } else {
                      return

                        ListView.builder(
                          itemCount: widget.dataListSM.length,
                          itemBuilder: (context, index) {
                            if( widget.dataListSM[index].type == 'table'){
                              return
                                Column(

                                  children: [

                                    Container(
                                      margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                                      child: Card(
                                        elevation: 5,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              10),
                                        ),
                                        child: Column(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment
                                                    .spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Text(
                                                        "Booking ID:",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            fontWeight: FontWeight
                                                                .bold),
                                                      ),

                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        right: 0),
                                                    child: Text("${widget.dataListSM[index].bookingUid}",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                  ],
                                ),
                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Text(
                                                          " Date:",
                                                          style: TextStyle(
                                                              fontSize: 15,
                                                              fontWeight: FontWeight
                                                                  .bold),
                                                        ),
                                                      ),
                                                      Text(  widget.dataListSM != null
                                                          ? " ${widget.dataListSM[index].date.toString().replaceAll("00:00:00.000", "")??""}"
                                                          : widget.aaData != null
                                                          ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
                                                          : " ",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(

                                                    "Guest: ",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text( widget.dataListSM != null
                                                        ? "${widget.dataListSM[index].guest??""}"
                                                        : widget.aaData != null
                                                        ? " ${widget.aaData.guest}"
                                                        : " ",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(
                                                    "Table: ",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text(  widget.dataListSM != null
                                                        ? "${widget.dataListSM[index].name??""}"
                                                        : widget.aaData != null
                                                        ? " ${widget.aaData.name}"
                                                        : " ",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(

                                                    "Paid Amount:",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Row(
                                                    children: [

                                                      Container(
                                                        child: Text(  widget.dataListSM != null
                                                            ? "${widget.dataListSM[index].paidAmount??""}"
                                                            : widget.aaData != null
                                                            ? " ${widget.aaData.paidAmount}"
                                                            : " ",
                                                          style: TextStyle(
                                                              fontSize: 15),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Column(
                                                children: [
                                                  if(widget.dataListSM[index]
                                                      .checkinStatus ==
                                                      0)...{


                                                    InkWell(
                                                      onTap: () {

                                                        setState((){
                                                          _booking1(
                                                              widget.dataListSM
                                                          [index].bookingUid,
                                                              widget.dataListSM
                                                              [index].date,
                                                              widget.dataListSM
                                                              [index].unitId,
                                                              widget.dataListSM[index].categoryId,
                                                              "table");
                                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                            content: Text("Check in successfully"),
                                                          ));
                                                          // if(chackInResponse.status == true){
                                                          //   Navigator.of(context).pushAndRemoveUntil(
                                                          //       MaterialPageRoute(builder: (context) => Guest_Checked_In_Successfully()),
                                                          //           (Route<dynamic> route) => false);
                                                          //
                                                          // }else{
                                                          //
                                                          //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                          //     content: Text(""+chackInResponse.message.toString()),
                                                          //   ));
                                                          // }


                                                          // chackInResponse == true; // Set state like this
                                                        });
                                                        // setState((){
                                                        //   _booking("");
                                                        //   Fluttertoast.showToast(
                                                        //       msg: "Guest already check-in",
                                                        //
                                                        //       toastLength: Toast.LENGTH_SHORT,
                                                        //       timeInSecForIosWeb: 2,
                                                        //       backgroundColor: Colors.black, //ColorRes.primaryColor,
                                                        //       textColor: Colors.white,
                                                        //       fontSize: 20.0,
                                                        //       gravity: ToastGravity.BOTTOM);
                                                        // });
                                                      },

                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(bottom: 10,top: 10),
                                                            decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.all(Radius.circular(5)),
                                                              gradient: LinearGradient(colors: [
                                                                Colors.black,
                                                                Colors.black,
                                                                Colors.black
                                                              ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                                            ),
                                                            padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                                                            child: Text(
                                                              "Checked In",
                                                              style: TextStyle(
                                                                //fontSize: 20,
                                                                  color: Colors.white,fontWeight: FontWeight.bold
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),




                                                  }else...{


                                                    Container(
                                                      margin: EdgeInsets.only(right: 10,bottom: 10,top: 5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(right: 20,),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                    margin: EdgeInsets.only(left: 10),
                                                                    height: 25,width: 20,

                                                                    child: Image.asset('assets/images/img_6.png', )),
                                                                Text(' Check-In',style: TextStyle(fontWeight: FontWeight.bold),),
                                                              ],
                                                            ),
                                                          ),

                                                          Row(
                                                            children: [
                                                              Container(
                                                                child: Text("Time: ",

                                                                  style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                                                ),
                                                              ),
                                                              Container(
                                                                child: Text( widget.dataListSM != null
                                                                    ? "${widget.dataListSM[0].checkinTime??""}"
                                                                    : widget.aaData != null
                                                                    ? " ${widget.aaData.checkinTime}"
                                                                    : " ",
                                                                  // snapshot.data.data.aaData[index].checkinTime.toString(),
                                                                  style: TextStyle(fontSize: 15,),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  }
                                                ]),

                                          ],
                                        ),
                                      ),
                                    ),


                                  ],
                                );

                            }else{
                              return
                                Column(

                                  children: [

                                    Container(
                                      margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                                      child: Card(
                                        elevation: 5,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              10),
                                        ),
                                        child: Column(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment
                                                    .spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Text(
                                                        "Booking ID:",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            fontWeight: FontWeight
                                                                .bold),
                                                      ),

                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        right: 0),
                                                    child: Text("${widget.dataListSM[index].bookingUid}",
                                                      // snapshot.data.data.aaData[index].bookingUid.toString(),
                                                      // "E1245",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Text(
                                                          " Date:",
                                                          // " ${widget.bookingUid}",
                                                          style: TextStyle(
                                                              fontSize: 15,
                                                              fontWeight: FontWeight
                                                                  .bold),
                                                        ),
                                                      ),
                                                      Text(  widget.dataListSM != null
                                                          ? " ${widget.dataListSM[index].date.toString().replaceAll("00:00:00.000", "")??""}"
                                                          : widget.aaData != null
                                                          ? " ${widget.aaData.date.toString().replaceAll("00:00:00.000", "")}"
                                                          : " ",
                                                        // snapshot.data.data.aaData[index].date.toString(),

                                                        // " ${widget.bookingUid}",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(

                                                    "Guest: ",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text( widget.dataListSM != null
                                                        ? "${widget.dataListSM[index].guest??""}"
                                                        : widget.aaData != null
                                                        ? " ${widget.aaData.guest}"
                                                        : " ",
                                                      // snapshot.data.data.aaData[index].guest.toString(),

                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(
                                                   "Event: ",

                                                    // snapshot.data.data.aaData[index].type.toString(),
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Container(
                                                    child: Text(  widget.dataListSM != null
                                                        ? "${widget.dataListSM[index].name??""}"
                                                        : widget.aaData != null
                                                        ? " ${widget.aaData.name}"
                                                        : " ",
                                                      style: TextStyle(
                                                          fontSize: 15),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),



                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text( "Paid Amount:",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Text(  widget.dataListSM != null
                                                            ? "${widget.dataListSM[index].paidAmount??""}"
                                                            : widget.aaData != null
                                                            ? " ${widget.aaData.paidAmount}"
                                                            : " ",
                                                          style: TextStyle(
                                                              fontSize: 15),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Container(
                                              margin: EdgeInsets.only(
                                                  left: 10, top: 10, right: 10),
                                              child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Text(

                                                        "No of Tickets:",
                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            fontWeight: FontWeight
                                                                .bold),
                                                      ),
                                                      Text(
                                                        widget.dataListSM != null
                                                          ? "${widget.dataListSM[index].quantity??""}"
                                                          : widget.aaData != null
                                                          ? " ${widget.aaData.quantity}"
                                                          : " ",


                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            ),
                                                      ),
                                                    ],
                                                  ),

                                                  Row(
                                                    children: [
                                                      Container(
                                                        child: Row(
                                                          children: [

                                                            Text(
                                                                 "Checked-In:",
                                                              style: TextStyle(
                                                                  fontSize: 15,fontWeight: FontWeight.bold),
                                                            ),

                                                            Text(
                                                              widget.dataListSM != null
                                                                  ? "${widget.dataListSM[index].checkinGuest??""}"
                                                                  : widget.aaData != null
                                                                  ? " ${widget.aaData.checkinGuest}"
                                                                  : " ",
                                                              style: TextStyle(
                                                                  fontSize: 15),
                                                            ),




                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),

                                            Column(
                                                children: [
                                                  if(widget.dataListSM[index]
                                                      .checkinStatus ==
                                                      0)...{
                                                    InkWell(
                                                      onTap: () {

                                                          checkInBooking(
                                                              widget.dataListSM
                                                              [index].bookingUid,
                                                              widget.dataListSM
                                                              [index].date,
                                                              widget.dataListSM
                                                              [index].event_ticket_id,
                                                              "event"
                                                          );
                                                        //   if(guestChecjResponse.status == true){
                                                        //     Navigator.of(context).pushAndRemoveUntil(
                                                        //         MaterialPageRoute(builder: (context) => Guest_Checked_In_Successfully()),
                                                        //             (Route<dynamic> route) => false);
                                                        //
                                                        //   }else{
                                                        //
                                                        //     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                        //       content: Text(""+guestChecjResponse.message.toString()),
                                                        //     ));
                                                        //   }
                                                         },


                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(bottom: 10,top: 10),
                                                            decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.all(Radius.circular(5)),
                                                              gradient: LinearGradient(colors: [
                                                                Colors.black,
                                                                Colors.black,
                                                                Colors.black
                                                              ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                                                            ),
                                                            padding: EdgeInsets.fromLTRB(135, 10, 135, 10,),
                                                            child: Text(
                                                              "Check In",
                                                              style: TextStyle(
                                                                //fontSize: 20,
                                                                  color: Colors.white,fontWeight: FontWeight.bold
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),

                                                  }else...{

                                                    Container(
                                                      margin: EdgeInsets.only(right: 10,bottom: 10,top: 5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(right: 20,),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                    margin: EdgeInsets.only(left: 10),
                                                                    height: 25,width: 20,

                                                                    child: Image.asset('assets/images/img_6.png', )),

                                                                Text(' Checked-In',style: TextStyle(fontWeight: FontWeight.bold),),
                                                              ],
                                                            ),
                                                          ),

                                                          Row(
                                                            children: [
                                                              Container(
                                                                child: Text("Time: ",

                                                                  style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                                                ),
                                                              ),
                                                              Container(
                                                                child: Text( widget.dataListSM != null
                                                                    ? "${widget.dataListSM[index].checkinTime??""}"
                                                                    : widget.aaData != null
                                                                    ? " ${widget.aaData.checkinTime}"
                                                                    : " ",
                                                                  // snapshot.data.data.aaData[index].checkinTime.toString(),
                                                                  style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),



                                                  }
                                                ]),

                                          ],
                                        ),
                                      ),
                                    ),


                                  ],
                                );

                            }

                           }







                      );
                    }
                  }



              ),
            ),

            ],
          ),

        ),
      ),
    );
  }

}


